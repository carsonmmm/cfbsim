# Football Empire

Open `football-empire.html` in any modern browser to play. No install needed.

For development, see `CLAUDE.md`: edit `src/`, run `python3 build.py`, and test with `npm test`.
