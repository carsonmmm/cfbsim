# Football Empire

A football management game that ships as **one self-contained HTML file** (`football-empire.html`) with no server and no dependencies. Saves live in the browser's localStorage.

Four ways to play, sharing one engine:
- **AD mode**: athletic director for any of 138 FBS programs (Michigan keeps its real roster).
- **Coach mode**: a coaching career from position coach to head coach, in college and the NFL.
- **NFL GM**: running an NFL front office (cap, contracts, trades, free agency, draft).
- **Player Career**: one player from high school through college and the NFL.

## Build

Never edit `football-empire.html` by hand. Edit the files in `src/`, then build:

```
python3 build.py            # writes football-empire.html
```

`build.py` joins the JS files in the order of its `FILES` list into `src/shell.html` (at the `/*JS*/` marker). `shell.html` holds the page skeleton and all CSS. The order matters: later files use earlier ones.

## Source layout (`src/`)

Engine files must stay **DOM-free**, because the Node tests load them directly:
- `data.js`: league data, seeded RNG (`R()`, `ri`, `gauss`), `hash`, constants.
- `core.js`: game sim (`createSim`/`simStep`/`simRun`), team strength, weeks, postseason, **league rules** (`RULE_DEFS`, `RULE_PRESETS`, `rules()`, `setRule`).
- `features.js`: events, recruiting, offseason steps (`offStepNext`), `offBlockers`, save migration (`migrate`).
- `systems.js`: season systems, **game day** (halftime speech `SPEECHES`/`speechFx`, replay review `reviewable`/`challengePlay`), **personalities that change** (`evolvePers`, `lockerRoom`), **injury rehab** (`REHAB`, `setRehab`), **scouting staff** (`scoutList`, `recScout`, `proScoutBoost`/`effSc`), AD **bonds and booster strings** (`issueBond`, `bondsYearEnd`, `boosterOffer`, `stringsCheck`), **bowl week** (`setTrip`), **historical rankings import** (`parseRankings`, `importRankings`), **team identity / schemes** (`OFF_SCH`, `DEF_SCH`, `myScheme`, `playerFit`), **relationships** (`rapOf`, `rapAdj`, `relAfterGame`), **legacy** (timeline `tlPush`, season highlights `buildHighlights`, Hall of Fame `hofConsider`, long-term goals `MILES`/`recordMile`), AD **media rights** and **conference moves**, the **coaching tree** and the coach's **practice plan**.
- `storage.js`: save slots, save queue (`makeSaveQueue`), save-state text, remembered filters.
- `coach.js`: Coach mode engine. `career.js`, `cgame.js`, `nfl.js`: Player Career (also following/endorsements with yearly brand offers `endorseSeason`, the combine and pro day, the after-career choice, college academics `acad`/`acadTerms`, teammates `mateList`/`chemistry`, NFL holdouts `nflHoldout`). `pro.js`: the NFL world for GM and NFL coaches (contracts, cap, trades and deadline deals, draft with compensatory picks, mock drafts and workouts, fifth-year options, Ring of Honor, schedule).

UI files (these use the DOM): `theme.js`, `ui.js`, `fieldview.js` (the animated field in live games), `admin.js`, `cui.js`, `coachui.js`, `proui.js`, `share.js` (leaderboards and league challenges), `qol.js` (undo, keyboard shortcuts, the glossary, the what-changed summary). Input and startup: `app.js`, `capp.js`.

Patterns:
- Views are functions that return HTML strings. `render()` redraws.
- Buttons use `data-act="name"`, handled in `actions` objects (`Object.assign(actions, {...})`).
- Escape all user and data text with `esc()`.
- Actions that change the roster during a live game must be listed in `LIVE_LOCKED` (app.js).

## Key models

- **World swap**: `state.lvl` is `'col'` or `'nfl'`. In the NFL, the college world is stashed in `state.colW`; NFL-only data is in `state.pro` (use `PS()`).
- **NFL contracts**: `k = { sal: [...], pr: [...], yrs, base, bpy, tot, rk, apy, shape? }`. There is one salary and one bonus charge per remaining season. `base`/`bpy` mirror index 0 and are kept in step by `kFix(k)`. Use `capHit`, `yearHit(p, i)`, `deadIfCut`, `restructureK`, `extendK`, `mkContract(apy, yrs, bonusShare, rk, shape)`.
- **League rules**: new careers start on the Realistic preset. `proRoster` (53/48/46) sets the NFL in-season roster limit; use `proMax()`, never a constant. Saves from before rules existed get Classic, which must keep playing exactly as before.
- **Draft picks**: `pro.picks` is the single owner record. `syncDraftSlots()` updates the draft order. Compensatory picks carry `c: true`; every match between a pick and a draft slot must compare `yr`, `rd`, `orig` and `!c`.
- **Game clock**: for your games, `sim.el` counts seconds used; `driveClock()` gives each drive time by its length so each half ends at 0:00 without changing the number of drives. Other games skip the clock for speed.
- **World-shared keys**: `WORLD_SHARED` (pro.js) lists what follows you between college and the NFL (for example `tline`, the timeline, and `mile`, long-term goals).
- **Field view** (`fieldview.js`): purely visual. It reads `sim.log` entries (each carries `pl`, the drive's last plays, plus `man`, `fg`, `good`, `endYl`) and the called plays in `pending.ds.plays`; it never calls `R()`. `pfSync()` runs after every `renderLive()`; `liveTick` waits for `pfLeft()`. Off with `prefs.field = 'off'`.
- **Deterministic extras**: features added after a game's random stream was fixed (personality changes, replay rulings, scouts, booster offers, grades, holdouts, new players' personalities) use `hash()` instead of `R()`, so they don't shift results.
- **Sharing** (`share.js`): uses the artifact `db` and `user` capabilities when present (`window.claude.use`), and hides itself otherwise. Each player keeps one document `scores/<id>` with up to 25 careers; challenges live in `challenges`. Only ids are stored about people.
- **Messages after an action** (`ui.flash`) render as a floating toast (`.flash.toast`) so the page never shifts; renders keep the scroll position.

## Rules for changes

- **Old saves must keep loading.** Any new field needs a safe default, set lazily or in `migrate()` (features.js) / `migratePro()` (pro.js). `tests/fixtures/` holds saves from older versions that the regression tests load.
- Keep the existing design: 5 themes (classic, broadcast, gazette, scoreboard, dashboard), light and dark, sidebar or top tabs, and the phone layout (check at 390px wide).
- Generated rosters and teams outside Michigan are fictional. Storylines involving players only use fictional players.
- Don't put `//` comments in the middle of a one-line statement (it comments out the rest of the line). Use `/* */`.

## Tests

Setup once: `npm install`, then `npx playwright install chromium` (needed for the browser tests).

```
npm test              # build + Node engine suites (fast)
npm run test:browser  # build + headless Chromium suites (slower, about 5 minutes)
npm run test:all
```

Suites: `engine`, `career`, `regression`, `v8`, `v9` (Node, run the engine in a VM); `*.browser.test.js` (Playwright against the built HTML, served by `tests/serve.js`). Add checks for anything that changes game rules, usually in `tests/v9.test.js` using `sec()` and `check()`.
