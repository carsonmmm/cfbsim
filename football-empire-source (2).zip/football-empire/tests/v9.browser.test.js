// Football Empire (v9) browser checks: Player Career slot loads stay in request order (B10),
// and the NFL front office and Coach mode render with no page errors.
//   node tests/v9.browser.test.js   (needs Playwright)
const path = require('path'); const { chromium } = require('playwright'); const { serveFile } = require('./serve.js');
const sleep = ms => new Promise(r => setTimeout(r, ms));
let pass = 0, fail = 0; const out = []; const check = (n, c, d) => { (c ? pass++ : fail++); out.push(`${c ? 'PASS' : 'FAIL'}  ${n}${d ? '  (' + d + ')' : ''}`); };
(async () => {
  const url = await serveFile(path.join(__dirname, '..', 'football-empire.html')); const browser = await chromium.launch();
  {
    const page = await (await browser.newContext()).newPage(); const errors = []; page.on('pageerror', e => errors.push(e.message));
    await page.goto(url); await page.waitForSelector('#view .modes');
    await page.evaluate(async () => {
      appMode = 'career'; rngOwner = 'career';
      for (const [i, last] of [[2, 'Second'], [3, 'Third']]) { newCareer({ pos: 'QB', first: 'Slot', last, num: i, home: 'OH', path: 'hs', stars: 3, diff: 'normal', pace: 'sim' }); cslot = i; cSave(); await cFlush(); }
      const orig = cLoadSlot; cLoadSlot = async i => { if (i === 2) await new Promise(r => setTimeout(r, 400)); return orig(i); };
      actions.cload({ i: '2' }); actions.cload({ i: '3' });
    });
    await sleep(1500);
    const r = await page.evaluate(() => ({ slot: cslot, last: cs && cs.p.last }));
    check('B10: two quick Player Career loads finish in the order they were asked for (the last one wins)', r.slot === 3 && r.last === 'Third', JSON.stringify(r));
    check('no page errors during the load race', errors.length === 0, errors[0]);
  }
  {
    const page = await (await browser.newContext()).newPage(); const errors = []; page.on('pageerror', e => errors.push(e.message));
    await page.goto(url); await page.waitForSelector('#view .modes');
    await page.click('[data-act=adpick]'); await page.click('[data-act=adpicklvl][data-v=nfl]'); await page.click('[data-act=adpickstart]');
    await page.waitForFunction(() => typeof state !== 'undefined' && state && state.lvl === 'nfl', null, { timeout: 20000 });
    const tabs = await page.evaluate(() => PRO_TABS.map(t => t[0]).filter(proTabVisible));
    for (const t of tabs) await page.evaluate(t => { ui.tab = t; render(); }, t);
    await page.evaluate(() => { let n = 0; while (state.phase === 'offseason' && n++ < 10) { autoSet().draft = true; autoSet().cuts = true; if (!proOffNext()) break; } ui.tab = 'office'; render(); });
    const r = await page.evaluate(() => ({ phase: state.phase, cap: capRoom(ME) >= 0 }));
    check('an NFL GM career opens, every tab renders, and the offseason reaches the season', r.phase === 'regular' && r.cap && errors.length === 0, JSON.stringify(r) + ' ' + (errors[0] || ''));
  }
  {
    const page = await (await browser.newContext()).newPage(); const errors = []; page.on('pageerror', e => errors.push(e.message));
    await page.goto(url); await page.waitForSelector('#view .modes');
    await page.click('[data-act=adpick]'); await page.click('[data-act=adpicklvl][data-v=nfl]'); await page.click('[data-act=adpickstart]');
    await page.waitForFunction(() => typeof state !== 'undefined' && state && state.lvl === 'nfl', null, { timeout: 20000 });
    await page.evaluate(() => { PS().offers = [{ lvl: 'col', tid: 'OSU', role: 'AD', int: 90, id: 'col:OSU' }]; globalThis.__real = collegeArrive; collegeArrive = () => { throw new Error('test failure'); }; actions.jobtake({ id: 'col:OSU' }); });
    await sleep(500);
    const a = await page.evaluate(() => ({ pending: !!state.pendingArrive, msg: (document.querySelector('#modal .h2') || {}).textContent }));
    await page.evaluate(() => { collegeArrive = __real; }); await page.click('#modal [data-act=catchretry]');
    await page.waitForFunction(() => !state.pendingArrive && !ui.catching, null, { timeout: 30000 });
    const b = await page.evaluate(() => ({ lvl: state.lvl || 'col', me: ME, phase: state.phase }));
    check('S02: a failed move back to college stays pending with a retry, and the retry finishes it', a.pending && /didn't finish/.test(a.msg || '') && b.me === 'OSU' && b.phase === 'regular', JSON.stringify([a, b]));
  }
  // v9.7: the field view, keyboard shortcuts, undo and the glossary
  {
    const page = await (await browser.newContext()).newPage(); const errors = []; page.on('pageerror', e => errors.push(e.message));
    await page.goto(url); await page.waitForSelector('#view .modes');
    await page.click('[data-act=adpick]'); await page.selectOption('#nc-tid', 'TCU'); await page.click('[data-act=adpickstart]'); await page.waitForFunction(() => typeof state !== 'undefined' && state && appMode === 'ad');
    await page.evaluate(() => startLive()); await page.waitForSelector('#modal .pfield svg'); await sleep(300);
    const pos = () => page.evaluate(() => [...document.querySelectorAll('#modal .pfd')].map(g => g.getAttribute('transform')).join('|'));
    const f0 = await page.evaluate(() => ({ dots: document.querySelectorAll('#modal .pfd').length, nums: [...document.querySelectorAll('#modal .pfd text')].filter(t => /^\d{1,2}$/.test(t.textContent)).length }));
    const p1 = await pos(); await sleep(900); const p2 = await pos(); await sleep(1600);
    const f1 = await page.evaluate(() => ({ logs: live.sim.log.length, cap: document.querySelector('#modal .pfcap').textContent }));
    check('v9.7: the field view shows 22 players with jersey numbers', f0.dots === 22 && f0.nums === 22, JSON.stringify(f0));
    check('v9.7: the players move during a play', p1 !== p2, f1.cap);
    await page.click('#modal #lfield'); await sleep(300);
    const off = await page.evaluate(() => ({ field: !!document.querySelector('#modal .pfield'), pref: prefs.field }));
    check('v9.7: the field view can be turned off from the live game', !off.field && off.pref === 'off', JSON.stringify(off));
    await page.evaluate(() => { setPref('field', 'on'); liveSkip(); hideModal(); });
    await page.keyboard.press('?'); await sleep(200); const kb = await page.evaluate(() => !$('#modal').hidden && /Keyboard shortcuts/.test($('#modal').textContent)); await page.evaluate(() => hideModal());
    await page.keyboard.press('2'); await sleep(200); const t2 = await page.evaluate(() => ui.tab);
    check('v9.7: keyboard shortcuts open the list and switch tabs', kb && t2 !== 'office', t2);
    const u = await page.evaluate(() => { const p = state.roster.find(x => x.pos === 'WR' && state.depth.WR.indexOf(x.id) >= 4); openModal(playerModal(p.id)); return p.id; });
    await page.click('#modal [data-act=mkstarter]'); await sleep(200); const moved = await page.evaluate(id => state.depth.WR.indexOf(id), u); await page.evaluate(() => hideModal());
    await page.click('.undobar [data-act=undo]'); await sleep(200); const back = await page.evaluate(id => state.depth.WR.indexOf(id), u);
    check('v9.7: a roster move can be undone', moved === 0 && back >= 4, moved + ' -> ' + back);
    await page.evaluate(() => { ui.tab = 'office'; render(); }); await sleep(100); const gl = await page.evaluate(() => [...document.querySelectorAll('#view .glo')].map(e => e.title).filter(Boolean).length);
    check('v9.7: ratings and numbers carry an explanation', gl >= 3, String(gl));
    check('v9.7: no page errors with the field view and shortcuts', errors.length === 0, errors[0]);
  }
  await browser.close();
  out.forEach(l => console.log(l)); console.log(`\n${pass} passed, ${fail} failed`); process.exit(fail ? 1 : 0);
})();
