// Football Empire (v8) checks: any-school AD careers, the AD NFL Draft, and the Player Career NFL.
// Runs the real engine files in a Node VM with a fake browser, like engine.test.js.
//   node tests/v8.test.js [sourceDir]
const fs = require('fs'), path = require('path'), vm = require('vm');
const dir = path.resolve(process.argv[2] || path.join(__dirname, '..', 'src'));
const FIX = path.join(__dirname, 'fixtures');
const FILES = ['data.js', 'core.js', 'features.js', 'systems.js', 'storage.js', 'coach.js', 'career.js', 'cgame.js', 'nfl.js', 'pro.js'];
function makeContext() {
  const store = new Map(); const noop = () => {};
  const ctx = {
    console, setTimeout, clearTimeout, performance, Promise, JSON, Math, Date, Blob, Response,
    localStorage: { getItem: k => (store.has(k) ? store.get(k) : null), setItem: (k, v) => store.set(k, String(v)), removeItem: k => store.delete(k), clear: () => store.clear() },
    window: { addEventListener: noop }, document: { addEventListener: noop, getElementById: () => null, querySelector: () => null, visibilityState: 'visible' },
    btoa: s => Buffer.from(s, 'binary').toString('base64'), atob: s => Buffer.from(s, 'base64').toString('binary'), escape, unescape, ui: {}, applyTheme: noop, render: noop,
  };
  vm.createContext(ctx); vm.runInContext(FILES.map(f => fs.readFileSync(path.join(dir, f), 'utf8')).join('\n'), ctx, { filename: 'engine' });
  return ctx;
}
const run = (ctx, code) => vm.runInContext('{' + code + '\n}', ctx);
let pass = 0, fail = 0; const out = [];
function check(name, cond, detail) { (cond ? pass++ : fail++); out.push(`${cond ? 'PASS' : 'FAIL'}  ${name}${detail ? '  (' + detail + ')' : ''}`); }
function sec(name, fn) { try { fn(); } catch (e) { fail++; out.push(`FAIL  ${name}: section error: ${String(e.message).split('\n')[0]}`); } }

// ---------------- AD mode: any of the 138 schools ----------------
sec('all schools', () => {
  const c = makeContext();
  const r = run(c, `const bad = []; const ids = Object.keys(CTEAMS0_AD);
    ids.forEach(id => { try { newGame('normal', null, 5, id); const games = mGames().filter(g => g.type === 'reg'); const arch = archRival();
      const str = michStrength().ovr; const rt = CTEAMS0_AD[id].rating;
      if (ME !== id || state.my !== id) bad.push(id + ': ME'); else if (games.length !== 12) bad.push(id + ': ' + games.length + ' games');
      else if (state.roster.length < 80) bad.push(id + ': roster ' + state.roster.length);
      else if (arch && !games.some(g => g.h === arch || g.a === arch)) bad.push(id + ': archrival ' + arch + ' not scheduled');
      else if (id !== 'MICH' && Math.abs(str - rt) > 3) bad.push(id + ': strength ' + str.toFixed(1) + ' vs ' + rt);
      else if (!TEAM_INFO[id] || !TEAM_INFO[id].stadium) bad.push(id + ': no stadium');
    } catch (e) { bad.push(id + ': ' + e.message); } }); ({ n: ids.length, bad })`);
  check('all 138 FBS schools start an AD career with a 12-game schedule, their archrival, a full roster and a fair strength', r.n === 138 && r.bad.length === 0, r.n + ' schools; ' + r.bad.slice(0, 5).join('; '));
});
sec('michigan stays real', () => {
  const c = makeContext();
  const r = run(c, `newGame('normal', null, 9, 'MICH'); ({ real: state.roster.filter(p => p.real).length, osu: state.rivals.OSU && state.rivals.OSU.w > 50, hc: state.staff.HC.name, theme: typeof schoolColors })`);
  check('Michigan keeps its real roster, staff and rivalry records', r.real >= 80 && r.osu && /Whittingham/.test(r.hc), JSON.stringify(r));
});
sec('non-michigan seasons', () => {
  const c = makeContext();
  const r = run(c, `newGame('normal', null, 31, 'ALA'); const before = RNG.s; const board = draftClass(); const mock = simDraft(state.season, board); const same = RNG.s === before;
    const txt = []; let n = 0; while (state.phase !== 'offseason' && n++ < 40) advance();
    const off = state.off.step; autoOffseason(); const after = state.lastDraft;
    ({ same, pool: board.length, picks: mock.picks.length, uniq: new Set(mock.picks.map(p => p.id)).size, nos: mock.picks.map(p => p.no).join(',') === Array.from({ length: 257 }, (_, i) => i + 1).join(','),
       rounds: [1,2,3,4,5,6,7].map(r => mock.picks.filter(p => p.rd === r).length).join('/'), off, season: state.season, draft: after && after.year, mine: after && after.mine.length,
       hist: state.draft.filter(d => d.no && d.tm).length, alum: state.alumni.filter(a => /Drafted by the|Undrafted/.test(a.where)).length, news: state.news.some(x => /NFL Draft: the /.test(x.txt)) })`);
  check('the draft board and mock draft never touch the game\'s random sequence', r.same, '');
  check('a draft class has more prospects than picks, and the draft makes 257 unique picks in order', r.pool > 300 && r.picks === 257 && r.uniq === 257 && r.nos, `${r.pool} prospects, rounds ${r.rounds}`);
  check('the offseason runs the NFL Draft step and records round, pick and team for your players', r.off === 0 && r.season === 2027 && r.draft === 2027 && r.mine > 0 && r.hist === r.mine && r.alum >= r.mine && r.news, JSON.stringify(r));
});
sec('draft step order', () => {
  const c = makeContext();
  const r = run(c, `newGame('normal', null, 12, 'OSU'); let n = 0; while (state.phase !== 'offseason' && n++ < 40) advance();
    const seen = []; let g = 0; while (state.phase === 'offseason' && g++ < 20) { const o = state.off; seen.push(o.step + ':' + OFF_STEPS[o.step]); if (o.step === 1) { autoBoard(); autoDeals(); } if (o.step === 2) autoHire(); if (o.step === 5 && !state.rec.done) signingDay(); if (o.step === 6 && !o.nfl) { const d = (o.declared || []).length; seen.push('declared ' + d); } offStepNext(); }
    seen.join(' | ')`);
  check('offseason steps run recap → board → staff → departures → portal → signing → NFL Draft → development', /5:Signing Day \| 6:NFL Draft \| declared \d+ \| 7:Development & captains/.test(r), r);
});
sec('custom program', () => {
  const c = makeContext();
  const r = run(c, `newGame('normal', { name: 'Lakeshore Tech', ab: 'LST', conf: 'MAC', tier: 'mid', stadium: 'Harbor Field', cap: 40000, c1: '#0B6E4F', c2: '#F2C14E', replace: 'KENT' }, 7);
    ({ me: ME, name: myName(), inConf: CONFS.MAC.teams.includes('KENT'), rivals: Object.values(state.rivals).map(x => x.name), fac: facName('stadium') })`);
  check('a custom program takes the chosen school\'s place, with its own rivalry names and stadium', r.me === 'KENT' && r.name === 'Lakeshore Tech' && r.inConf && r.rivals.every(n => n.startsWith('Lakeshore Tech')) && r.fac === 'Harbor Field', JSON.stringify(r));
});
sec('v7 saves', () => {
  for (const [f, want] of [['v7save_off5.json', 5], ['v7save_off6.json', 7]]) {
    const p = path.join(FIX, f); if (!fs.existsSync(p)) continue; const c = makeContext();
    const r = run(c, `(() => { try { adoptState(JSON.parse(${JSON.stringify(fs.readFileSync(p, 'utf8'))})); const st = state.off.step; const v = state.v; let g = 0; while (state.phase === 'offseason' && g++ < 10) { if (state.off.step === 5 && !state.rec.done) signingDay(); offStepNext(); } let n = 0; while (state.phase !== 'offseason' && n++ < 40) advance(); return { st, v, my: state.my, phase: state.phase, season: state.season }; } catch (e) { return { err: e.message }; } })()`);
    check(`v7 save ${f} loads at the right offseason step and plays into the next season`, r.st === want && r.v === 4 && r.my === 'MICH' && r.phase === 'offseason' && r.season === 2027, JSON.stringify(r));
  }
});

// ---------------- Player Career: the NFL ----------------
const toDraft = (pos, stars, seed) => `newCareer({ pos: '${pos}', first: 'Test', last: 'Pro', num: 7, home: 'TX', path: 'college', stars: ${stars}, seed: ${seed} }); cs.p.auto = true;
  signWith(offersList().sort((a, b) => teamLevel(b.id) - teamLevel(a.id))[0].id);
  let gq = 0; while (cs.phase !== 'done' && gq++ < 40) { const r = cSimUntil(null, { events: true, spend: true }); if (r === 'choice' && offStep() === 'draft') declareDraft(true); else if (r === 'choice') offNext(); }`;
sec('nfl start', () => {
  const c = makeContext();
  const r = run(c, `${toDraft('QB', 5, 101)} const d = cs.done.draft; const ok = nflStart(); const L = cs.nfl.L;
    const per = {}; const byes = {}; L.games.forEach(g => { [g.h, g.a].forEach(t => per[t] = (per[t] || 0) + 1); });
    NFL.forEach(t => { const wks = new Set(L.games.filter(g => g.h === t.id || g.a === t.id).map(g => g.wk)); byes[t.id] = 18 - wks.size; });
    const dupWeek = L.games.some(g => L.games.some(h => h !== g && h.wk === g.wk && [h.h, h.a].some(x => x === g.h || x === g.a)));
    ({ ok, tm: cs.nfl.tm, team: nflName(cs.nfl.tm) === d.team, lvl: cs.lvl, phase: cs.phase, games: Object.values(per).every(n => n === 17), byes: Object.values(byes).every(n => n === 1), dupWeek, bonus: cs.nfl.contract.bonus > 0, yrs: cs.nfl.contract.yrs })`);
  check('after the draft the player signs with the team that drafted him and starts an NFL season', r.ok && r.team && r.lvl === 'nfl' && r.phase === 'nfl' && r.bonus && r.yrs === 4, JSON.stringify(r));
  check('the NFL schedule gives every team 17 games and one bye, with no team playing twice in a week', r.games && r.byes && !r.dupWeek, JSON.stringify(r));
});
sec('nfl seasons', () => {
  const c = makeContext();
  const r = run(c, `${toDraft('WR', 4, 202)} nflStart(); const seasons = [];
    for (let y = 0; y < 4; y++) {
      let g = 0; while (cs.phase === 'nfl' && g++ < 40) cSimWeek();
      const L = cs.nfl.L; const po = L.games.filter(x => x.type === 'po');
      seasons.push({ y: L.year, po: po.length, champ: !!L.champ, seeds: L.seeds.AFC.length + L.seeds.NFC.length, phase: cs.phase, gp: cs.p.seasons[cs.p.seasons.length - 1].gp, reg: cs.p.seasons[cs.p.seasons.length - 1].gp <= 17, steps: cs.off && cs.off.steps.join(',') });
      let k = 0; while (cs.phase === 'nfloff' && k++ < 12) { if (offStep() === 'nmoney' && cs.nfl.fa && !cs.nfl.fa.done) { if (cs.nfl.fa.offers.length) nflSign(0); else nflRetire('none'); continue; } offNext(); }
    }
    ({ seasons, age: cs.nfl.age, yrs: cs.nfl.yrs, earn: cs.nfl.earn > 0, phase: cs.phase })`);
  const s = r.seasons;
  check('NFL seasons run 18 weeks, seed 14 playoff teams, play 13 playoff games and crown a champion', s.every(x => x.po === 13 && x.champ && x.seeds === 14), JSON.stringify(s));
  check('regular-season stats count at most 17 games (playoffs are kept apart)', s.every(x => x.reg), s.map(x => x.gp).join(','));
  check('each NFL offseason runs review, contract and training, then a new season; the player ages and gets paid', s.every(x => x.steps === 'nreview,nmoney,ntrain') && r.yrs === 4 && r.earn && (r.phase === 'nfl' || r.phase === 'retired'), JSON.stringify(r).slice(0, 300));
});
sec('nfl contracts', () => {
  const c = makeContext();
  const r = run(c, `${toDraft('DE', 5, 303)} nflStart(); let g = 0; while (cs.phase === 'nfl' && g++ < 40) cSimWeek(); offNext();
    const step = offStep(); const before = cs.nfl.tm;
    // free agency: force the contract to end and open the market
    cs.nfl.contract.left = 0; cs.nfl.contract.opt = false; cs.nfl.moneyDone = null; nflMoneyStep();
    const F = cs.nfl.fa; const nOffers = F.offers.length; const blocked = !!offBlocked(); const w = nflFAWait();
    const pickI = F.offers.findIndex(o => o.tm !== before); const o = F.offers[pickI]; const signed = nflSign(pickI);
    const after = { tm: cs.nfl.tm, apy: cs.nfl.contract.apy, trust: cs.p.trust, unblocked: !offBlocked() };
    // trade request and extension can each be asked once
    cs.nfl.asked = null; const t1 = nflRequestTrade(); const t2 = nflRequestTrade();
    cs.nfl.asked = null; cs.nfl.contract.left = 1; const e1 = nflAskExtension(); const e2 = nflAskExtension();
    ({ step, nOffers, blocked, waited: Array.isArray(w), signed, moved: after.tm === o.tm && after.tm !== before, apy: after.apy === o.apy, trust: after.trust === 50, unblocked: after.unblocked, t1: !!t1, t2: t2 === null, e1: !!e1, e2: e2 === null })`);
  check('free agency opens with offers, blocks the offseason until he signs, and signing moves him and his contract', r.step === 'nmoney' && r.nOffers >= 1 && r.blocked && r.waited && r.signed && r.moved && r.apy && r.trust && r.unblocked, JSON.stringify(r));
  check('a trade request and an extension request can each be made once an offseason', r.t1 && r.t2 && r.e1 && r.e2, JSON.stringify(r));
});
sec('nfl aging and retirement', () => {
  const c = makeContext();
  const r = run(c, `${toDraft('RB', 4, 404)} nflStart(); const ovr = []; let k = 0;
    while (cs.phase !== 'retired' && k++ < 25) {
      let g = 0; while (cs.phase === 'nfl' && g++ < 40) cSimWeek(); ovr.push(cs.nfl.age + ':' + cOvr(cs.p));
      let s = 0; while (cs.phase === 'nfloff' && s++ < 12) { if (cs.nfl.age >= 33) { nflRetire('age'); break; } if (offStep() === 'nmoney' && cs.nfl.fa && !cs.nfl.fa.done) { if (cs.nfl.fa.offers.length) nflSign(0); else if (cs.nfl.fa.round < 3) nflFAWait(); else nflRetire('none'); continue; } offNext(); }
    }
    const R = cs.nfl.retired; const peak = Math.max(...ovr.map(x => +x.split(':')[1])); const last = +ovr[ovr.length - 1].split(':')[1];
    const saved = JSON.parse(JSON.stringify(cs)); let valid = 'ok'; try { cValidate(saved); } catch (e) { valid = e.message; }
    ({ ovr: ovr.join(' '), retired: cs.phase === 'retired', verdict: R && R.verdict, hof: R && R.hof, declined: last < peak, valid })`);
  check('a running back peaks and then declines with age', r.declined, r.ovr);
  check('retirement ends the career with a Hall of Fame verdict, and the save still validates', r.retired && typeof r.verdict === 'string' && r.hof >= 0 && r.valid === 'ok', JSON.stringify(r));
});
sec('old career saves', () => {
  for (const f of ['v7career_done.json', 'v6career_col.json']) {
    const p = path.join(FIX, f); if (!fs.existsSync(p)) continue; const c = makeContext();
    const r = run(c, `(() => { try { cAdopt(JSON.parse(${JSON.stringify(fs.readFileSync(p, 'utf8'))})); const was = cs.phase; if (cs.phase === 'done') { nflStart(); let g = 0; while (cs.phase === 'nfl' && g++ < 40) cSimWeek(); } return { was, phase: cs.phase, lvl: cs.lvl }; } catch (e) { return { err: e.message }; } })()`);
    check(`an older career save (${f}) loads${/done/.test(f) ? ' and continues into the NFL' : ''}`, !r.err && (r.was !== 'done' || (r.lvl === 'nfl' && r.phase === 'nfloff')), JSON.stringify(r));
  }
});
sec('nfl save round trip', () => {
  const c = makeContext();
  const r = run(c, `${toDraft('CB', 3, 505)} nflStart(); for (let i = 0; i < 5; i++) cSimWeek(); const txt = JSON.stringify(cs); const copy = JSON.parse(txt);
    let res = 'ok'; try { cAdopt(copy); } catch (e) { res = e.message; } const back = JSON.stringify(cs) === txt || cs.week === JSON.parse(txt).week;
    const broken = JSON.parse(txt); broken.nfl.tm = 'XYZ'; let rej = false; try { cValidate(broken); } catch (e) { rej = true; }
    ({ res, back, rej })`);
  check('an NFL career saves and loads, and a damaged NFL record is rejected', r.res === 'ok' && r.back && r.rej, JSON.stringify(r));
});

out.forEach(l => console.log(l));
console.log(`\n${pass} passed, ${fail} failed`);
process.exitCode = fail ? 1 : 0;
