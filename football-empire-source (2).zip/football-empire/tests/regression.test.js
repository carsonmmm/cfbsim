// v7 regression checks: one or more deterministic checks for every bug fixed from the
// "full diagnostic report" (GPT-B1..B10, GPT-I5..I7, GPT-I9, CL-01..CL-28, CL-B1..CL-B12).
// Engine-level only (Node VM, no browser). Screen-level fixes are covered in
// tests/regression.browser.test.js.
//   node tests/regression.test.js [sourceDir]      (default: ../src next to tests/)
const fs = require('fs'), path = require('path'), vm = require('vm');
const dir = path.resolve(process.argv[2] || ['src', 'v7'].map(d => path.join(__dirname, '..', d)).find(d => fs.existsSync(path.join(d, 'career.js'))));
const AD_FILES = ['data.js', 'core.js', 'features.js', 'systems.js', 'storage.js', 'coach.js', 'career.js', 'nfl.js', 'pro.js'];
const ALL_FILES = AD_FILES.filter(f => f !== 'pro.js').concat(['cgame.js', 'pro.js']);

function makeContext(files, opts) {
  opts = opts || {};
  const store = new Map(); let blocked = false;
  const localStorage = {
    getItem: k => (store.has(k) ? store.get(k) : null),
    setItem: (k, v) => { if (blocked) throw new Error('QuotaExceededError'); store.set(k, String(v)); },
    removeItem: k => store.delete(k), clear: () => store.clear(),
  };
  const noop = () => {};
  const win = { addEventListener: noop };
  if (opts.gzip) { win.CompressionStream = CompressionStream; win.DecompressionStream = DecompressionStream; }
  const ctx = {
    console, setTimeout, clearTimeout, performance, Promise, JSON, Math, Date, Blob, Response, CompressionStream, DecompressionStream,
    localStorage, window: win, document: { addEventListener: noop, getElementById: () => null, visibilityState: 'visible' },
    btoa: s => Buffer.from(s, 'binary').toString('base64'), atob: s => Buffer.from(s, 'base64').toString('binary'),
    escape, unescape, ui: {}, applyTheme: noop, render: noop,
  };
  vm.createContext(ctx);
  vm.runInContext(files.map(f => fs.readFileSync(path.join(dir, f), 'utf8')).join('\n'), ctx, { filename: 'engine' });
  ctx.__store = store; ctx.__block = b => { blocked = b; };
  return ctx;
}
const run = (ctx, code) => vm.runInContext('{' + code + '\n}', ctx);
const runAsync = (ctx, code) => vm.runInContext('(async () => {' + code + '\n})()', ctx);

let pass = 0, fail = 0; const results = [];
function check(id, name, cond, detail) { (cond ? pass++ : fail++); results.push(`${cond ? 'PASS' : 'FAIL'}  [${id}] ${name}${detail != null && detail !== '' ? '  (' + detail + ')' : ''}`); }
async function sec(id, fn) { try { await fn(); } catch (e) { fail++; results.push(`FAIL  [${id}] section error: ${String(e && e.stack || e).split('\n').slice(0, 2).join(' / ')}`); } }

// A seeded career played forward with simple choices (GPT-I9 makes this repeatable).
const PLAY = `function playTo(stop) { let g = 0; while (cs.phase !== 'done' && g++ < 300) {
    const r = cSimUntil(stop || null, { events: true, spend: true }); const s = offStep();
    if (r === 'stop') return 'stop';
    if (cs.phase === 'sign' || s === 'signing') { const o = offersList().sort((a, b) => teamLevel(b.id) - teamLevel(a.id)); signWith(o[0].id); continue; }
    if (s === 'draft') { declareDraft(draftProjection() >= 88 || outOfEligibility()); continue; }
    if (r === 'choice') return 'choice'; } return cs.phase; }`;

(async () => {
  // ====================== Player Career save safety ======================
  await sec('GPT-B1', async () => {
    const c = makeContext(ALL_FILES, { gzip: true });
    const r = await runAsync(c, `newCareer({ pos: 'QB', first: 'A', last: 'B', num: 1, home: 'MI', path: 'hs', diff: 'normal', seed: 11 }); cslot = 1;
      cs.p.bank = 10; cSave(); const chain = cFlush();       // compressed write of bank 10 now in flight
      cs.p.bank = 20; cSave(); cFlushSync();                  // page-hide: bank 20 written synchronously
      await chain; await new Promise(r => setTimeout(r, 30)); await cFlush();
      const saved = JSON.parse(await gunz(localStorage.getItem(CSLOT_KEY(1))));
      return saved.p.bank;`);
    check('GPT-B1', 'an in-flight older career save never overwrites a newer page-hide save', r === 20, 'stored bank ' + r);
  });
  await sec('GPT-B2', async () => {
    const c = makeContext(ALL_FILES);
    const r = await runAsync(c, `newCareer({ pos: 'WR', first: 'Good', last: 'Career', num: 1, home: 'MI', path: 'hs', diff: 'normal', seed: 3 }); cslot = 1; await cSaveNow();
      const good = cs; const rng = RNG.s;
      const bad = [{ p: { pos: 'QB' }, league: {} }, Object.assign(JSON.parse(JSON.stringify(cs)), { phase: 'nonsense' }), Object.assign(JSON.parse(JSON.stringify(cs)), { league: { teams: {} } })];
      const outs = bad.map(b => { try { cAdopt(b); return 'adopted'; } catch (e) { return cs === good && RNG.s === rng ? 'restored' : 'corrupted'; } });
      // a failure while settling an unfinished game is also rolled back
      const unfinished = JSON.parse(JSON.stringify(cs)); unfinished.liveWk = unfinished.week; unfinished.liveRng = 5;
      const orig = cFinishGame; cFinishGame = () => { throw new Error('boom'); };
      let settle; try { cAdopt(unfinished); settle = 'adopted'; } catch (e) { settle = cs === good && RNG.s === rng ? 'restored' : 'corrupted'; }
      cFinishGame = orig;
      localStorage.setItem(CSLOT_KEY(2), 'RAW:' + JSON.stringify(bad[0])); const ld = await cLoadSlot(2);
      return { outs, settle, ld: ld.ok, slot: cslot, name: cs.p.first };`);
    check('GPT-B2', 'damaged careers are rejected and the working career, slot and RNG are restored', r.outs.every(x => x === 'restored') && r.settle === 'restored' && !r.ld && r.slot === 1 && r.name === 'Good', JSON.stringify(r));
  });
  await sec('GPT-B3', async () => {
    const c = makeContext(ALL_FILES);
    run(c, `newCareer({ pos: 'RB', first: 'A', last: 'B', num: 1, home: 'MI', path: 'hs', diff: 'normal', seed: 4 }); cslot = 1;`);
    c.__block(true);
    const r1 = await runAsync(c, `const ok = await cSaveNow(); return { ok, failed: cSaveFailed() };`);
    c.__block(false);
    const r2 = await runAsync(c, `const ok = await cSaveNow(); return { ok, failed: cSaveFailed(), stored: !!localStorage.getItem(CSLOT_KEY(1)) };`);
    check('GPT-B3', 'a refused career save reports failure, stays flagged, and succeeds on retry', !r1.ok && r1.failed && r2.ok && !r2.failed && r2.stored, JSON.stringify([r1, r2]));
  });
  await sec('GPT-B4', async () => {
    const c = makeContext(ALL_FILES);
    const r = await runAsync(c, `newCareer({ pos: 'CB', first: 'A', last: 'B', num: 1, home: 'MI', path: 'hs', diff: 'normal', seed: 5 }); cslot = 1;
      cs.rng = 12345; rngOwner = 'ad'; RNG.s = 999; cSave(); await cFlush();
      const saved = JSON.parse(await gunz(localStorage.getItem(CSLOT_KEY(1)))); rngOwner = 'career'; return saved.rng;`);
    check('GPT-B4', 'saving the career while AD owns the random stream keeps the career\'s own RNG', r === 12345, 'saved rng ' + r);
  });
  await sec('GPT-I2', async () => {
    const c = makeContext(ALL_FILES);
    const r = await runAsync(c, `newCareer({ pos: 'TE', first: 'Code', last: 'Test', num: 1, home: 'MI', path: 'hs', diff: 'normal', seed: 6 }); cslot = 1;
      const code = await cMakeCode(); const back = await cReadCode(code); let adCode = 'n/a'; try { await cReadCode('MFAD0:abc'); } catch (e) { adCode = e.message; }
      return { prefix: code.slice(0, 4), same: back.p.first === 'Code', adCode };`);
    check('GPT-I2', 'career save codes round-trip and refuse AD codes', r.prefix === 'MFPC' && r.same && /MFPC/.test(r.adCode), JSON.stringify(r));
  });

  await sec('old career saves', () => {
    const FIX = path.join(__dirname, 'fixtures'); const out = [];
    for (const f of ['v6career_hs.json', 'v6career_col.json']) {
      if (!fs.existsSync(path.join(FIX, f))) { out.push(f + ' missing'); continue; }
      const c = makeContext(ALL_FILES); c.__json = fs.readFileSync(path.join(FIX, f), 'utf8');
      out.push(f + ': ' + run(c, PLAY + `const before = JSON.parse(__json); cAdopt(before); const name = cs.p.first; const ph = cs.phase;
        cs.p.auto = true; playTo(); [name, ph, cs.phase, cs.v, cs.col ? typeof cs.col.gs : 'n/a'].join('/')`));
    }
    check('migration', 'v6 Player Career saves (high school and college) load and play to the end', out.every(x => /Old\/.*\/done\/2\/number/.test(x)), out.join(' | '));
  });
  // ====================== correctness ======================
  await sec('GPT-B5', async () => {
    const c = makeContext(ALL_FILES);
    const r = run(c, `newCareer({ pos: 'RB', first: 'A', last: 'B', num: 1, home: 'MI', path: 'hs', diff: 'normal', seed: 7 });
      cs.p.inj = 1; cs.p.injName = 'Ankle sprain'; cs.p.injFresh = true; // as set at the final whistle
      cEndWeek(); const afterSameWeek = cs.p.inj;
      const rec = cSimWeek(); ({ afterSameWeek, missed: !rec || rec.role === 'Not playing', healed: cs.p.inj })`);
    check('GPT-B5', 'a one-week injury from the final whistle misses the next game, then heals', r.afterSameWeek === 1 && r.missed && r.healed === 0, JSON.stringify(r));
  });
  await sec('GPT-B7', () => {
    const c = makeContext(AD_FILES);
    const r = run(c, `newGame('normal', null, 3); while (state.roster.length > MIN_ROSTER) state.roster.pop(); rebuildPMap(); POS_ORDER.forEach(p => state.depth[p] = state.depth[p].filter(id => P(id)));
      const refused = !releasePlayer(state.roster[0].id) && state.roster.length === MIN_ROSTER;
      const small = JSON.parse(JSON.stringify(state)); small.roster = small.roster.slice(0, 30); let ok = true; try { adoptState(small); } catch (e) { ok = e.message; }
      ({ refused, ok, n: state.roster.length })`);
    check('GPT-B7', 'releases stop at the roster floor, and a small saved roster loads and is refilled', r.refused && r.ok === true && r.n >= 45, JSON.stringify(r));
  });
  await sec('GPT-B8', () => {
    const c = makeContext(AD_FILES);
    const r = run(c, `newGame('normal', null, 5); let n = 0; while (state.week < 12 && n++ < 30) advance();
      state.deals = (state.deals || []).concat([{ id: 'perf', name: 'Test partner', perf: true, thru: state.season + 1, amt: 1 }]);
      state.games.push({ id: 'fakecfp', type: 'cfp', h: 'MICH', a: 'OSU', done: true, hs: 30, as: 10, mResult: 'W', wk: 15 });
      state.phase = 'cfp1'; startOffseason(); ({ review: state.off.review.fin.net, now: finTotals().net })`);
    check('GPT-B8', 'the season review and history use money after year-end bonuses post', Math.abs(r.review - r.now) < 1e-9, JSON.stringify(r));
  });
  await sec('GPT-B10', () => {
    const c = makeContext(AD_FILES);
    const r = run(c, `const dups = []; for (const seed of [1, 2, 3, 4, 5, 6]) { newGame('normal', null, seed); Object.keys(state.teams).forEach(id => { const f = state.games.filter(g => g.h === id || g.a === id).map(g => g.h === id ? g.a : g.h).filter(isFCS); if (new Set(f).size !== f.length) dups.push(seed + ':' + id); }); } dups`);
    check('GPT-B10', 'no team plays the same FCS opponent twice (6 seeds, every team)', r.length === 0, r.slice(0, 5).join(','));
  });
  await sec('GPT-I6', () => {
    const c = makeContext(AD_FILES);
    const r = run(c, `newGame('normal', null, 8); state.rec.otherScores = null; const s0 = RNG.s; const a = classRank(state.rec.list.slice(0, 20)); const s1 = RNG.s; state.rec.otherScores = null; const b = classRank(state.rec.list.slice(0, 20)); ({ same: a === b, rngUntouched: s0 === s1 && RNG.s === s0 })`);
    check('GPT-I6', 'ranking a recruiting class (as the Recruiting screen does) never draws random numbers', r.same && r.rngUntouched, JSON.stringify(r));
  });
  await sec('GPT-I7', () => {
    const c = makeContext(AD_FILES);
    const r = run(c, `newGame('normal', null, 9); const early = (() => { const n = state.roster.length; signingDay(); return state.roster.length === n && !state.rec.done; })();
      autoSeasonRecruiting(); let n = 0; while (state.phase !== 'offseason' && n++ < 40) advance(); const h = state.history.length; startOffseason(); const h2 = state.history.length;
      let g = 0; while (state.off.step < 5 && g++ < 10) { if (state.off.step === 2) autoHire(); offStepNext(); }
      signingDay(); const n1 = state.roster.length; signingDay(); ({ early, onceOff: h2 === h, twice: state.roster.length === n1 })`);
    check('GPT-I7', 'signing day only runs once and only in the offseason; the offseason starts once', r.early && r.onceOff && r.twice, JSON.stringify(r));
  });
  await sec('GPT-I9', () => {
    const a = makeContext(ALL_FILES), b = makeContext(ALL_FILES);
    const go = c => run(c, `newCareer({ pos: 'LB', first: 'S', last: 'D', num: 1, home: 'TX', path: 'hs', diff: 'normal', seed: 2026 }); cs.p.auto = true; cSimUntil(() => cs.phase === 'hsoff', { events: true, spend: true }); JSON.stringify([cs.p.a, cs.p.stars, cs.ss.games.map(g => g.us + '-' + g.them)])`);
    check('GPT-I9', 'a seeded career plays out identically', go(a) === go(b));
  });

  // ====================== Player Career awards, draft and stats ======================
  await sec('CL-01/02', () => {
    const c = makeContext(ALL_FILES);
    const r = run(c, `const ss = { gp: 12, gs: 0, st: { att: 22 } }; const st = { gp: 12, gs: 12, st: { att: 380 } }; const thin = { gp: 12, gs: 12, st: { att: 60 } };
      newCareer({ pos: 'QB', first: 'A', last: 'B', num: 1, home: 'MI', path: 'college', stars: 5, diff: 'normal', seed: 12 }); signWith(offersList()[0].id);
      const p = cs.p; cs.col.best = 1.3; cs.col.gs = 0; const benchProj = draftProjection(); cs.col.gs = 30; const starterProj = draftProjection();
      ({ backup: starterSeason(ss, 'QB'), starter: starterSeason(st, 'QB'), thin: starterSeason(thin, 'QB'), benchProj, starterProj })`);
    check('CL-01', 'a backup (0 starts) or a low-volume starter is not an award-eligible season', !r.backup && r.starter && !r.thin, JSON.stringify(r));
    check('CL-02', 'no career starts costs about eight points of draft stock', Math.abs((r.starterProj - r.benchProj) - 8.4) < 0.11, `${r.benchProj} vs ${r.starterProj}`);
  });
  await sec('CL-01/02/03 sims', () => {
    const bench = [], caps = [], heis = []; let r1Bench = 0;
    const CAP = { CB: { tfl: 12, sack: 6, dint: 9, pbu: 28 }, LB: { tfl: 26, dint: 7, pbu: 10 }, DE: { ff: 6, sack: 22 }, S: { dint: 12 } };
    for (let k = 0; k < 24; k++) {
      const c = makeContext(ALL_FILES); const pos = ['CB', 'LB', 'DE', 'S', 'QB', 'WR'][k % 6];
      const r = run(c, PLAY + `newCareer({ pos: '${pos}', first: 'A', last: 'B' + ${k}, num: 1, home: 'MI', path: '${k % 2 ? 'college' : 'hs'}', stars: ${3 + (k % 3)}, diff: 'normal', seed: ${100 + k} }); cs.p.auto = true; playTo();
        ({ seasons: cs.p.seasons.filter(s => s.lvl === 'col').map(s => ({ gs: s.gs, gp: s.gp, st: s.st, aw: s.awards.filter(a => !/champion/i.test(a)) })), draft: cs.done && cs.done.draft, gs: cs.col ? cs.col.gs : 0 })`);
      r.seasons.forEach(s => {
        if (s.gs < 5 && s.aw.length) bench.push(pos + ' gs' + s.gs + ' ' + s.aw.join('/'));
        const cp = CAP[pos]; if (cp) Object.keys(cp).forEach(st => { if ((s.st[st] || 0) > cp[st]) caps.push(`${pos} ${st} ${s.st[st]} (gs ${s.gs})`); });
        if (pos === 'DE' && s.gs < 5 && (s.st.ff || 0) > 2) caps.push(`backup DE ff ${s.st.ff}`);
      });
      if (r.draft && r.draft.round === 1 && r.gs < 12) r1Bench++;
    }
    check('CL-01', 'no college honors in seasons with fewer than 5 starts (24 careers)', bench.length === 0, bench.slice(0, 4).join('; '));
    check('CL-02', 'nobody with fewer than 12 career starts goes in round 1 (24 careers)', r1Bench === 0, r1Bench + '');
    check('CL-03', 'defensive season lines stay inside realistic caps (24 careers)', caps.length === 0, caps.slice(0, 5).join('; '));
  });
  await sec('CL-04', () => {
    // Several seeds, so a different random path (new schools, towns, rivals) can't flip the verdict on one unlucky draw.
    const runs = [1, 2, 3, 4, 5, 6, 7, 8].map(seed => { const c = makeContext(AD_FILES);
      return run(c, `newGame('normal', null, ${seed}); const ovr = []; for (let y = 0; y < 6; y++) { autoSeasonRecruiting(); let n = 0; while (state.phase !== 'offseason' && !state.gameOver && n++ < 40) advance(); ovr.push(+michStrength().ovr.toFixed(1)); if (state.gameOver) break; autoOffseason(); } ovr`); });
    const late = runs.map(r => Math.max(...r.slice(3))).sort((a, b) => a - b), top = Math.max(...runs.flat());
    check('CL-04', 'sustained autopilot recruiting lifts Michigan to 85+ within 6 seasons in most careers, never to a permanent 95', late.filter(x => x >= 85).length >= 5 && top < 93, runs.map(r => r.join(' ')).join(' | '));
  });

  // ====================== minor bugs (engine side) ======================
  await sec('CL-06/07', () => {
    const c = makeContext(ALL_FILES);
    const r = run(c, `newCareer({ pos: 'WR', first: 'A', last: 'B', num: 1, home: 'MI', path: 'hs', diff: 'normal', seed: 21 }); cs.p.auto = true;
      cSimUntil(() => cs.phase === 'hsoff' && cs.hs.cls >= 2, { events: true, spend: true });
      const kind = canVisitKind(); const tid = Object.keys(cs.rec.schools).find(t => canVisit(t) === 'official');
      const v1 = doVisit(tid); const again = canVisit(tid); ({ kind, first: v1 && v1.kind, again })`);
    check('CL-06', 'one official visit per school', r.first === 'official' && r.again === 'done', JSON.stringify(r));
    check('CL-07', 'visits after the junior season are official ones', r.kind === 'official');
  });
  await sec('CL-08', () => {
    const c = makeContext(ALL_FILES);
    const r = run(c, `newCareer({ pos: 'QB', first: 'A', last: 'B', num: 1, home: 'MI', path: 'hs', diff: 'normal', seed: 22 }); const g = cStartGame(); const bad = []; const clocks = [];
      const secs = k => (k.qtr - 1) * 900 + (900 - (+k.clock.split(':')[0] * 60 + +k.clock.split(':')[1]));
      let guard = 0; while (!g.done && guard++ < 400) { if (g.pending) { const board = cgBoardClock(g); const d = g.pending.clk; clocks.push(d.qtr + ' ' + d.clock); if (board.qtr && secs(d) < secs(board)) bad.push(board.qtr + ' ' + board.clock + ' > ' + d.clock); cgChoose(g, autoPick(g, g.pending)); } else cgStep(g); }
      ({ bad, first: clocks[0], distinct: new Set(clocks).size, n: clocks.length })`);
    check('CL-08', 'a decision\'s clock never runs behind the scoreboard, and clocks vary', r.bad.length === 0 && r.first !== '1 15:00' && r.distinct === r.n, JSON.stringify(r));
  });
  await sec('CL-10', () => {
    const c = makeContext(ALL_FILES);
    const r = run(c, `[tpl('You fill downhill and stuff him. {y}.', { y: 0 }), tpl('The receiver locks you up. {y}-yard run.', { y: -1 }), tpl('He sits down in front of you. {y}-yard catch.', { y: 9 }), tpl('{y} more yards', { y: 1 })]`);
    check('CL-10', 'play text: sentences start with a capital, a loss reads as a loss', r[0] === 'You fill downhill and stuff him. No gain.' && r[1] === 'The receiver locks you up. 1-yard loss.' && r[2] === 'He sits down in front of you. 9-yard catch.' && r[3] === '1 more yard', JSON.stringify(r));
  });
  await sec('CL-12/B2', () => {
    const c = makeContext(ALL_FILES);
    const r = run(c, `newCareer({ pos: 'WR', first: 'A', last: 'B', num: 1, home: 'MI', path: 'hs', diff: 'normal', seed: 23 });
      const base = { decN: 0, decOk: 0, share: 0.2, ratio: 0.1 };
      const noLine = gameGradeRatio(Object.assign({}, base, { line: {} }));
      const tinyLow = gameGradeRatio(Object.assign({}, base, { line: { tgt: 1 } }));
      const tinyHigh = gameGradeRatio(Object.assign({}, base, { ratio: 3, line: { tgt: 2, rec: 2, recyd: 16, rectd: 1 } }));
      const decFloor = gameGradeRatio({ decN: 8, decOk: 6, share: 1, ratio: 0.4, line: { tgt: 6, rec: 3, recyd: 20 } });
      cs.p.pos = 'DE'; const de = gameGradeRatio({ decN: 8, decOk: 5, share: 1, ratio: 0.55, line: { tkl: 4, hur: 2 } });
      ({ noLine, tinyLow, tinyHigh, decFloor, de: gradeOf(de)[1] })`);
    check('CL-12', 'no stat line means no grade; a few snaps grade C to B only', r.noLine === null && r.tinyLow >= 0.75 && r.tinyHigh <= 1.24, JSON.stringify(r));
    check('CL-B2', 'snap decisions count toward the grade, with a floor for a strong decision game', r.decFloor >= 0.75 && ['C', 'B', 'A'].includes(r.de), JSON.stringify(r));
  });
  await sec('CL-14', () => {
    const src = fs.readFileSync(path.join(dir, 'career.js'), 'utf8');
    check('CL-14', 'the dead injury expression is gone', !/p\.inj > 12 \? 0 : 0/.test(src));
  });
  await sec('CL-16', () => {
    const c = makeContext(ALL_FILES);
    const r = run(c, `[aAn('ankle sprain'), aAn('hamstring strain'), lastName('Darnell Moore Jr.'), lastName('Cole Smith III'), lastName('Ty Oden')]`);
    check('CL-16', 'a/an picks the right article', r[0] === 'an ankle sprain' && r[1] === 'a hamstring strain', r.slice(0, 2).join(', '));
    check('CL-22', 'last names keep their suffix', r[2] === 'Moore Jr.' && r[3] === 'Smith III' && r[4] === 'Oden', r.slice(2).join(', '));
    const src = fs.readFileSync(path.join(dir, 'career.js'), 'utf8');
    check('CL-16', 'champions read "Ohio State wins", not "win"', !/\} win the \$\{e\.year\} national championship/.test(src) && /wins the \$\{e\.year\} national championship/.test(src));
  });
  await sec('CL-17', () => {
    const c = makeContext(AD_FILES);
    const r = run(c, `newGame('normal', null, 4); state.meters.board = 46; autoSeasonRecruiting(); let n = 0; while (state.phase !== 'offseason' && n++ < 40) advance(); const rv = state.off.review; ({ before: rv.boardBefore, after: rv.boardAfter, delta: rv.delta })`);
    check('CL-17', 'the recap\'s board change is the real change', r.after - r.before === r.delta, JSON.stringify(r));
  });
  await sec('CL-20', () => {
    const src = fs.readFileSync(path.join(dir, 'app.js'), 'utf8');
    const m = src.match(/const clean = (v => .*?\.trim\(\));/); const clean = m ? eval(m[1]) : null;
    check('CL-20', 'custom names have markup stripped, and a stray "<" doesn\'t eat the rest', !!clean && clean('<b>Zeta</b> Tech') === 'Zeta Tech' && clean('Texas <3 Tech') === 'Texas 3 Tech', clean ? clean('<b>Zeta</b> Tech') + ' | ' + clean('Texas <3 Tech') : 'not found');
  });

  // ====================== balance ======================
  await sec('CL-B1', () => {
    const stars = [];
    for (let k = 0; k < 32; k++) {
      const c = makeContext(ALL_FILES);
      stars.push(run(c, PLAY + `newCareer({ pos: ['QB','RB','WR','TE','CB','DE','LB','S'][${k} % 8], first: 'A', last: 'B', num: 1, home: 'MI', path: 'hs', diff: 'normal', seed: ${300 + k} }); cs.p.auto = true;
        playTo(() => cs.phase === 'sign' || offStep() === 'signing'); cs.p.stars`));
    }
    const mid = stars.filter(s => s === 3 || s === 4).length;
    check('CL-B1', 'auto-simmed HS careers still land mostly at 3-4 stars', mid / stars.length >= 0.85, [1, 2, 3, 4, 5].map(s => stars.filter(x => x === s).length).join('/'));
    // the same career twice; in one, the sophomore and junior seasons are dominant (ratio 2.3)
    const one = elite => { const c = makeContext(ALL_FILES); return run(c, `const orig = hsEndSeason; hsEndSeason = function () { if (${elite} && cs.hs.cls >= 1 && cs.ss.expImp) cs.ss.gImp = cs.ss.expImp * 2.3; return orig(); };
      newCareer({ pos: 'QB', first: 'A', last: 'B', num: 1, home: 'MI', path: 'hs', diff: 'normal', seed: 77 }); cs.p.auto = true;
      cSimUntil(() => cs.phase === 'hsoff' && cs.hs.cls >= 2, { events: true, spend: true }); ({ score: recruitScore(), stars: cs.p.stars, aw: cs.p.awards.map(a => a.a).join('/') })`); };
    const base = one(false), star = one(true);
    check('CL-B1', 'two dominant high school seasons are worth at least a full star band (+5 score)', star.score - base.score >= 5, `${base.score} (${base.stars}★) vs ${star.score} (${star.stars}★, ${star.aw})`);
  });
  await sec('CL-B3', () => {
    const t = { WR: [0, 0], TE: [0, 0] };
    for (let k = 0; k < 8; k++) {
      const c = makeContext(ALL_FILES); const pos = k % 2 ? 'TE' : 'WR';
      const r = run(c, PLAY + `newCareer({ pos: '${pos}', first: 'A', last: 'B', num: 1, home: 'MI', path: 'college', stars: 4, diff: 'normal', seed: ${400 + k} }); cs.p.auto = true; playTo(); cs.p.seasons.filter(s => s.lvl === 'col').reduce((a, s) => [a[0] + (s.st.rec || 0), a[1] + (s.st.tgt || 0)], [0, 0])`);
      t[pos][0] += r[0]; t[pos][1] += r[1];
    }
    const wr = t.WR[0] / t.WR[1], te = t.TE[0] / t.TE[1];
    check('CL-B3', 'catch rates: WR about 60-72%, TE about 65-78%', wr >= 0.58 && wr <= 0.74 && te >= 0.62 && te <= 0.8, `WR ${wr.toFixed(2)}, TE ${te.toFixed(2)}`);
  });
  await sec('CL-B4', () => {
    const c = makeContext(ALL_FILES);
    const r = run(c, `newCareer({ pos: 'QB', first: 'A', last: 'B', num: 1, home: 'MI', path: 'college', stars: 3, diff: 'normal', seed: 31 });
      const fr = depthOutlook(Object.keys(cs.league.teams).find(t => cs.league.teams[t].conf === 'MAC'), cs.year, 55);
      cs.lvl = 'col'; cs.col = { tid: 'MICH', gs: 0 }; cs.p.seasons.push({ lvl: 'col', gp: 12, gs: 0, st: {} }); cs.col.playRatio = 1.6; cs.col.lastRatio = null; const backup = transferScore();
      cs.p.seasons[cs.p.seasons.length - 1].gs = 12; cs.col.lastRatio = 1.6; const starter = transferScore();
      ({ fr: fr.k, backup, starter, bk: portalStarter() })`);
    check('CL-B4', 'a backup\'s portal stock sits well below a starter\'s with the same production', r.starter - r.backup >= 4, JSON.stringify(r));
    check('CL-B4', 'a low-rated high school QB is not "Could start right away" at a MAC school', r.fr !== 'start', r.fr);
  });
  await sec('CL-B5', () => {
    const c = makeContext(ALL_FILES);
    const r = run(c, `newCareer({ pos: 'QB', first: 'A', last: 'B', num: 1, home: 'MI', path: 'college', stars: 5, diff: 'normal', seed: 32 }); cs.p.bank = 1e7; const got = TRAIN.map(t => buyTraining(t.id)); got.filter(Boolean).length`);
    check('CL-B5', 'at most two training programs a year', r === 2, r + ' bought');
  });
  await sec('CL-B6', () => {
    let n = 0, tooSoon = 0, sample = '';
    for (const seed of [33, 34, 35]) {
      const c = makeContext(ALL_FILES);
      const r = run(c, `newCareer({ pos: 'RB', first: 'A', last: 'B', num: 1, home: 'MI', path: 'hs', diff: 'normal', seed: ${seed} }); cs.p.auto = true; const seen = []; let guard = 0;
        while (cs.phase !== 'done' && guard++ < 400) { const r = cSimUntil(null, { events: false, spend: true }); const s = offStep();
          if (r === 'event') { seen.push([cs.wkN || 0, cs.event.id]); cResolveEvent(0); continue; }
          if (cs.phase === 'sign' || s === 'signing') { signWith(offersList()[0].id); continue; }
          if (s === 'draft') { declareDraft(outOfEligibility() || cs.col.years >= 4); continue; }
          if (r === 'choice') break; }
        const last = {}; let soon = 0; seen.forEach(([t, id]) => { if (last[id] != null && t - last[id] < 12) soon++; last[id] = t; }); ({ n: seen.length, soon, ids: seen.map(x => x[1] + '@' + x[0]).slice(0, 8).join(' ') })`);
      n += r.n; tooSoon += r.soon; if (!sample) sample = r.ids;
    }
    check('CL-B6', 'the same event never returns within 12 game weeks, across season breaks (3 full careers)', tooSoon === 0 && n > 5, `${n} events, ${tooSoon} too soon; ${sample}`);
  });
  await sec('CL-B7/B9', () => {
    const c = makeContext(AD_FILES);
    const r = run(c, `let spec5 = 0; for (const seed of [6, 7, 8, 9]) { newGame('normal', null, seed); spec5 += state.rec.list.filter(x => ['K', 'P', 'LS'].includes(x.pos) && x.star > 3).length; } ({ spec5 })`);
    check('CL-B9', 'no 4- or 5-star kickers, punters or long snappers', r.spec5 === 0, r.spec5 + '');
    const src = fs.readFileSync(path.join(dir, 'features.js'), 'utf8');
    check('CL-B7', 'the autopilot\'s signing-day offers respect the 30-offer cap', /30 - state\.rec\.list\.filter\(r => r\.offered && r\.status === 'open'\)\.length/.test(src));
  });
  await sec('CL-B10', () => {
    const c = makeContext(AD_FILES);
    const r = run(c, `newGame('normal', null, 7); const mg = michGameThisWeek(state.week); const sim = createSim(mg, { live: true });
      const ms = mg.h === 'MICH' ? 0 : 1; for (let i = 0; i < 60; i++) { startPlayDrive(sim, ms, 1, '15:00', false); runPlay(sim, 'inside'); }
      sim.rbLoad`);
    const v = Object.values(r || {}).sort((a, b) => b - a);
    check('CL-B10', 'the lead back gets a breather after a heavy load (60 run calls)', v.length >= 2 && v[0] <= 45, JSON.stringify(v));
  });
  await sec('CL-B11', () => {
    const c = makeContext(AD_FILES);
    const r = run(c, `const per = []; for (const seed of [1, 2, 3]) { newGame('normal', null, seed); let n = 0, k = 0; const weeks = []; while (state.phase === 'regular' && n++ < 20) { advance(); if (state.event && state.event.key === 'presser') { weeks.push(state.week); resolveEvent(0); } else if (state.event) resolveEvent(0); } per.push(weeks.length); } per`);
    check('CL-B11', 'press conferences are occasional (regular season, 3 seeds)', Math.max(...r) <= 5, r.join(', '));
  });
  await sec('CL-B12', () => {
    const c = makeContext(AD_FILES);
    const r = run(c, `const miss = []; for (const seed of [1, 2, 3]) { newGame('normal', null, seed); for (let y = 0; y < 2; y++) { autoSeasonRecruiting(); let n = 0; while (state.phase !== 'offseason' && !state.gameOver && n++ < 40) advance();
      const seeds = state.bracket ? state.bracket.seeds : []; Object.values(state.teams).forEach(t => { if (!(CONFS[t.conf].p4 || t.id === 'ND')) return; const gs = state.games.filter(g => g.done && (g.h === t.id || g.a === t.id) && (g.type === 'reg' || g.type === 'ccg')); const l = gs.filter(g => (g.h === t.id ? g.hs < g.as : g.as < g.hs)).length; if (l <= 1 && gs.length >= 12 && !seeds.includes(t.id)) miss.push(state.season + ' ' + t.id); });
      if (state.gameOver) break; autoOffseason(); } } miss`);
    check('CL-B12', 'power-conference teams with one loss or fewer always make the 12-team field (6 seasons)', r.length === 0, r.join(', '));
  });
  await sec('GPT-I5', async () => {
    const src = fs.readFileSync(path.join(dir, 'capp.js'), 'utf8');
    check('GPT-I5', 'long career sims run week by week, yield to the browser and can be stopped', /async function cSimTo/.test(src) && /await new Promise\(r => setTimeout\(r, 0\)\)/.test(src) && /csimstop\(\)/.test(src));
  });

  console.log(results.join('\n'));
  console.log(`\n${pass} passed, ${fail} failed`);
  process.exit(fail ? 1 : 0);
})();
