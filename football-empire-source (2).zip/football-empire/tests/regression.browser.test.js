// v7 screen-level regression checks in headless Chromium, one or more per fixed issue from the
// full diagnostic report (the engine-level ones are in tests/regression.test.js).
//   NODE_PATH=$(npm root -g) node tests/regression.browser.test.js [path/to/game.html]
const { chromium } = require('playwright');
const path = require('path');
const { serveFile } = require('./serve');
const file = path.resolve(process.argv[2] || path.join(__dirname, '..', 'football-empire.html'));
let pass = 0, fail = 0; const out = [];
function check(id, name, cond, detail) { (cond ? pass++ : fail++); out.push(`${cond ? 'PASS' : 'FAIL'}  [${id}] ${name}${detail != null && detail !== '' ? '  (' + detail + ')' : ''}`); }
const sleep = ms => new Promise(r => setTimeout(r, ms));
let url;
async function fresh(browser, opts) {
  const ctx = await browser.newContext(opts || {});
  await ctx.addInitScript(() => { if (!localStorage.getItem('mfad-prefs')) localStorage.setItem('mfad-prefs', JSON.stringify({ seen: 1, liveSpeed: 3, anim: 'off' })); });
  const page = await ctx.newPage(); const errors = [];
  page.on('pageerror', e => errors.push(e.message)); page.on('console', m => { if (m.type() === 'error' && !/Failed to load resource|could not be loaded|not a Player Career/.test(m.text())) errors.push('console: ' + m.text()); });
  await page.goto(url); await page.waitForSelector('#view .modes');
  return { ctx, page, errors };
}
const goAD = async page => { await require('./serve').enterAD(page); };
const newPlayer = async (page, pos) => {
  await page.click('#view [data-act=gocareer]'); await page.waitForSelector('#cnewform');
  if (pos) await page.click(`[data-act=cform][data-k=pos][data-v=${pos}]`);
  await page.click('[data-act=cstart]'); await page.waitForFunction(() => cs && appMode === 'career');
};
async function sec(id, fn) { try { await fn(); } catch (e) { fail++; out.push(`FAIL  [${id}] section error: ${String(e.message).split('\n')[0]}`); } }

(async () => {
  url = await serveFile(file);
  const browser = await chromium.launch();
  const allErrors = [];

  // ---------- Player Career ----------
  await sec('GPT-B6', async () => {
    const { ctx, page, errors } = await fresh(browser);
    await newPlayer(page, 'WR');
    await page.evaluate(async () => { await cSaveNow(); });
    // copy the good career to slot 3, damage slots 1 and 2, then reload
    await page.evaluate(() => { cs = null; cq = null; localStorage.setItem('mfpc-slot-3', localStorage.getItem('mfpc-slot-1')); localStorage.setItem('mfpc-slot-1', 'RAW:{"broken":true}'); localStorage.setItem('mfpc-slot-2', 'RAW:not json'); localStorage.setItem('mfpc-active', '1'); });
    await page.reload(); await page.waitForSelector('#view .modes'); await page.click('#view [data-act=gocareer]');
    await page.waitForFunction(() => appMode === 'career' && cs);
    const r = await page.evaluate(() => ({ slot: cslot, flash: (document.querySelector('#view .flash') || {}).textContent || '', s1: !!localStorage.getItem('mfpc-slot-1'), s2: !!localStorage.getItem('mfpc-slot-2') }));
    await page.click('#tabs [data-tab=saves]');
    const dmg = await page.evaluate(() => [...document.querySelectorAll('.slotcard')].slice(1, 2).map(c => /may be damaged/.test(c.textContent))); // slot 2 has no summary left
    check('review', 'a damaged career slot is labeled as saved data, not "Empty slot"', dmg.every(Boolean), JSON.stringify(dmg));
    check('GPT-B6', 'career startup skips damaged slots, loads slot 3, reports 1 and 2 and keeps them', r.slot === 3 && /1, 2/.test(r.flash) && r.s1 && r.s2, JSON.stringify(r));
    allErrors.push(...errors); await ctx.close();
  });

  await sec('Career', async () => {
    const { ctx, page, errors } = await fresh(browser);
    await newPlayer(page, 'QB');
    await page.evaluate(() => { Object.keys(cs.p.a).forEach(k => cs.p.a[k] = 80); render(); }); // a starter, so every game has snap decisions
    // reviewer fix: a locked action during a paused game explains itself on the career screen
    await page.click('#hdr .btn.primary'); await page.waitForSelector('#cdec .evopt'); await page.keyboard.press('Escape'); await sleep(100);
    const lockMsg = await page.evaluate(() => { const b = document.createElement('button'); b.dataset.act = 'cload'; b.dataset.i = '2'; document.getElementById('view').appendChild(b); b.click(); return [...document.querySelectorAll('#view .flash')].map(x => x.textContent).join(' '); });
    check('review', 'a blocked action during a paused game shows "Finish the game first" in Player Career', /Finish the game first/.test(lockMsg), lockMsg.slice(0, 60));
    await page.click('#hdr .btn.primary'); await page.waitForSelector('#modal:not([hidden]) .cgame'); await page.evaluate(() => { cgAutoplay(cg); cgRun(); }); await page.waitForSelector('#cgdonebtn'); await page.click('#cgdonebtn');
    await page.evaluate(() => { if (cs.event) cResolveEvent(0); cui.flash = 'Welcome back.'; render(); });

    const f0 = await page.evaluate(() => document.querySelectorAll('#view > .flash').length);
    await page.click('#hdr .btn.primary'); await page.waitForSelector('#modal:not([hidden]) .cgame');
    const f1 = await page.evaluate(() => document.querySelectorAll('#view > .flash').length);
    check('CL-11', 'a notice disappears once the player does something else', f0 === 1 && f1 === 0, `${f0} -> ${f1}`);
    // CL-09 (Instant speed is set by the test prefs): your own result stays up after drives fly by
    await page.waitForSelector('#cdec .evopt'); await page.click('#cdec .evopt >> nth=0'); await sleep(150);
    const lp = await page.evaluate(() => { const g = cg; const el = document.querySelector('.lastplay'); return { mine: !!(el && el.classList.contains('me') && el.classList.contains('big')), pending: !!(g && (g.pending || g.done)) }; });
    check('CL-09', 'at Instant speed your own play\'s result is still shown when the next snap comes', lp.mine, JSON.stringify(lp));
    // CL-08: the decision clock is not behind the scoreboard
    const clk = await page.evaluate(() => { const dec = cg.pending; if (!dec) return null; const b = cgBoardClock(cg); const s = k => (k.qtr - 1) * 900 + 900 - (+k.clock.split(':')[0] * 60 + +k.clock.split(':')[1]); return { dec: dec.clk.qtr + ' ' + dec.clk.clock, board: b.qtr + ' ' + b.clock, ok: !b.qtr || s(dec.clk) >= s(b) }; });
    check('CL-08', 'the decision clock is at or after the scoreboard clock', !clk || clk.ok, JSON.stringify(clk));
    await page.evaluate(() => { cgAutoplay(cg); }); await page.evaluate(() => cgRun()); await page.waitForSelector('#cgdonebtn'); await page.click('#cgdonebtn');
    // CL-13: no Heisman target before college; GPT-B9: career sound toggle
    await page.click('#tabs [data-tab=settings]');
    const snd = await page.evaluate(() => { const b = document.querySelector('[data-act=csound][data-v=on]'); if (!b) return null; b.click(); return { set: cs.sound === true, on: soundOn() }; });
    check('GPT-B9', 'Player Career has its own sound setting, and it drives the sound check', snd && snd.set && snd.on, JSON.stringify(snd));
    const sfx = await page.evaluate(() => /sfx\('crowd'\)/.test(sfxFor.toString()));
    check('GPT-B9', 'the touchdown/takeaway sound uses a real effect', sfx);
    // GPT-I2: save code export and import with a confirm step, plus a save status line
    await page.click('#tabs [data-tab=saves]');
    const st = await page.evaluate(() => (document.getElementById('csavemsg') || {}).textContent || '');
    await page.click('[data-act=ccode]'); await page.waitForFunction(() => document.querySelector('#ccodeout') && document.querySelector('#ccodeout').value.startsWith('MFPC'));
    const code = await page.$eval('#ccodeout', el => el.value);
    await page.evaluate(() => { cs.p.bank = 4242; });
    await page.fill('#cimportbox', code); await page.click('[data-act=cask2][data-k=cimp]');
    const conf = await page.evaluate(() => !!document.querySelector('[data-act=cimport]'));
    await page.click('[data-act=cimport]'); await page.waitForFunction(() => !document.querySelector('[data-act=cimport]'));
    const back = await page.evaluate(() => cs.p.bank);
    check('GPT-I2', 'career save codes export, ask before replacing, and load', /Saved|slot/i.test(st) && conf && back !== 4242, `status "${st.slice(0, 30)}", confirm ${conf}, bank ${back}`);
    // CL-15: week wording
    const w = await page.evaluate(() => { const l = cs.lvl; cs.lvl = 'col'; const r = [weekPhrase(15), weekPhrase(3), weekPhrase(18)]; cs.lvl = l; return r; });
    check('CL-15', 'sim-button week wording', w[0] === 'the CFP first round' && w[1] === 'week 3' && w[2] === 'the national championship', w.join(' | '));
    // GPT-I5: a long sim shows Stop and can be stopped
    await page.click('#tabs [data-tab=home]');
    const stop = await page.evaluate(async () => { const p = cSimTo('signing'); let shown = !!document.getElementById('csimcancel'); for (let i = 0; i < 400 && !shown && cui.simming; i++) { await new Promise(r => setTimeout(r, 1)); shown = !!document.getElementById('csimcancel'); } if (shown) actions.csimstop(); await p; return { shown, cls: cs.hs ? cs.hs.cls : null, flash: [...document.querySelectorAll('#view .flash, #modal .flash')].map(x => x.textContent).join(' '), simming: !!cui.simming }; });
    check('GPT-I5', 'a long career sim yields with a Stop button and stops early', stop.shown && !stop.simming && /stopped/i.test(stop.flash), JSON.stringify(stop));
    allErrors.push(...errors); await ctx.close();
  });

  // ---------- AD Mode ----------
  await sec('AD', async () => {
    const { ctx, page, errors } = await fresh(browser);
    await goAD(page);
    // reviewer fix: AD keeps a save-failure banner on screen until a save lands
    await page.evaluate(async () => { window.__set = Storage.prototype.setItem; Storage.prototype.setItem = function () { throw new Error('QuotaExceededError'); }; save(); await flushSave(); await new Promise(r => setTimeout(r, 50)); });
    const ban1 = await page.evaluate(() => !!document.querySelector('#view [data-act=adretry]'));
    await page.evaluate(() => actions.tab({ tab: 'roster' })); const ban2 = await page.evaluate(() => !!document.querySelector('#view [data-act=adretry]'));
    await page.evaluate(() => { Storage.prototype.setItem = window.__set; }); await page.click('#view [data-act=adretry]'); await sleep(200);
    const ban3 = await page.evaluate(() => !!document.querySelector('#view [data-act=adretry]'));
    check('review', 'AD shows a lasting save-failure banner that clears after a successful retry', ban1 && ban2 && !ban3, JSON.stringify([ban1, ban2, ban3]));
    // CL-18: offseason steps are numbered once
    await page.evaluate(() => { autoSeasonRecruiting(); let n = 0; while (state.phase !== 'offseason' && n++ < 40) advance(); actions.tab({ tab: 'off' }); });
    const num = await page.evaluate(() => { const li = document.querySelector('.steps li'); return li ? getComputedStyle(li, '::before').content : 'none'; });
    check('CL-18', 'offseason steps carry one number, not two', num === 'none' || num === 'normal', num);
    // CL-B8: Office warns when no recruiting offers are out
    await page.evaluate(() => { state.rec.list.forEach(r => { r.offered = false; if (r.status === 'mc' || r.status === 'signed') r.status = 'open'; }); actions.tab({ tab: 'office' }); });
    const warn = await page.evaluate(() => /No recruiting offers are out/.test(document.getElementById('view').textContent));
    check('CL-B8', 'the Office warns before an empty recruiting class', warn);
    // CL-24: feedback messages
    await page.evaluate(() => { state.tryouts = 0; actions.tryouts(); });
    const fb = await page.evaluate(() => (document.querySelector('#view .flash') || {}).textContent || '');
    check('CL-24', 'holding open tryouts gives a message', /tryouts held/i.test(fb), fb.slice(0, 50));
    // CL-26: loading a save code asks first
    await page.click('#tabs [data-tab=file]');
    await page.click('#view [data-act=export]'); await page.waitForSelector('#exportbox');
    const code = await page.$eval('#exportbox', el => el.value);
    await page.fill('#importbox', code); await page.click('#view [data-act=askimport]');
    const asked = await page.evaluate(() => ({ btn: (document.querySelector('#view [data-act=import]') || {}).textContent || '', cancel: !!document.querySelector('#view [data-act=unconfirm]') }));
    check('CL-26', 'loading a save code asks for confirmation first', /Confirm: replace/.test(asked.btn) && asked.cancel, asked.btn);
    await page.click('#view [data-act=unconfirm]');
    // CL-23: depth chart slot label is not a bordered box
    await page.click('#tabs [data-tab=depth]').catch(async () => { await page.evaluate(() => actions.tab({ tab: 'depth' })); });
    const slotCss = await page.evaluate(() => { const el = document.querySelector('.depth .slot'); if (!el) return null; const cs = getComputedStyle(el); return { border: cs.borderTopWidth, over: el.scrollWidth > el.clientWidth + 1 }; });
    check('CL-23', 'depth chart role labels have no input-like box and fit their column', slotCss && slotCss.border === '0px' && !slotCss.over, JSON.stringify(slotCss));
    // CL-22: suffix names in the unit list
    const unit = await page.evaluate(() => { const p = state.roster.find(x => x.pos === 'S'); const old = p.n; p.n = 'Darnell Moore Jr.'; const d = state.depth.S; state.depth.S = [p.id].concat(d.filter(x => x !== p.id)); render(); const t = document.getElementById('view').textContent; p.n = old; state.depth.S = d; render(); return /Moore Jr\./.test(t) && !/S\s*Jr\., /.test(t); });
    check('CL-22', 'the depth unit list shows "Moore Jr.", not "Jr."', unit);
    // CL-25: play-calling header wording
    const spot = await page.evaluate(() => { const html = document.documentElement.innerHTML; return /'your own '/.test(html) && !/'own ' \+ ds\.yl/.test(html); });
    check('CL-25', 'the play-calling header says "your own 25", not "the own 25"', spot);
    // CL-27: a fired AD's Office shows the career-over state
    await page.evaluate(() => { state.gameOver = { reason: 'Test firing.' }; ui.overHide = true; actions.tab({ tab: 'office' }); });
    const over = await page.evaluate(() => ({ txt: /Your tenure has ended/.test(document.getElementById('view').textContent), desk: /Open the offseason desk/.test(document.getElementById('view').textContent) }));
    check('CL-27', 'after being fired, Office shows the career-over state', over.txt && !over.desk, JSON.stringify(over));
    allErrors.push(...errors); await ctx.close();
  });

  await sec('Custom program', async () => {
    const { ctx, page, errors } = await fresh(browser);
    await goAD(page);
    await page.click('#tabs [data-tab=file]'); await page.evaluate(() => window.scrollTo(0, 0));
    await page.evaluate(() => actions.slotnew({ i: '2' })); await page.waitForSelector('#nc-name, [data-act=ncmode]');
    await page.click('[data-act=ncmode][data-v=custom]'); await page.waitForSelector('#nc-name');
    await page.fill('#nc-name', '<b>Zeta</b> Tech'); await page.evaluate(() => window.scrollTo(0, 600));
    await page.click('[data-act=startcareer]'); await page.waitForFunction(() => state && state.me && ui.tab === 'office');
    await sleep(200);
    const r = await page.evaluate(() => ({ name: state.me.name, title: document.title, y: window.scrollY }));
    check('CL-20', 'markup typed into a custom name is stripped', r.name === 'Zeta Tech' && !/</.test(r.title), JSON.stringify(r));
    check('CL-21', 'starting a new career scrolls to the top', r.y === 0, 'scrollY ' + r.y);
    await page.evaluate(() => actions.tab({ tab: 'roster' }));
    const ro = await page.evaluate(() => /official 2026 roster/.test(document.getElementById('view').textContent));
    await page.evaluate(() => actions.tab({ tab: 'staff' }));
    const sf = await page.evaluate(() => /real 2026 staff/.test(document.getElementById('view').textContent));
    check('CL-19', 'a custom program doesn\'t claim the real Michigan roster or staff', !ro && !sf, JSON.stringify({ ro, sf }));
    allErrors.push(...errors); await ctx.close();
  });

  // ---------- phone header (CL-05) ----------
  await sec('CL-05', async () => {
    const { ctx, page, errors } = await fresh(browser, { viewport: { width: 390, height: 844 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true });
    await goAD(page); await sleep(200);
    const r = await page.evaluate(() => { const b = document.querySelector('#hdr .board'); const cells = [...b.querySelectorAll('.cell')]; const vw = document.documentElement.clientWidth; return { cells: cells.length, hidden: cells.filter(c => { const q = c.getBoundingClientRect(); return q.right > vw + 1 || q.left < -1; }).length, scroll: b.scrollWidth > b.clientWidth + 1, page: document.documentElement.scrollWidth > vw + 1 }; });
    check('CL-05', 'every header stat is visible on a 390 px phone, with no sideways scrolling', r.cells >= 4 && !r.hidden && !r.scroll && !r.page, JSON.stringify(r));
    allErrors.push(...errors); await ctx.close();
  });

  check('all', 'no page errors in these runs', !allErrors.length, allErrors.slice(0, 3).join(' | '));
  await browser.close();
  console.log(out.join('\n'));
  console.log(`\n${pass} passed, ${fail} failed`);
  process.exit(fail ? 1 : 0);
})().catch(e => { console.log(out.join('\n')); console.error(e); process.exit(2); });
