// Football Empire (v9) checks: Coach mode, the NFL front office (GM), NFL coaching, moves between
// college and the NFL, firing and new jobs, and automation. Runs the real engine files in a Node VM.
//   node tests/v9.test.js [sourceDir]
const fs = require('fs'), path = require('path'), vm = require('vm');
const dir = path.resolve(process.argv[2] || path.join(__dirname, '..', 'src'));
const FILES = ['data.js', 'core.js', 'features.js', 'systems.js', 'storage.js', 'coach.js', 'career.js', 'cgame.js', 'nfl.js', 'pro.js'];
function makeContext() {
  const store = new Map(); const noop = () => {};
  const ctx = {
    console, setTimeout, clearTimeout, performance, Promise, JSON, Math, Date, Blob, Response,
    localStorage: { getItem: k => (store.has(k) ? store.get(k) : null), setItem: (k, v) => store.set(k, String(v)), removeItem: k => store.delete(k), clear: () => store.clear() },
    window: { addEventListener: noop }, document: { addEventListener: noop, getElementById: () => null, querySelector: () => null, visibilityState: 'visible' },
    btoa: s => Buffer.from(s, 'binary').toString('base64'), atob: s => Buffer.from(s, 'base64').toString('binary'), escape, unescape, ui: {}, applyTheme: noop, render: noop, fm: x => '$' + x + 'M',
  };
  vm.createContext(ctx); vm.runInContext(FILES.map(f => fs.readFileSync(path.join(dir, f), 'utf8')).join('\n'), ctx, { filename: 'engine' });
  return ctx;
}
const run = (ctx, code) => vm.runInContext('{' + code + '\n}', ctx);
let pass = 0, fail = 0; const out = [];
function check(name, cond, detail) { (cond ? pass++ : fail++); out.push(`${cond ? 'PASS' : 'FAIL'}  ${name}${detail ? '  (' + detail + ')' : ''}`); }
function sec(name, fn) { try { fn(); } catch (e) { fail++; out.push(`FAIL  ${name}: section error: ${String(e.message).split('\n')[0]}`); } }
const seasonLoop = `let n = 0; while (state.phase !== 'offseason' && n++ < 40) advance();`;

// ---------------- the NFL as GM ----------------
sec('gm start', () => {
  const c = makeContext();
  const r = run(c, `newGame('normal', null, 101, 'MICH'); goPro('DET', { role: 'gm' });
    ({ lvl: state.lvl, me: ME, teams: Object.keys(state.teams).length, roster: state.roster.length, step: PS().off.step, phase: state.phase, room: capRoom(ME), dc: PS().dc.list.length, picks: PS().picks.filter(p => p.own === ME).length, colW: Object.keys(state.colW.teams).length, colSeason: state.colW.season, season: state.season })`);
  check('a GM career starts in the NFL offseason with 32 clubs, a full roster, cap room, a draft class and picks', r.lvl === 'nfl' && r.me === 'DET' && r.teams === 32 && r.roster >= 50 && r.step === 0 && r.phase === 'offseason' && r.room > 0 && r.dc >= 250 && r.picks >= 12, JSON.stringify(r));
  check('the college world waits in the same save, one season ahead of the NFL offseason', r.colW >= 130 && r.colSeason === r.season + 1, r.colSeason + ' vs ' + r.season);
});
sec('gm seasons', () => {
  const c = makeContext();
  const r = run(c, `newGame('normal', null, 102, 'MICH'); goPro('CLE', { role: 'gm' }); state.settings.noFire = true; const log = [];
    for (let y = 0; y < 4; y++) { proAutoOffseason(); const pays = NFL.map(t => capRoom(t.id)); const sizes = NFL.map(t => proRoster(t.id).length);
      log.push({ season: state.season, phase: state.phase, mine: state.roster.length, room: capRoom(ME), minRoom: Math.min(...pays), maxSize: Math.max(...sizes), minSize: Math.min(...sizes) });
      let n = 0; while (state.phase !== 'offseason' && n++ < 30) advance(); }
    const L = PS(); ({ log, hist: L.hist.length, champs: L.champs.length, games: state.games.filter(g => g.type === 'reg').length, starters: (() => { const st = []; NFL.forEach(t => { const l = proRoster(t.id); POS_ORDER.forEach(pos => l.filter(p => p.pos === pos).sort((a, b) => b.ovr - a.ovr).slice(0, START[pos]).forEach(p => st.push(p.ovr))); }); return st.reduce((s, v) => s + v, 0) / st.length; })() })`);
  check('four GM seasons play through: every offseason ends in a new season, every club 53 or fewer', r.log.every((x, i) => x.phase === 'regular' && x.season === 2026 + i && x.maxSize <= 53 && x.minSize >= 46 && x.mine <= 53), JSON.stringify(r.log.map(x => [x.season, x.mine, x.minSize, x.maxSize])));
  check('your club starts each season under the cap', r.log.every(x => x.room >= 0), r.log.map(x => x.room).join(','));
  check('a regular season is 272 games and each season is recorded', r.games === 272 && r.hist === 4 && r.champs >= 4, `${r.games} games, ${r.hist} seasons`);
  check('league talent stays steady over the years (starters average 72-80)', r.starters > 72 && r.starters < 80, r.starters.toFixed(1));
});
sec('gm moves', () => {
  const c = makeContext();
  const r = run(c, `newGame('normal', null, 103, 'MICH'); goPro('NYJ', { role: 'gm' }); proAutoOffseason();
    const L = PS(); const p = state.roster.filter(x => x.k && x.k.yrs >= 2 && !x.k.rk && x.k.base > 3).sort((a, b) => b.k.base - a.k.base)[0];
    const hit0 = capHit(p), room0 = capRoom(ME); const sv = restructure(p.id); const room1 = capRoom(ME);
    const q = state.roster.filter(x => x.k && x.k.bpy > 0.5 && x.k.yrs >= 2)[0]; const dead = deadIfCut(q); const cr = cutPlayer(q.id); const room2 = capRoom(ME);
    const inFA = L.fa.some(x => x.id === q.id);
    ({ sv, gain: +(room1 - room0).toFixed(2), dead, deadNow: deadNow(ME), cr, inFA, gone: !P(q.id), room2: +(room2 - room1).toFixed(2), saves: cr.saves })`);
  check('a restructure frees cap room this year', r.sv > 0 && Math.abs(r.gain - r.sv) < 0.05, JSON.stringify(r));
  check('releasing a player leaves his bonus as dead money and sends him to free agency', r.gone && r.inFA && r.deadNow >= r.dead - 0.01 && Math.abs(r.room2 - r.saves) < 0.05, JSON.stringify(r));
});
sec('trades', () => {
  const c = makeContext();
  const r = run(c, `newGame('normal', null, 104, 'MICH'); goPro('KC', { role: 'gm' }); proAutoOffseason();
    const L = PS(); const myFirst = L.picks.findIndex(p => p.own === ME && p.rd === 1); const theirSeventh = L.picks.findIndex(p => p.own === 'NYG' && p.rd === 7);
    const theirFirst = L.picks.findIndex(p => p.own === 'NYG' && p.rd === 1); const mySeventh = L.picks.findIndex(p => p.own === ME && p.rd === 7);
    const good = tradeCheck('NYG', { pl: [], pk: [myFirst] }, { pl: [], pk: [theirSeventh] }); const bad = tradeCheck('NYG', { pl: [], pk: [mySeventh] }, { pl: [], pk: [theirFirst] });
    const ex = tradeExec('NYG', { pl: [], pk: [myFirst] }, { pl: [], pk: [theirSeventh] });
    ({ good: good.ok, bad: bad.ok, why: bad.why, ex: ex.ok, own1: L.picks[myFirst].own, own7: L.picks[theirSeventh].own })`);
  check('clubs take a trade in their favor and turn down a lopsided one', r.good && !r.bad && /want about/.test(r.why), JSON.stringify(r));
  check('a done trade moves the picks', r.ex && r.own1 === 'NYG' && r.own7 === 'KC');
});
sec('draft', () => {
  const c = makeContext();
  const r = run(c, `newGame('normal', null, 105, 'MICH'); goPro('BUF', { role: 'gm' }); const L = PS();
    while (L.off.step < 4) proOffNext(); const D = L.draft; const st = draftRun(true); const mineNo = D.slots[D.cur].no; const own = D.slots[D.cur].own;
    const best = draftAvail().sort((a, b) => myDraftScore(b) - myDraftScore(a))[0]; draftPick(best.id); const got = state.roster.find(p => p.n === best.n && p.dr);
    const downs = (() => { draftRun(true); return D.done ? 0 : draftDownOffers().length; })();
    draftRun(false); const all = D.slots.every(s => s.pid); const mine = D.mine.length;
    ({ st, own, mineNo, got: !!got, k: got && got.k.rk, pick: got && got.dr.no, all, mine, downs, udfa: L.fa.filter(p => p.udfa).length })`);
  check('the draft stops on your pick, takes your choice on a rookie deal and finishes all 224 picks', r.st === 'mine' && r.own === 'BUF' && r.got && r.k && r.pick === r.mineNo && r.all && r.mine >= 6, JSON.stringify(r));
  check('undrafted rookies land in free agency', r.udfa > 10, r.udfa);
});
sec('free agency', () => {
  const c = makeContext();
  const r = run(c, `newGame('normal', null, 106, 'MICH'); goPro('CHI', { role: 'gm' }); const L = PS(); while (L.off.step < 3) proOffNext();
    const p = L.fa.filter(x => x.ask && x.ask.apy < capRoom(ME) - 2).sort((a, b) => b.ovr - a.ovr)[0]; const res = faOffer(p.id, p.ask.apy * 1.25, p.ask.yrs);
    proFaWave(); const signed = state.roster.some(x => x.id === p.id) || NFL.some(t => t.id !== ME && proRoster(t.id).some(x => x.id === p.id));
    const others = NFL.reduce((s, t) => s + (t.id === ME ? 0 : proRoster(t.id).filter(x => x.k && x.k.tot && x.k.yrs === x.k.tot).length), 0);
    ({ res, mine: state.roster.some(x => x.id === p.id), signed, wave: L.faWave, others })`);
  check('a strong free-agent offer lands the player, and other clubs sign players too', r.res === 'ok' && r.mine && r.wave === 1 && r.others > 20, JSON.stringify(r));
});
sec('hc input', () => {
  const c = makeContext();
  const r = run(c, `newGame('normal', null, 107, 'MICH'); goPro('DAL', { role: 'gm' }); const L = PS(); const w = L.hcIn; const rel0 = L.hcRel;
    proOffNext(); proOffNext(); if (w && w.pid) { const p = P(w.pid); signOwn(p, askFor(p, false).apy, 2, false); } proOffNext();
    ({ wish: w && w.k, rel0, rel1: L.hcRel, nextWish: L.hcIn && L.hcIn.k })`);
  check('the head coach asks for things and is pleased when you deliver', r.wish === 'keep' && r.rel1 > r.rel0 && r.nextWish === 'need', JSON.stringify(r));
});

// ---------------- moving between college and the NFL ----------------
sec('ad to gm and back', () => {
  const c = makeContext();
  const r = run(c, `newGame('normal', null, 108, 'IOWA'); execState().rep = 95; ${seasonLoop}
    const offers = (state.exec.offers || []).map(j => j.id); const gm = state.exec.offers.find(j => j.lvl === 'nfl'); const t = execTake(gm.id);
    const a = { lvl: state.lvl, me: ME, step: PS().off.step, col: state.colW.my };
    proAutoOffseason(); let k = 0; while (state.phase !== 'offseason' && k++ < 30) advance();
    PS().offers = [{ lvl: 'col', tid: 'OSU', role: 'AD', int: 90, id: 'col:OSU' }]; const t2 = execTake('col:OSU'); const need = collegeNeedsSeasons(); goCollegeNow();
    ({ offers, t, a, t2, need, lvl: state.lvl, me: ME, phase: state.phase, week: state.week, season: state.season, games: mGames().length, jobs: jobsLog().map(j => j.lvl + ':' + j.role) })`);
  check('a successful AD gets NFL GM calls and can take one in the same save', r.offers.some(x => x.startsWith('nfl:')) && r.t === 'done' && r.a.lvl === 'nfl' && r.a.step === 0 && r.a.col === 'IOWA', JSON.stringify(r.a));
  check('a GM can go back to college as an AD: the college world catches up and the new school starts its season', r.t2 === 'catchup' && r.need >= 1 && r.lvl === 'col' && r.me === 'OSU' && r.phase === 'regular' && r.week === 1 && r.games >= 12, JSON.stringify(r));
  check('the career log keeps both levels', r.jobs.join(',') === 'col:AD,nfl:GM,col:AD' || r.jobs.join(',').startsWith('col:AD,nfl:GM'), r.jobs.join(','));
});
sec('fired gm', () => {
  const c = makeContext();
  const r = run(c, `newGame('normal', null, 109, 'MICH'); goPro('NYG', { role: 'gm' }); proAutoOffseason(); let n = 0; while (state.phase !== 'offseason' && n++ < 30) advance();
    proAutoOffseason(); PS().gm.sec = -40; PS().gm.hired = 2000; n = 0; while (state.phase !== 'offseason' && n++ < 30) advance();
    const go = state.gameOver; const jobs = go.jobs; const nfl = jobs.filter(j => j.lvl === 'nfl' && j.int >= 40), col = jobs.filter(j => j.lvl === 'col' && j.int >= 40);
    const t = execTake(nfl[0].id); ({ fired: !!go, nfl: nfl.length, col: col.length, t, me: ME, over: !!state.gameOver, step: PS().off.step })`);
  check('a fired GM gets a list of open GM and AD jobs he can take', r.fired && r.nfl >= 2 && r.col >= 2, JSON.stringify(r));
  check('taking another GM job keeps the career going in the same offseason', r.t === 'done' && !r.over && r.me !== 'NYG' && r.step === 0, JSON.stringify(r));
});
sec('fired ad', () => {
  const c = makeContext();
  const r = run(c, `newGame('normal', null, 110, 'KU'); const f0 = DIFF.normal.fire; DIFF.normal.fire = 101; state.history.push({}); ${seasonLoop}
    DIFF.normal.fire = f0; const go = state.gameOver; const g = go.jobs.find(j => j.lvl === 'nfl' && j.int >= 40); const t = execTake(g.id); ({ jobs: go.jobs.length, t, lvl: state.lvl, over: !!state.gameOver })`);
  check('a fired AD can take an open GM job', r.jobs >= 8 && r.t === 'done' && r.lvl === 'nfl' && !r.over, JSON.stringify(r));
});

// ---------------- coaching in the NFL ----------------
sec('coach college to nfl and back', () => {
  const c = makeContext();
  const r = run(c, `newCoachCareer({ name: 'Pat Doe', start: 'any', tid: 'UGA', role: 'HC', diff: 'normal', gameDay: 'key', seed: 111 }); state.co.rep = 92; ${seasonLoop}
    const m = state.co.market; const nflJobs = m.open.filter(o => o.lvl === 'nfl').length; offStepNext();
    const job = m.open.find(o => o.lvl === 'nfl' && o.role === 'HC'); job.offer = job.offer || makeOffer(job.tid, 'HC', null, false, 'nfl'); acceptOffer(job.id); offStepNext();
    const a = { lvl: state.lvl, me: ME, role: state.co.role, mine: STAFF_ROLES.filter(x => state.staff[x] && state.staff[x].me).join(','), step: PS().off.step, sal: state.co.contract.sal };
    proAutoOffseason(); let k = 0; while (state.phase !== 'offseason' && k++ < 30) advance(); const h = state.co.hist[state.co.hist.length - 1];
    proOffNext(); const mk = state.co.market; const cj = mk.open.find(o => o.lvl === 'col' && o.role === 'HC'); cj.offer = makeOffer(cj.tid, 'HC', null, false, 'col'); acceptOffer(cj.id); const res = proOffNext(); goCollegeNow();
    ({ nflJobs, a, h: h && (h.lvl + ':' + h.role), lvl: state.lvl, me: ME, target: cj.tid, role: state.co.role, mine: STAFF_ROLES.filter(x => state.staff[x] && state.staff[x].me).join(','), phase: state.phase, nflSchools: state.co.schools.filter(s => s.startsWith('nfl:')).length })`);
  check('a winning college coach hears from NFL clubs and can take an NFL head coaching job', r.nflJobs > 5 && r.a.lvl === 'nfl' && r.a.role === 'HC' && r.a.mine === 'HC' && r.a.step === 2 && r.a.sal > 5, JSON.stringify(r.a));
  check('an NFL season goes on the coaching record', r.h === 'nfl:HC', r.h);
  check('an NFL coach can take a college job and arrives for the next season', r.lvl === 'col' && r.me === r.target && r.role === 'HC' && r.mine === 'HC' && r.phase === 'regular' && r.nflSchools === 1, JSON.stringify(r));
});
sec('coach starts in nfl', () => {
  const c = makeContext();
  const r = run(c, `newCoachCareer({ name: 'Al Ray', start: 'any', tid: 'MICH', role: 'DC', diff: 'normal', gameDay: 'all', seed: 112, lvl: 'nfl', nfl: 'SF' });
    const a = { lvl: state.lvl, me: ME, role: state.co.role, mine: STAFF_ROLES.filter(x => state.staff[x] && state.staff[x].me).join(','), kind: state.kind };
    const L = PS(); const target = state.roster.find(p => DEF_POS.includes(p.pos) && underContract(p)); const off = state.roster.find(p => OFF_POS.includes(p.pos) && underContract(p));
    const t1 = cinToggle('cut', target.id, target.pos), t2 = cinToggle('cut', off.id, off.pos);
    proAutoOffseason(); let n = 0; while (state.phase !== 'offseason' && n++ < 30) advance();
    ({ a, t1, t2, season: state.season, hist: state.co.hist.length, review: !!state.co.review, market: !!state.co.market, w: gmWeight() })`);
  check('Coach mode can start on an NFL staff', r.a.lvl === 'nfl' && r.a.me === 'SF' && r.a.role === 'DC' && r.a.mine === 'DC' && r.a.kind === 'coach', JSON.stringify(r.a));
  check('a coordinator can weigh in on his own side of the ball only', r.t1 === 'on' && r.t2 === 'role' && r.w > 0.3 && r.w < 0.8, JSON.stringify(r));
  check('an NFL coach gets a season review and a job market', r.hist === 1 && r.review && r.market, JSON.stringify(r));
});
sec('nfl game day', () => {
  const c = makeContext();
  const r = run(c, `newCoachCareer({ name: 'Al Ray', start: 'any', tid: 'MICH', role: 'HC', diff: 'normal', gameDay: 'all', seed: 113, lvl: 'nfl', nfl: 'GB' }); proAutoOffseason();
    const g = michGameThisWeek(state.week) || michGameThisWeek(state.week + 1); const sim = createSim(g, { live: true }); sim.callPlays = callsOff() && state.co.gameDay !== 'plan';
    let calls = 0, dcalls = 0, guard = 0; while (!sim.done && guard++ < 3000) { const p = sim.pending; if (!p) { simStep(sim); autoAdvance(sim); continue; }
      if (p.type === 'drive') { runPlay(sim, 'short'); calls++; } else if (p.type === 'ddrive') { runDefPlay(sim, 'base'); dcalls++; } else simResolve(sim, p.type === 'half' ? { off: null, def: null } : autoChoice(sim, p.drv)); autoAdvance(sim); }
    if (!sim.done) finishSim(sim); ({ done: g.done, calls, dcalls, score: [g.hs, g.as] })`);
  check('NFL games can be coached live, calling plays on both sides', r.done && r.calls > 10 && r.dcalls > 10, JSON.stringify(r));
});

// ---------------- saves ----------------
sec('nfl saves', () => {
  const c = makeContext();
  const r = run(c, `newGame('normal', null, 114, 'MICH'); goPro('PHI', { role: 'gm' }); proAutoOffseason(); advance(); const snap = JSON.stringify(state); const before = { me: ME, wk: state.week, n: state.roster.length };
    newGame('normal', null, 1, 'OSU'); const ok = adoptState(JSON.parse(snap)); const after = { me: ME, wk: state.week, n: state.roster.length, lvl: state.lvl, b1g: CONFS.B1G.teams.length, conf: T(ME).conf };
    const bad = JSON.parse(snap); delete bad.colW; let rej = false; try { adoptState(bad); } catch (e) { rej = /college world/.test(e.message); }
    const bad2 = JSON.parse(snap); bad2.pro.rost.KC = 'x'; let rej2 = false; try { adoptState(bad2); } catch (e) { rej2 = true; }
    ({ ok, before, after, rej, rej2, sum: slotSummary() })`);
  check('an NFL career saves and loads in the same place', r.ok && r.after.me === r.before.me && r.after.wk === r.before.wk && r.after.n === r.before.n && r.after.lvl === 'nfl' && r.after.conf === 'NFC' && r.after.b1g >= 17, JSON.stringify(r.after));
  check('a damaged NFL save is rejected', r.rej && r.rej2);
  check('the save slot shows the NFL club', r.sum.lvl === 'nfl' && /Eagles/.test(r.sum.name), JSON.stringify(r.sum));
});
sec('college saves untouched', () => {
  const c = makeContext();
  const r = run(c, `newGame('normal', null, 115, 'MICH'); advance(); const snap = JSON.parse(JSON.stringify(state)); delete snap.lvl; const ok = adoptState(snap); ({ ok, lvl: state.lvl || 'col', pro: isPro() })`);
  check('college saves without the new fields load as college saves', r.ok && r.lvl === 'col' && !r.pro);
});

// ---------------- automation ----------------
sec('ad automation', () => {
  const c = makeContext();
  const r = run(c, `newGame('normal', null, 116, 'TCU'); const A = autoSet(); ['rec', 'plan', 'depth', 'events', 'board', 'deals', 'staff', 'fac', 'pay'].forEach(k => A[k] = true);
    autoSeasonRecruiting(); ${seasonLoop} let guard = 0; const steps = []; while (state.phase === 'offseason' && guard++ < 20) { steps.push(state.off.step); if (!offStepNext()) break; }
    ({ phase: state.phase, steps: steps.join(','), hc: !!state.staff.HC, signed: state.roster.filter(p => p.recruit).length })`);
  check('with automation on, an AD offseason runs to the next season by just clicking Continue', r.phase === 'regular' && r.hc && r.signed > 5, JSON.stringify(r));
});
sec('auto recruiting', () => {
  const ranks = { auto: [], good: [] };
  for (const mode of ['auto', 'good']) for (const tid of ['IOWA', 'TCU', 'MICH']) for (const seed of [1, 2]) {
    const c = makeContext();
    ranks[mode].push(run(c, `newGame('normal', null, ${seed}, '${tid}'); if ('${mode}' === 'auto') autoSet().rec = true;
      const good = () => { const rc = state.rec; const open = rc.list.filter(r => r.status === 'open'); open.filter(r => r.offered && r.interest < 25 && state.week > 6).forEach(r => r.offered = false);
        const live = rc.list.filter(r => r.offered && r.status === 'open').length; const room = projRoom() - recCommits().length;
        open.filter(r => !r.offered).sort((a, b) => recOdds(b) * (b.star + 1) - recOdds(a) * (a.star + 1)).slice(0, Math.max(0, Math.min(30, room + 12) - live)).forEach(r => r.offered = true);
        const homes = state.games.filter(g => g.h === ME && !g.done && g.wk > state.week && g.type === 'reg');
        rc.list.filter(r => r.offered && r.status === 'open' && !r.visit).sort((a, b) => b.star * b.interest - a.star * a.interest).forEach(r => { const g = homes.find(g => rc.list.filter(x => x.visit === g.id).length < 4); if (g && rc.visits > 0) setVisit(r.id, g.id); }); };
      let n = 0; while (state.phase !== 'offseason' && n++ < 40) { if ('${mode}' === 'good') good(); advance(); }
      let g2 = 0; while (state.phase === 'offseason' && state.off.step < 5 && g2++ < 10) { if (state.off.step === 1) { autoBoard(); autoDeals(); } if (state.off.step === 2) autoHire(); offStepNext(); }
      if ('${mode}' === 'good') { const rc = state.rec; const room = rosterLimit() - state.roster.length; rc.list.filter(r => r.status === 'open').sort((a, b) => recOdds(b) * (b.star + 1) - recOdds(a) * (a.star + 1)).slice(0, Math.max(0, Math.min(room - recCommits().length + 10, 30 - rc.list.filter(r => r.offered && r.status === 'open').length))).forEach(r => r.offered = true); signingDay(); }
      else { runOffAutomation(); if (!state.rec.done) autoRecruitClose(); }
      state.rec.classRank`));
  }
  const avg = a => a.reduce((s, v) => s + v, 0) / a.length;
  check('auto-recruited classes rank about as well as a careful staff working the board by hand', avg(ranks.auto) <= avg(ranks.good) + 4, JSON.stringify(ranks));
});
sec('gm automation', () => {
  const c = makeContext();
  const r = run(c, `newGame('normal', null, 117, 'MICH'); goPro('LV', { role: 'gm' }); const A = autoSet(); ['resign', 'fa', 'draft', 'cuts', 'staff', 'scout'].forEach(k => A[k] = true);
    let guard = 0; while (state.phase === 'offseason' && guard++ < 20) { if (!proOffNext()) break; } ({ phase: state.phase, season: state.season, n: state.roster.length, room: capRoom(ME), drafted: (PS().tx || []).filter(t => /Drafted/.test(t.txt)).length })`);
  check('with automation on, a GM offseason runs to the next season by just clicking Continue', r.phase === 'regular' && r.season === 2026 && r.n <= 53 && r.room >= 0 && r.drafted >= 6, JSON.stringify(r));
});

// ---------------- diagnostic report fixes (B01-B07, B11, B13) ----------------
const asyncChecks = [];
asyncChecks.push(async () => {
  const c = makeContext();
  run(c, `globalThis.__rel = []; gz = s => new Promise(res => __rel.push(() => res('RAW:' + s)));
    globalThis.__q = makeSaveQueue({ key: i => 'tk' + i, metaKey: 'tkm', status: () => {} });
    __q.push(1, '{"bal":10}', {}); __q.flush(); __q.push(1, '{"bal":20}', {}); __q.flush(); __q.flushSync();`);
  const afterHide = run(c, `localStorage.getItem('tk1')`);
  run(c, `__rel.forEach(f => f());`); await new Promise(r => setTimeout(r, 20)); run(c, `__rel.forEach(f => f());`); await new Promise(r => setTimeout(r, 20));
  const final = run(c, `localStorage.getItem('tk1')`);
  check('B01: closing the page saves the newest snapshot even when it waits behind another write, and the older write never lands on top', afterHide === 'RAW:{"bal":20}' && final === 'RAW:{"bal":20}', afterHide + ' / ' + final);
});
sec('B02 coach nfl to college autopilot', () => {
  const c = makeContext();
  const r = run(c, `const bad = [];
    for (const [tid, role, seed] of [['CAR', 'OC', 8046], ['KC', 'QB', 8047], ['DAL', 'DC', 8048], ['SEA', 'WR', 8049]]) {
      newCoachCareer({ name: 'T', start: 'any', tid: 'UGA', role, diff: 'normal', gameDay: 'key', seed, lvl: 'nfl', nfl: tid }); state.settings.noFire = true; autoSet().market = true;
      try { for (let y = 0; y < 3; y++) { autoOffseason(); let n = 0; while (state.phase !== 'offseason' && n++ < 40) advance();
        // force a college offer so the move back is exercised
        if (isPro() && state.co.market) { const o = state.co.market.open.find(x => x.lvl === 'col' && ROLE_TIER[x.role] >= ROLE_TIER[state.co.role]); if (o) { o.int = 99; o.offer = makeOffer(o.tid, o.role, null, false, 'col'); state.co.rep = 99; } } }
        autoOffseason(); if (state.pendingArrive) bad.push(tid + ': pending'); if (state.phase !== 'regular') bad.push(tid + ': ' + state.phase);
      } catch (e) { bad.push(tid + ': ' + e.message); } }
    bad`);
  check('B02: Coach offseason autopilot survives moves from the NFL to college and lands in the next season', r.length === 0, r.join('; '));
});
sec('B03 assistant with no head coach', () => {
  const c = makeContext();
  const r = run(c, `newCoachCareer({ name: 'T', start: 'any', tid: 'BSU', role: 'WR', diff: 'normal', gameDay: 'key', seed: 8019 }); state.settings.noFire = true;
    let n = 0; while (state.phase !== 'offseason' && n++ < 40) advance(); offStepNext(); finishMarket(); state.staff.HC = null; state.co.contract.pool = 0; autoSet().rec = true;
    let g = 0; while (state.phase === 'offseason' && g++ < 12) { if (!offStepNext()) break; } ({ phase: state.phase, hc: !!state.staff.HC, me: state.staff.WR && state.staff.WR.me })`);
  check('B03: an assistant whose head coach is gone can still finish the offseason (the AD hires the head coach)', r.phase === 'regular' && r.hc && r.me, JSON.stringify(r));
});
sec('B04 pick ownership', () => {
  const c = makeContext();
  const r = run(c, `newGame('normal', null, 123, 'MICH'); goPro('DET', { role: 'gm' }); const L = PS(); while (L.off.step < 4) proOffNext();
    const mine = L.picks.findIndex(p => p.own === 'DET' && p.rd === 1 && p.yr === L.draft.yr); const theirs = L.picks.findIndex(p => p.own === 'KC' && p.rd === 7 && p.yr === L.draft.yr);
    const no1 = proPickNo(L.picks[mine]), no7 = proPickNo(L.picks[theirs]);
    const t = tradeExec('KC', { pl: [], pk: [mine] }, { pl: [], pk: [theirs] }, true);
    draftRun(false); const s1 = L.draft.slots.find(s => s.no === no1), s7 = L.draft.slots.find(s => s.no === no7);
    const counts = {}; L.draft.slots.forEach(s => counts[s.no] = (counts[s.no] || 0) + 1);
    ({ ok: t.ok, no1, no7, own1: s1.own, own7: s7.own, mineHas7: L.draft.mine.some(id => P(id) && P(id).dr.no === no7), mineHas1: L.draft.mine.some(id => P(id) && P(id).dr.no === no1), once: Object.values(counts).every(v => v === 1) && L.draft.slots.every(s => s.pid) })`);
  check('B04: a traded pick changes hands in the draft itself, and every pick is made exactly once', r.ok && r.own1 === 'KC' && r.own7 === 'DET' && r.mineHas7 && !r.mineHas1 && r.once, JSON.stringify(r));
});
sec('B05 cap on extensions', () => {
  const c = makeContext();
  const r = run(c, `newGame('normal', null, 123, 'MICH'); goPro('DET', { role: 'gm' }); proAutoOffseason(); const L = PS();
    const p = state.roster.filter(x => x.k && x.k.yrs >= 1 && !x.k.tag).sort((a, b) => b.ovr - a.ovr)[0]; const before = JSON.stringify(p.k); const room0 = capRoom(ME);
    const big = offerOwn(p.id, room0 + capHit(p) + 50, 3); const same = JSON.stringify(p.k) === before;
    p.k.base = r2(p.k.base + room0 + 10); const wk = state.week; const adv = proAdvance(); const blocked = state.week === wk;
    autoSet().cuts = true; proAdvance(); ({ big, same, adv, blocked, after: state.week, room: capRoom(ME) })`);
  check('B05: an extension that does not fit under the cap is refused without changing the contract', r.big === 'cap' && r.same, JSON.stringify(r));
  check('B05: a GM over the cap cannot play the next game (unless automatic cap fixes are on)', r.adv === false && r.blocked && r.room >= 0, JSON.stringify(r));
});
sec('B06 live lock', () => {
  const c = makeContext();
  const r = run(c, `newGame('normal', null, 124, 'MICH'); goPro('DET', { role: 'gm' }); proAutoOffseason(); state.liveWk = state.week;
    const qb = state.depth.QB[0]; const cut = cutPlayer(qb); const L = PS(); const pk = L.picks.findIndex(p => p.own === ME); const tr = tradeCheck('NYJ', { pl: [qb], pk: [] }, { pl: [], pk: [L.picks.findIndex(p => p.own === 'NYJ')] }, true);
    state.liveWk = null; ({ cut, still: !!P(qb), tr: tr.ok, why: tr.why })`);
  check('B06: no releases or trades while a live game is unfinished', r.cut === null && r.still && !r.tr && /live game/.test(r.why), JSON.stringify(r));
});
sec('B07 restructure', () => {
  const c = makeContext();
  const r = run(c, `newGame('normal', null, 125, 'MICH'); goPro('DET', { role: 'gm' }); proAutoOffseason();
    const p = state.roster.find(x => x.k && !x.k.rk); p.k = { base: 10, bpy: 2, yrs: 3, tot: 3, apy: 12 };
    const owed0 = owedLeft(p), hit0 = capHit(p), y1 = yearHit(p, 1); const sv = restructure(p.id); const owed1 = owedLeft(p), hit1 = capHit(p), y1b = yearHit(p, 1);
    ({ owed0, owed1, hit0, hit1, y1, y1b, sv })`);
  check('B07: a restructure lowers this year\'s cap hit, raises later years and keeps the total owed', r.hit1 < r.hit0 && r.y1b > r.y1 && Math.abs(r.owed1 - r.owed0) < 0.05 && Math.abs(r.sv - (r.hit0 - r.hit1)) < 0.05, JSON.stringify(r));
});
sec('B11 nfl depth offsets', () => {
  const c = makeContext();
  const r = run(c, `const src = String(nflRoster); ({ fixed: /\\[i\\] \\?\\? -12/.test(src) })`);
  check('B11: a zero depth offset is applied as zero, not as a 12-point penalty', r.fixed);
});
sec('B13 real players', () => {
  const c = makeContext();
  const r = run(c, `newCoachCareer({ name: 'T', start: 'any', tid: 'MICH', role: 'HC', diff: 'normal', gameDay: 'key', seed: 49001 }); const e = CO_EVENTS.find(x => x.id === 'discipline'); const real = [];
    for (let i = 0; i < 40; i++) { if (!e.cond()) break; const m = e.make(); const p = P(m.data.pid); if (p.real) real.push(p.n); }
    const keep = state.roster.slice(); state.roster.forEach(p => p.real = true); const none = !e.cond(); keep.forEach(p => p.real = false);
    ({ real, none })`);
  check('B13: the misconduct event never names a real player, and is skipped when there is no fictional starter', r.real.length === 0 && r.none, JSON.stringify(r));
});

// ---------------- diagnostic report fixes, round 2 (B08, B09, B12) ----------------
sec('B08 damaged offseason saves', () => {
  const c = makeContext();
  const r = run(c, `newCareer({ pos: 'WR', first: 'A', last: 'B', num: 1, home: 'OH', path: 'hs', stars: 3, diff: 'normal', pace: 'sim' });
    cSimUntil(() => cs.phase === 'hsoff', { events: true }); const good = JSON.parse(JSON.stringify(cs)); const before = cs.p.last;
    const tries = { empty: c => { c.off.steps = []; c.off.i = 0; }, unknown: c => { c.off.steps = ['review', 'bogus']; }, range: c => { c.off.i = 9; }, frac: c => { c.off.i = 0.5; }, mismatch: c => { c.phase = 'nfloff'; } };
    const out = {}; Object.entries(tries).forEach(([k, f]) => { const bad = JSON.parse(JSON.stringify(good)); f(bad); try { cAdopt(bad); out[k] = 'loaded'; } catch (e) { out[k] = 'rejected'; } });
    const ok = (() => { try { return cAdopt(JSON.parse(JSON.stringify(good))); } catch (e) { return e.message; } })();
    ({ phase: good.phase, out, ok, same: cs.p.last === before })`);
  check('B08: damaged Player Career offseason saves are rejected and the current career stays', r.phase === 'hsoff' && Object.values(r.out).every(v => v === 'rejected') && r.ok === true && r.same, JSON.stringify(r));
});
sec('B09 draft rounds', () => {
  const c = makeContext();
  const r = run(c, `const picks = [64, 65, 96, 97, 104, 105, 128, 129, 143, 144, 224, 225, 257]; const lab = picks.map(n => n + ':' + pickRound(n));
    newCareer({ pos: 'QB', first: 'A', last: 'B', num: 1, home: 'OH', path: 'college', stars: 4, diff: 'normal', pace: 'sim' }); cs.year = 2030;
    const t = projText(83); draftProjection = () => 83; const dr0 = draftRange; let mismatch = []; const seen = [];
    for (const pk of [64, 65, 104, 105, 138, 143, 144, 224, 225, 257]) { draftRange = () => [pk, pk]; cs.phase = 'coloff'; cs.done = null; const d = runDraft(); seen.push(d.pick + ':' + d.round); if (d.round !== pickRound(d.pick)) mismatch.push(d.pick + '/' + d.round); } draftRange = dr0;
    ({ lab, mismatch, t, seen })`);
  check('B09: Player Career draft results and projections use the shared round table', r.mismatch.length === 0 && r.lab.join(',') === '64:2,65:3,96:3,97:3,104:3,105:4,128:4,129:4,143:4,144:5,224:7,225:7,257:7' && /Round/.test(r.t), JSON.stringify(r));
});
sec('B12 coach event effects', () => {
  const c = makeContext();
  const r = run(c, `newCoachCareer({ name: 'T', start: 'any', tid: 'TCU', role: 'HC', diff: 'normal', gameDay: 'key', seed: 7 });
    const ev = CO_EVENTS.find(e => e.id === 'discipline'); const m = ev.make(); state.event = { key: 'coach:discipline', wk: 1, title: m.title, text: m.text, opts: m.opts, data: m.data };
    resolveCoachEvent(0); const p = P(m.data.pid); const g = michGameThisWeek(state.week); const marked = p.halfOut === g.id;
    const sim = createSim(g, {}); const outFirst = !avail(p); let n = 0; while (!sim.done && sim.i < sim.total / 2 && n++ < 100) simStep(sim);
    simStep(sim); const backSecond = avail(p); simRun(sim); const cleared = !p.halfOut && !p.sitNow;
    const pr = CO_EVENTS.find(e => e.id === 'practice').make(); state.event = { key: 'coach:practice', wk: 1, title: pr.title, text: pr.text, opts: pr.opts, data: pr.data }; resolveCoachEvent(0);
    const g2 = mGames().find(x => !x.done); const pads = state.padsWk && state.padsWk.gid === g2.id && state.padsWk.mode === 'off';
    const s1 = createSim(g2, {}); state.padsWk = null; const s0 = createSim(g2, {}); const weaker = s1.F[s1.mSide].off < s0.F[s0.mSide].off + 2.4 * 3;
    ({ marked, outFirst, backSecond, cleared, pads, offDiff: (s1.F[s1.mSide].off - s0.F[s0.mSide].off).toFixed(2), hint: m.opts[0].hint })`);
  check('B12: "Sit him for a half" benches the player for the first half of the next game, then he returns', r.marked && r.outFirst && r.backSecond && r.cleared, JSON.stringify(r));
  check('B12: "Pads off" is recorded for the next game and changes it', r.pads, JSON.stringify(r));
});
sec('B12 practice injuries', () => {
  const c = makeContext();
  const r = run(c, `newGame('normal', null, 9, 'TCU'); const g = mGames()[0]; const cnt = mode => { let n = 0; for (let i = 0; i < 300; i++) { state.roster.forEach(p => { p.inj = 0; p.injSE = false; }); state.padsWk = mode ? { gid: g.id, mode } : null; const before = state.news.length; rollInjuries(g); n += state.roster.filter(p => p.inj).length; } return n; };
    ({ off: cnt('off'), none: cnt(null), on: cnt('on') })`);
  check('B12: pads off means fewer injuries than normal, pads on means more', r.off < r.none && r.none < r.on, JSON.stringify(r));
});

// ---------------- round 3: schedule, career events, quality-of-life engine pieces ----------------
sec('D01 NFL schedule', () => {
  const c = makeContext();
  const r = run(c, `newGame('normal', null, 31, 'MICH'); goPro('DET', { role: 'gm' }); const bad = [], dbl = [];
    for (let y = 0; y < 8; y++) { const g = proSchedule(2026 + y); const per = {}; NFL.forEach(t => per[t.id] = { n: 0, home: 0, div: 0, opp: {} });
      g.forEach(x => { [x.h, x.a].forEach(id => { per[id].n++; if (x.div) per[id].div++; }); per[x.h].home++; const k = [x.h, x.a].sort().join(); per[x.h].opp[k] = (per[x.h].opp[k] || 0) + 1; });
      NFL.forEach(t => { const p = per[t.id]; if (p.n !== 17 || p.div !== 6 || p.home < 8 || p.home > 9) bad.push(2026 + y + t.id); });
      for (let wk = 1; wk <= 18; wk++) { const seen = new Set(); g.filter(x => x.wk === wk).forEach(x => [x.h, x.a].forEach(id => { if (seen.has(id)) dbl.push(wk + id); seen.add(id); })); }
      const divOk = g.filter(x => x.div).every(x => T(x.h).conf === T(x.a).conf && T(x.h).div === T(x.a).div); if (!divOk) bad.push('div' + y); }
    ({ bad, dbl })`);
  check('D01: eight NFL schedules: every club plays 17 games, 6 in its division, 8 or 9 at home, never twice in a week', r.bad.length === 0 && r.dbl.length === 0, JSON.stringify(r).slice(0, 200));
});
sec('D03 career readiness', () => {
  const c = makeContext();
  const r = run(c, `newCareer({ pos: 'RB', first: 'R', last: 'D', num: 2, home: 'TX', path: 'college', stars: 3, diff: 'normal', pace: 'sim' });
    const sore = CEVENTS.find(e => e.id === 'sore'); sore.opts[0][2](); const fresh = cs.p.ready; cEndWeek(); const cleared = cs.p.ready === undefined;
    const tiredOpts = CEVENTS.filter(e => e.opts.some(o => /higher injury risk/.test(o[1]))).length;
    ({ fresh, cleared, tiredOpts })`);
  check('D03: a Player Career rest choice lowers this week\'s injury risk and wears off after one week', r.fresh === 'fresh' && r.cleared && r.tiredOpts >= 2, JSON.stringify(r));
});
sec('QoL contracts', () => {
  const c = makeContext();
  const r = run(c, `newGame('normal', null, 103, 'MICH'); goPro('NYJ', { role: 'gm' }); proAutoOffseason();
    const p = state.roster.filter(x => x.k && x.k.yrs >= 3 && !x.k.rk && x.k.base > 3).sort((a, b) => b.k.base - a.k.base)[0];
    const pv = restructurePreview(p); const k0 = JSON.stringify(p.k); const same = JSON.stringify(p.k) === k0; const sv = restructure(p.id);
    const real = [0, 1, 2].map(i => yearHit(p, i)); const match = pv.yrs.slice(0, 3).every((y, i) => Math.abs(y.after - real[i]) < 0.011);
    const tot0 = pv.yrs.reduce((s, y) => s + y.before, 0), tot1 = pv.yrs.reduce((s, y) => s + y.after, 0);
    const q = state.roster.find(x => x.k && x.k.yrs === 1 && !x.k.rk && x.k.bpy > 0.3); const nk = q ? extendK(q.k, 5, 2) : null;
    ({ saved: pv.saved, sv, same, match, tot: +(tot1 - tot0).toFixed(2), later: pv.later, ext: nk ? +(nk.base + nk.bpy).toFixed(2) : null })`);
  check('QoL: the restructure preview matches what the restructure does, changes nothing by itself, and keeps the total the same', r.same && r.match && Math.abs(r.saved - r.sv) < 0.011 && Math.abs(r.tot) < 0.05 && r.later > 0, JSON.stringify(r));
  check('QoL: an extension preview gives the new yearly cap hit', r.ext == null || r.ext >= 4.9, JSON.stringify(r));
});
sec('QoL trades and blockers', () => {
  const c = makeContext();
  const r = run(c, `newGame('normal', null, 104, 'MICH'); goPro('KC', { role: 'gm' }); proAutoOffseason();
    const L = PS(); const mySeventh = L.picks.findIndex(p => p.own === ME && p.rd === 7); const theirFirst = L.picks.findIndex(p => p.own === 'NYG' && p.rd === 1);
    const no = tradeCheck('NYG', { pl: [], pk: [mySeventh] }, { pl: [], pk: [theirFirst] });
    const o = L.off; let n = 0; while (state.phase !== 'offseason' && n++ < 40) advance(); const off0 = offBlockers().length;
    state.settings.auto = Object.assign({}, state.settings.auto || {}, { cuts: false }); const o2 = PS().off; let g = 0; while (o2.step < 5 && g++ < 12) { if (!proOffNext()) { if (o2.step === 1) proAutoHireHC(); if (o2.step === 4) draftRun(false); } }
    for (let i = 0; state.roster.length <= 55 && i < 40; i++) addMine(Object.assign({}, state.roster[0], { id: 'x' + i, k: null }));
    const bl = offBlockers();
    ({ why: no.why, reasons: (no.reasons || []).length, ok: no.ok, off0, step: o2.step, bl, n: state.roster.length, ph: state.phase })`);
  check('QoL: a refused trade says why, using the club\'s own valuation', !r.ok && r.reasons >= 1 && /want about/.test(r.why), r.why);
  check('QoL: the offseason checklist names a roster over 53 and links to the Roster tab', r.step === 5 && r.bl.some(b => /Cut down/.test(b.txt) && b.tab === 'roster'), JSON.stringify({ bl: r.bl, step: r.step, n: r.n, ph: r.ph }));
});
sec('QoL college', () => {
  const c = makeContext();
  const r = run(c, `newGame('normal', null, 12, 'TCU'); ${seasonLoop}
    const b0 = offBlockers(); state.off.step = 1; const b1 = offBlockers(); const hc = state.staff.HC; state.off.step = 3; state.staff.HC = null; const b3 = offBlockers(); state.staff.HC = hc;
    state.off.step = 5; state.rec.done = false; const b5 = offBlockers();
    const w = recWhy(state.rec.list[0]);
    ({ b0: b0.length, b1: b1.map(x => x.txt), b3: b3.map(x => x.tab), b5: b5.map(x => x.txt), w })`);
  check('QoL: the college checklist names the board meeting, a missing head coach and signing day', r.b0 === 0 && /board/.test(r.b1.join()) && r.b3.includes('staff') && /Signing Day/.test(r.b5.join()), JSON.stringify(r));
  check('QoL: every prospect gets plain reasons for his interest', Array.isArray(r.w.pro) && Array.isArray(r.w.con) && r.w.pro.length + r.w.con.length > 0, JSON.stringify(r.w));
});
sec('QoL coach', () => {
  const c = makeContext();
  const r = run(c, `newCoachCareer({ name: 'T', start: 'any', tid: 'TCU', role: 'WR', diff: 'normal', gameDay: 'key', seed: 9 });
    const a = roleAuthority('WR', false), h = roleAuthority('HC', true);
    const co = state.co; ${seasonLoop}
    ({ a, h })`);
  check('QoL: the job card spells out what a position coach and an NFL head coach control', r.a.some(t => /recruit WR/.test(t)) && r.a.some(t => /develops/.test(t)) && r.h.some(t => /both sides/.test(t)) && r.h.some(t => /GM runs the roster/.test(t)), JSON.stringify(r));
});
sec('QoL save state text', () => {
  const c = makeContext();
  const r = run(c, `const a = saveStateTxt(); setSaveSt('saving'); const b = saveStateTxt(); setSaveSt('failed'); const d = saveStateTxt(); setSaveSt('saved'); const e = saveStateTxt(); ({ a, b, d, e })`);
  check('QoL: the header save indicator reads Saving, Saved with a time, or Not saved', r.b === 'Saving…' && /^Not saved/.test(r.d) && /^Saved \d/.test(r.e), JSON.stringify(r));
});

// ---------------- v9.4: per-year contracts, league rules ----------------
sec('v9.4 contracts', () => {
  const c = makeContext();
  const r = run(c, `newGame('normal', null, 141, 'MICH'); goPro('SEA', { role: 'gm' }); proAutoOffseason();
    const all = state.roster.concat(...NFL.filter(t => t.id !== ME).map(t => proRoster(t.id))).filter(p => p.k && p.k.yrs > 0);
    const shaped = all.every(p => kOk(p.k) && Math.abs(capHit(p) - yearHit(p, 0)) < 0.011);
    // an old-style contract (one base salary, a restructure's later salaries, one flat proration) converts without changing a cap hit
    const legacy = { base: 3, bpy: 1.5, yrs: 3, tot: 4, rk: false, apy: 6, later: [7, 8] }; const lp = { k: JSON.parse(JSON.stringify(legacy)) };
    const before = [0, 1, 2].map(i => yearHit(lp, i)), deadB = deadIfCut(lp); kFix(lp.k); const after = [0, 1, 2].map(i => yearHit(lp, i));
    // rollover uses up the first season
    const p = state.roster.filter(x => x.k && x.k.yrs >= 3).sort((a, b) => capHit(b) - capHit(a))[0]; const y1 = yearHit(p, 1), y2 = yearHit(p, 2);
    let n = 0; while (state.phase !== 'offseason' && n++ < 40) advance();
    const L = PS(); let g = 0; while (state.phase === 'offseason' && g++ < 12) { if (!proOffNext()) { if (L.off.step === 1) proAutoHireHC(); if (L.off.step === 4) draftRun(false); if (L.off.step === 5) { trimRoster(ME, proMax()); capFix(ME); } } }
    const stillHere = P(p.id); const rolled = stillHere ? [yearHit(stillHere, 0), yearHit(stillHere, 1)] : null;
    // shapes: back-loaded rises, front-loaded falls, both pay the same total
    const back = mkContract(10, 4, 0.2, false, 'back'), front = mkContract(10, 4, 0.2, false, 'front'), flat = mkContract(10, 4, 0.2);
    const tot = k => k.sal.reduce((s, x) => s + x, 0) + k.pr.reduce((s, x) => s + x, 0);
    const ext = extendK(flat, 12, 2, 'back');
    ({ shaped, before, after, deadB, deadA: deadIfCut(lp), legacyGone: !lp.k.later, y1, y2, rolled, backUp: back.sal[3] > back.sal[0], frontDown: front.sal[3] < front.sal[0], tots: [tot(back), tot(front), tot(flat)].map(x => +x.toFixed(1)), ext: { yrs: ext.yrs, first: +(ext.sal[0] + ext.pr[0]).toFixed(2), last: +(ext.sal[5] + ext.pr[5]).toFixed(2), shape: ext.shape } })`);
  check('v9.4: every contract in the league stores a salary and a bonus charge for each season left', r.shaped, JSON.stringify(r).slice(0, 200));
  check('v9.4: an old save\'s contract converts without changing any cap hit or dead money', JSON.stringify(r.before) === JSON.stringify(r.after) && r.deadA === r.deadB && r.legacyGone, JSON.stringify(r));
  check('v9.4: at the new league year each deal moves on one season', !r.rolled || (Math.abs(r.rolled[0] - r.y1) < 0.011 && Math.abs(r.rolled[1] - r.y2) < 0.011), JSON.stringify(r));
  check('v9.4: back-loaded deals rise, front-loaded deals fall, and both cost the same in total', r.backUp && r.frontDown && Math.abs(r.tots[0] - r.tots[2]) < 0.2 && Math.abs(r.tots[1] - r.tots[2]) < 0.2, JSON.stringify(r.tots));
  check('v9.4: a back-loaded extension starts below and ends above its yearly average', r.ext.yrs === 6 && r.ext.first < 12 && r.ext.last > 12 && r.ext.shape === 'back', JSON.stringify(r.ext));
});
sec('v9.4 rules', () => {
  const c = makeContext();
  const r = run(c, `newGame('normal', null, 151, 'MICH'); const fresh = rulePreset();
    const old = JSON.parse(JSON.stringify(state)); delete old.settings.rules; migrate(old); const oldR = old.settings.rules.otNfl;
    setRulePreset('hardcore'); const hard = rulePreset(); const h = rules(); const fire = diff().fire, neg = diff().neg;
    setRule('injuries', 'normal'); const custom = rulePreset(); setRule('security', 'never'); const nf = state.settings.noFire; setRule('security', 'patient'); const nf2 = state.settings.noFire; const pf = diff().fire;
    setRule('cfp', '16'); const cfp = state.settings.playoff.size;
    state.settings.rules.injuries = 'low'; const lo = injRuleF(); state.settings.rules.injuries = 'high'; const hi = injRuleF();
    ({ fresh, oldR, hard, h, fire, neg, custom, nf, nf2, pf, cfp, lo, hi })`);
  check('v9.4: new careers start on Realistic rules; saves from before keep Classic (how they played)', r.fresh === 'realistic' && r.oldR === 'college', JSON.stringify(r));
  check('v9.4: presets set every rule, and changing one makes a custom mix', r.hard === 'hardcore' && r.h.nflSeeds === 6 && r.h.capGrow === 3 && r.custom === 'custom', JSON.stringify(r));
  check('v9.4: job security and injury rules reach the engine', r.fire === 14 && r.neg === 1.2 && r.nf === true && r.nf2 === false && r.pf === 4 && r.cfp === 16 && r.lo < 1 && r.hi > 1, JSON.stringify(r));
});
sec('v9.4 overtime', () => {
  const c = makeContext();
  const r = run(c, `newGame('normal', null, 161, 'MICH'); goPro('DAL', { role: 'gm' }); proAutoOffseason(); const g0 = state.games.find(g => g.wk === 1 && g.h !== ME && g.a !== ME);
    const out = {}; for (const rule of ['college', 'nfl', 'sudden']) { state.settings.rules.otNfl = rule; const o = { ot: 0, odd: 0, one: 0, ties: 0 }; for (let i = 0; i < 700; i++) { const sim = createSim(Object.assign({}, g0, { done: false }), {}); simRun(sim); if (sim.pts[0] === sim.pts[1]) o.ties++; if (sim.otTurn) { o.ot++; if (sim.otTurn % 2) o.odd++; if (sim.otTurn === 1) o.one++; } } out[rule] = o; }
    out`);
  check('v9.4: overtime follows the rule: college ends after a full round, NFL gives both teams the ball, sudden death can end on the first drive', r.college.ot > 10 && r.college.odd === 0 && r.nfl.one === 0 && r.sudden.one > 0 && !r.college.ties && !r.nfl.ties && !r.sudden.ties, JSON.stringify(r));
});
sec('v9.4 six seeds', () => {
  const c = makeContext();
  const r = run(c, `newGame('normal', null, 171, 'MICH'); goPro('GB', { role: 'gm' }); state.settings.noFire = true; state.settings.rules.nflSeeds = 6; proAutoOffseason();
    let n = 0; while (state.week <= 18 && n++ < 30) advance(); const L = PS().lg; const wc = state.games.filter(g => g.wk === 19).length; const seeds = L.seeds.AFC.length;
    while (!L.champ && n++ < 60) advance(); const div = state.games.filter(g => g.wk === 20); const byesIn = ['AFC', 'NFC'].every(cf => div.some(g => g.h === L.seeds[cf][0] || g.a === L.seeds[cf][0]) && div.some(g => g.h === L.seeds[cf][1] || g.a === L.seeds[cf][1]));
    ({ wc, seeds, div: div.length, byesIn, champ: !!L.champ })`);
  check('v9.4: with six playoff teams a conference, the top two seeds get byes and the bracket still crowns a champion', r.wc === 4 && r.seeds === 6 && r.div === 4 && r.byesIn && r.champ, JSON.stringify(r));
});
sec('v9.4 cap growth', () => {
  const c = makeContext();
  const r = run(c, `newGame('normal', null, 181, 'MICH'); goPro('MIA', { role: 'gm' }); const y = capYear(); const now = proCap(y), next = proCap(y + 1);
    setRule('capGrow', '0'); const now2 = proCap(y), next2 = proCap(y + 1), far = proCap(y + 4); setRule('capGrow', '8'); const next3 = proCap(y + 1);
    ({ now, next, now2, next2, far, next3 })`);
  check('v9.4: a new cap growth rate leaves this year\'s cap alone and changes the years after it', r.now === r.now2 && r.next2 === r.now && r.far === r.now && r.next3 > r.next, JSON.stringify(r));
});
sec('D03 injury chance', () => {
  const c = makeContext();
  const r = run(c, `newCareer({ pos: 'RB', first: 'R', last: 'D', num: 2, home: 'TX', path: 'college', stars: 3, diff: 'normal', pace: 'sim' });
    const n = cInjChance(); cs.p.ready = 'fresh'; const f = cInjChance(); cs.p.ready = 'tired'; const t = cInjChance(); delete cs.p.ready; ({ n, f, t })`);
  check('D03: resting this week lowers the injury chance and grinding raises it', r.f < r.n && r.n < r.t, JSON.stringify(r));
});

// ---------------- v9.5: team identity, relationships, remaining rules ----------------
sec('v9.5 schemes', () => {
  const c = makeContext();
  const r = run(c, `newCoachCareer({ name: 'T', start: 'any', tid: 'TCU', role: 'WR', diff: 'normal', gameDay: 'key', seed: 21 });
    schemeGameStart(); const s0 = myScheme(); const ocSch = coachSch(state.staff.OC); const follows = s0.off === ocSch.off; const wrSet = setScheme('off', 'air');
    state.co.role = 'HC'; const hcSet = setScheme('off', s0.off === 'air' ? 'power' : 'air') && setScheme('def', 'zone'); const s1 = myScheme();
    const g = mGames().find(x => !x.done); const p1 = schemeGameStart(); const p2 = schemeGameStart(); const p3 = schemeGameStart();
    const qb = P(state.depth.QB[0]); const f = playerFit(qb); const tr = Object.assign({}, qb.tr); qb.tr = Object.assign({}, tr, { arm: qb.ovr + 10, acc: qb.ovr + 10, mob: qb.ovr - 20 }); const fAir = playerFit(qb, { off: 'air', def: 'd43' }), fSpread = playerFit(qb, { off: 'spread', def: 'd43' }); qb.tr = tr;
    const opp = oppOf(g); const e = schemeEdge(opp); const fb = schemeFitBonus();
    ({ follows, wrSet, hcSet, s1, p1, p2, p3, fAir, fSpread, e, fb })`);
  check('v9.5: your scheme comes from your coordinators until the person in charge picks one; a position coach cannot', r.follows && r.wrSet === false && r.hcSet && r.s1.def === 'zone', JSON.stringify(r));
  check('v9.5: a new scheme costs a point on that side for two games, then it is installed', r.p1.off === -1 && r.p1.def === -1 && r.p2.off === -1 && r.p3.off === 0 && r.p3.def === 0, JSON.stringify(r));
  check('v9.5: scheme fit follows the traits the scheme leans on', r.fAir > 0 && r.fSpread < 0 && Math.abs(r.fb.off) <= 1.5 && Math.abs(r.fb.def) <= 1.5, JSON.stringify(r));
});
sec('v9.5 scheme traits carry over', () => {
  const c = makeContext();
  const r = run(c, `newGame('normal', null, 191, 'MICH'); goPro('ATL', { role: 'gm' }); proAutoOffseason(); const L = PS(); const fa = L.fa.slice().sort((a, b) => b.ovr - a.ovr)[0]; const before = playerFit(fa); const t0 = JSON.stringify(hashTraits(fa));
    state.phase = 'regular'; state.week = 3; fa.ask.apy = 1; while (state.roster.length >= proMax()) removeMine(state.roster[state.roster.length - 1].id); const res = faSignNow(fa.id, Math.max(1, fa.ask.apy), 1); const p = P(fa.id); ({ res, before, after: p ? playerFit(p) : 'gone', same: p ? JSON.stringify(p.tr) === t0 : false })`);
  check('v9.5: a free agent shows the same traits and fit before and after he signs', r.res === 'signed' && r.same && r.before === r.after, JSON.stringify(r));
});
sec('v9.5 relationships', () => {
  const c = makeContext();
  const r = run(c, `newGame('normal', null, 201, 'MICH'); const pos = 'WR'; const dep = state.depth[pos]; const best = dep.map(P).sort((a, b) => b.ovr - a.ovr)[0];
    state.depth[pos] = dep.filter(id => id !== best.id).concat(best.id); const g = mGames()[0]; relAfterGame(g, true); relAfterGame(g, false); const benched = rapOf(best);
    // departures: an unhappy underclassman is likelier to enter the portal
    const kids = state.roster.filter(p => ['Fr', 'So'].includes(p.cls) && !p.walkon).slice(0, 30); let sad = 0, glad = 0;
    for (let i = 0; i < 40; i++) { kids.forEach(p => p.rap = 15); state.off = { departures: [] }; offDepartures(); sad += state.off.departures.filter(d => kids.some(k => k.id === d.id) && /portal/.test(d.why)).length; kids.forEach(p => p.rap = 90); offDepartures(); glad += state.off.departures.filter(d => kids.some(k => k.id === d.id) && /portal/.test(d.why)).length; }
    ({ benched, why: best.rapW && best.rapW[0].why, sad, glad })`);
  check('v9.5: benching a better player costs rapport, with the reason recorded', r.benched < 60 && /Benched/.test(r.why), JSON.stringify(r));
  check('v9.5: unhappy players enter the transfer portal more often than happy ones', r.sad > r.glad * 1.5, JSON.stringify(r));
});
sec('v9.5 relationships NFL', () => {
  const c = makeContext();
  const r = run(c, `newGame('normal', null, 211, 'MICH'); goPro('NO', { role: 'gm' }); proAutoOffseason(); const p = state.roster.filter(x => x.k && x.k.yrs === 1 && x.ovr >= 70)[0] || state.roster[0];
    const price = v => { p.rap = v; delete p.ask; return askFor(p, true); }; const close = price(90).apy, mid = price(60).apy, sad = price(35).apy; const broken = price(10).walk;
    const before = rapOf(p); p.rap = 60; delete p.ask; const a = askFor(p, false); offerOwn(p.id, a.apy * 0.8, a.yrs); const low = rapOf(p);
    ({ close, mid, sad, broken, low })`);
  check('v9.5: a player close to you asks for less, an unhappy one for more, and a broken relationship ends extension talks', r.close < r.mid && r.sad > r.mid && r.broken === true && r.low < 60, JSON.stringify(r));
});
sec('v9.5 boss rapport', () => {
  const c = makeContext();
  const r = run(c, `newCoachCareer({ name: 'T', start: 'any', tid: 'TCU', role: 'OC', diff: 'normal', gameDay: 'key', seed: 31 }); state.settings.noFire = true; let n = 0; while (state.phase !== 'offseason' && n++ < 40) advance();
    const snap = JSON.stringify(state.co); const run1 = v => { state.co = JSON.parse(snap); bossRel().rap = v; coachSeasonEnd(); return state.co.sec; }; ({ hi: run1(85), lo: run1(25) })`);
  check('v9.5: rapport with your boss counts in your season review', r.hi > r.lo, JSON.stringify(r));
});
sec('v9.5 rules', () => {
  const c = makeContext();
  const r = run(c, `newGame('normal', null, 221, 'MICH'); const keep105 = trimToLimit().length; setRule('roster', '85'); const lim = rosterLimit(); const n0 = state.roster.length; const out = trimToLimit(); const n1 = state.roster.length;
    const L = { teams: {} }; ['A', 'B'].forEach(id => L.teams[id] = { id, off: 75, def: 75, st: 70, rating: 75, w: 0, l: 0, pf: 0, pa: 0, elo: 1500 }); let ot = 0, tie = 0, oneScore = 0;
    for (let i = 0; i < 1500; i++) { const g = { h: 'A', a: 'B', neutral: true }; fastGame(L, g, 'sudden'); if (g.ot) { ot++; if (Math.abs(g.hs - g.as) <= 7) oneScore++; } if (g.hs === g.as) tie++; }
    ({ keep105, lim, n0, n1, out: out.length, ot, tie, oneScore })`);
  check('v9.5: an 85-player college roster limit releases the extras before the new season', r.keep105 === 0 && r.lim === 85 && r.n0 > 85 && r.n1 === 85 && r.out === r.n0 - 85, JSON.stringify(r));
  check('v9.5: NFL games around the league follow the overtime rule too', r.ot > 10 && r.tie === 0 && r.oneScore === r.ot, JSON.stringify(r));
});
sec('v9.5 career injuries rule', () => {
  const c = makeContext();
  const r = run(c, `newCareer({ pos: 'RB', first: 'R', last: 'D', num: 2, home: 'TX', path: 'college', stars: 3, diff: 'normal', pace: 'sim' }); const n = cInjChance(); cs.injRule = 'low'; const lo = cInjChance(); cs.injRule = 'high'; const hi = cInjChance(); delete cs.injRule; ({ n, lo, hi })`);
  check('v9.5: Player Career has its own injuries rule', r.lo < r.n && r.hi > r.n, JSON.stringify(r));
});

// ---------------- v9.6: game clock, legacy pages, new mode features ----------------
sec('v9.6 game clock', () => {
  const c = makeContext();
  const r = run(c, `newGame('normal', null, 301, 'MICH'); const out = []; for (let k = 0; k < 6; k++) { const g = mGames()[k]; const sim = createSim(Object.assign({}, g, { done: false }), { detail: true }); simRun(sim); out.push(sim.log.filter(x => !x.half && !x.ot).map(x => [x.qtr, x.clock])); }
    const sec = c => { const [m, s] = c.split(':').map(Number); return m * 60 + s; };
    const bad = []; let odd = 0, all = 0; out.forEach(L => { let el = 0; L.forEach(([q, c]) => { const t = (q - 1) * 900 + 900 - sec(c); if (t < el) bad.push(q + ' ' + c); el = t; all++; if (sec(c) % 150) odd++; }); const q2 = L.filter(x => x[0] === 2).pop(), q4 = L.filter(x => x[0] === 4).pop(); if (!q2 || q2[1] !== '0:00' || !q4 || q4[1] !== '0:00') bad.push('end ' + JSON.stringify([q2, q4])); });
    ({ bad, odd, all, sample: out[0].slice(0, 6).map(x => 'Q' + x[0] + ' ' + x[1]).join(', ') })`);
  check('v9.6: the game clock runs forward drive by drive, each half ends at 0:00, and times are not stuck on 2:30 steps', r.bad.length === 0 && r.odd > r.all * 0.8, JSON.stringify(r));
});
sec('v9.6 legacy', () => {
  const c = makeContext();
  const r = run(c, `newGame('normal', null, 311, 'TCU'); state.settings.noFire = true; let n = 0; while (state.phase !== 'offseason' && n++ < 40) advance();
    const hl = state.hl && state.hl[state.season]; const tl = (state.tline || []).length;
    for (let i = 0; i < 120; i++) addNews('filler ' + i); const tl2 = (state.tline || []).length; addNews('A big moment', 'big'); const tl3 = state.tline.length;
    const p = state.roster.find(x => !x.real); p.awards = ['Heisman Trophy', 'First-team All-American']; const e = hofConsider(p, state.season); const real = state.roster.find(x => x.real); if (real) real.awards = ['Heisman Trophy']; const er = real ? hofConsider(real, state.season) : null;
    p.num = 7; e.num = 7; const ret = retireNumber(p.id); state.roster = state.roster.filter(x => x.num !== 7 || x.pos !== 'QB'); const nn = freeNumber('QB');
    const m0 = JSON.parse(JSON.stringify(mileRec())); for (let i = 0; i < 4; i++) recordMile({ tm: 'TCU', w: 25, l: 0, natl: true, conf: true, po: true }); const m1 = mileRec();
    ({ hl: !!hl, rating: hl ? hl.rating.length : 0, plays: hl ? hl.plays.length : -1, tl, tl2, tl3, hof: !!e, real: er, ret, nn, m0: m0.seasons, wins: m1.wins, done: Object.keys(m1.done) })`);
  check('v9.6: every season ends with highlights: plays, wins, top players and a week-by-week rating line', r.hl && r.rating >= 10 && r.plays >= 0, JSON.stringify(r));
  check('v9.6: the timeline keeps the big moments even after the newswire rolls over', r.tl > 0 && r.tl2 === r.tl && r.tl3 === r.tl + 1, JSON.stringify(r));
  check('v9.6: a fictional star goes into the Hall of Fame (real players are left out) and a retired number is never handed out again', r.hof && !r.real && r.ret && r.nn !== 7, JSON.stringify(r));
  check('v9.6: long-term goals count across seasons and unlock once', r.m0 === 1 && r.wins >= 100 && r.done.includes('m_100w') && r.done.includes('m_3natl'), JSON.stringify(r));
});
sec('v9.6 AD media and conference move', () => {
  const c = makeContext();
  const r = run(c, `newGame('normal', null, 321, 'UCF'); const a0 = mediaAmt(); state.media = { plan: 'linear', thru: state.season }; state.phase = 'offseason'; const due = mediaDue(); let tries = 0; while (state.media.plan !== 'stream' && tries++ < 20) { state.media.thru = state.season; settleMedia('stream'); } const a1 = mediaAmt();
    const from = T(ME).conf; const odds = moveOdds('SEC'); state.myMove = { s: state.season, to: 'SEC', fee: 18 }; realign(); const to = T(ME).conf; const inSEC = CONFS.SEC.teams ? CONFS.SEC.teams.includes ? CONFS.SEC.teams.includes(ME) : true : true;
    ({ a0, due, a1, plan: state.media.plan, thru: state.media.thru, from, odds, to })`);
  check('v9.6: the conference media deal comes up for a vote and its plan changes the money', r.a0 === 0 && r.due && r.plan === 'stream' && r.a1 === 4 && r.thru > 2026, JSON.stringify(r));
  check('v9.6: an accepted application moves your program to the new conference at the start of the next season', r.from !== 'SEC' && r.odds > 0 && r.to === 'SEC', JSON.stringify(r));
});
sec('v9.6 coach features', () => {
  const c = makeContext();
  const r = run(c, `newCoachCareer({ name: 'T', start: 'any', tid: 'TCU', role: 'HC', diff: 'normal', gameDay: 'key', seed: 41 });
    const oc = state.staff.OC; const dest = Object.values(state.teams).find(t => t.id !== ME && CONFS[t.conf].p4); treeAdd(oc, 'OC', dest.id, 'HC'); dest.coach = oc.name; const at = treeAt(dest.id); const cand = treeCandidate('HC'); const acc = hireAccept(cand, false), acc0 = hireAccept(Object.assign({}, cand, { tree: false }), false);
    const ms0 = michStrength().off; setPplan('def', -2); setPplan('off', 2); const ms1 = michStrength().off; const inj = pplanBonus().inj; setPplan('film', -1); setPplan('cond', 1); const inj2 = pplanBonus().inj;
    state.co.role = 'OC'; const ocSet = setPplan('off', 1); state.co.role = 'HC';
    const st = POS_ORDER.flatMap(pos => starters(pos)); const r0 = rapOf(st[0]); const b0 = bossRel().rap; state.event = { key: 'presser', opts: [{ label: 'Credit the players', fx: { rap: 3, boss: 2 } }] }; resolvePresser(0);
    ({ at: !!at, cand: cand && cand.tree, acc: +(acc - acc0).toFixed(2), ms0, ms1, inj, inj2, ocSet, r: rapOf(st[0]) - r0, b: bossRel().rap - b0 })`);
  check('v9.6: a former assistant now leading another program is in your coaching tree, and he can be hired back more easily', r.at && r.cand && r.acc > 0.1, JSON.stringify(r));
  check('v9.6: the head coach\'s practice plan moves the offense and the injury risk; others can\'t change it', r.ms1 > r.ms0 && r.inj === 1 && r.inj2 < 1 && r.ocSet === false, JSON.stringify(r));
  check('v9.6: a coach\'s press conference answers move rapport with his players and his boss', r.r >= 2.5 && r.b >= 2, JSON.stringify(r));
});
sec('v9.6 NFL features', () => {
  const c = makeContext();
  const r = run(c, `newGame('normal', null, 331, 'MICH'); goPro('SF', { role: 'gm' }); const L = PS();
    // compensatory picks
    L.cfa = [{ s: state.season, from: ME, to: 'DAL', apy: 12, n: 'A' }, { s: state.season, from: ME, to: 'NYG', apy: 3, n: 'B' }]; const got = proCompPicks(); const comp = L.picks.filter(p => p.c && p.own === ME);
    // a comp pick in this year's draft takes a slot at the end of its round
    L.picks.push({ yr: state.season + 1, rd: 4, orig: ME, own: ME, c: true, cv: 12 }); let g = 0; while (L.off.step < 4 && g++ < 10) { if (!proOffNext()) { if (L.off.step === 1) proAutoHireHC(); } }
    const mock = mockDraft(); const uniq = new Set(mock.map(x => x.pid)).size;
    const D = L.draft; const nos = D.slots.map(s => s.no); const seq = nos.every((x, i) => x === i + 1); const cs4 = D.slots.filter(s => s.rd === 4); const lastIsComp = cs4[cs4.length - 1].c === true; draftRun(false); const mine = D.mine.length;
    // fifth-year option
    const p = state.roster.find(x => x.k && !x.k.tag); p.k = rookieContract(12); p.k.yrs = 1; kFix(p.k); const due = optionDue(p); const sal = optionSalary(p); exerciseOption(p.id, true); const after = { yrs: p.k.yrs, n: p.k.sal.length, last: p.k.sal[1] };
    ({ got, comp: comp.map(x => x.rd), seq, lastIsComp, mine, due, sal, after, mock: mock.length, uniq, done: D.done })`);
  check('v9.6: losing free agents earns compensatory picks sized to the contracts lost', r.got.length === 2 && JSON.stringify(r.comp) === '[4,6]', JSON.stringify(r));
  check('v9.6: compensatory picks come at the end of their round and the draft runs through them', r.seq && r.lastIsComp && r.done && r.mine >= 7, JSON.stringify(r));
  check('v9.6: a first-round pick\'s fifth-year option adds a season at the option salary', r.due && r.after.yrs === 2 && r.after.n === 2 && Math.abs(r.after.last - r.sal) < 0.01, JSON.stringify(r));
  check('v9.6: the mock draft fills round one with 32 different prospects', r.mock === 32 && r.uniq === 32, JSON.stringify(r));
});
sec('v9.6 NFL workouts and deadline deals', () => {
  const c = makeContext();
  const r = run(c, `newGame('normal', null, 341, 'MICH'); goPro('LAR', { role: 'gm' }); proAutoOffseason(); const L = PS(); const list = L.dc.list.filter(p => p.sc < 3).slice(0, 7); const res = list.map(p => workout(p.id)); const full = list.filter(p => p.sc === 3).length;
    const seller = NFL.find(t => t.id !== ME).id; const their = proRoster(seller).filter(p => underContract(p) && capHit(p) < capRoom(ME)).sort((a, b) => b.ovr - a.ovr)[0]; const myPk = L.picks.findIndex(pk => pk.own === ME && pk.rd === 2);
    L.tradeOffers = [{ id: 'tbx', s: state.season, tid: seller, exp: 9, buy: true, get: { pl: [], pk: [myPk] }, give: { pl: [their.id], pk: [] } }]; const ok = acceptOffer2('tbx');
    ({ why: ok.why, res, full, ok: ok.ok, have: !!P(their.id), pk: L.picks[myPk].own === seller })`);
  check('v9.6: five private workouts a year give full reads on prospects', JSON.stringify(r.res) === '[true,true,true,true,true,false,false]' && r.full === 5, JSON.stringify(r));
  check('v9.6: accepting a deadline deal brings the player in and sends your pick out', r.ok && r.have && r.pk, JSON.stringify(r));
});
sec('v9.6 career features', () => {
  const c = makeContext();
  const r = run(c, `newCareer({ pos: 'WR', first: 'C', last: 'M', num: 3, home: 'GA', path: 'college', stars: 4, diff: 'normal', pace: 'sim' }); signWith(offersList()[0].id);
    const base = draftProjection(); combineDrills().forEach(d => runDrill(d[0])); const dl = combineDelta(); const after = draftProjection(); const pd = runDrill('forty', true); const pd2 = runDrill('bench', true);
    cs.lvl = 'col'; cs.phase = 'col'; const bank0 = cs.p.bank; folGain(6000); const offers = (cs.endOff || []).length; const id = offers ? cs.endOff[0].id : null; if (id) endorseAnswer(id, true); const paid = cs.p.bank - bank0;
    cs.phase = 'retired'; const a1 = careerAfter('booth'); const a2 = careerAfter('coach');
    ({ base, dl, after, pd: !!pd, pd2: pd2 === null, offers, paid, a1, a2, after2: cs.after })`);
  check('v9.6: the combine moves the draft projection by at most 1.5 points, and pro day allows one redo', Math.abs(r.after - r.base - r.dl) < 0.01 && Math.abs(r.dl) <= 1.5 && r.pd && r.pd2, JSON.stringify(r));
  check('v9.6: a growing following brings an endorsement offer that pays when signed', r.offers === 1 && r.paid > 0, JSON.stringify(r));
  check('v9.6: after retiring, a player picks one next chapter', r.a1 === true && r.a2 === false && r.after2 === 'booth', JSON.stringify(r));
});
sec('v9.6 how it was won', () => {
  const c = makeContext();
  const r = run(c, `newGame('normal', null, 351, 'MICH'); advance(); const g = mGames().find(x => x.done && x.box); ({ has: !!g, p: g ? g.log.every(x => Array.isArray(x.p) && x.p.length === 2) : false, last: g ? g.log[g.log.length - 1].p : null, score: g ? [g.hs, g.as] : null })`);
  check('v9.6: every drive in the box score keeps the score after it, for the drive chart', r.has && r.p && JSON.stringify(r.last) === JSON.stringify(r.score), JSON.stringify(r));
});

// ---------------- v9.7 ----------------
sec('v9.7 field view data and game day', () => {
  const c = makeContext();
  const r = run(c, `newGame('normal', null, 701, 'MICH'); const mg = michGameThisWeek(state.week); const sim = createSim(mg, { live: true }); sim.ask = true; let n = 0;
    while (!sim.done && n++ < 300) { if (sim.pending) { if (sim.pending.type === 'half') { const m0 = simMargin(sim); const fx = speechFx(sim, 'fire'); const F0 = sim.F[sim.mSide].off; simResolve(sim, { speech: 'fire' }); sim._sp = { m0, fx, d: r1(sim.F[sim.mSide].off - F0) }; } else autoAdvance(sim); if (sim.pending && sim.pending.type !== 'half') simResolve(sim, autoChoice(sim, sim.pending.drv)); } else simStep(sim); }
    const drives = sim.log.filter(x => !x.half); ({ pl: drives.every(x => Array.isArray(x.pl) && x.pl.length >= 1 && x.pl.length <= 2), kinds: [...new Set(drives.flatMap(x => x.pl.map(p => p.k)))], fg: drives.filter(x => x.out === 'fg').every(x => x.fg > 0), sp: sim._sp, half: sim.log.find(x => x.half).txt })`);
  check('v9.7: every drive of your game carries its last plays for the field view', r.pl && r.fg, JSON.stringify(r.kinds));
  check('v9.7: the halftime speech changes your second-half strength by what the score calls for', r.sp && Math.abs(r.sp.d - r.sp.fx.off) < 0.05 && (r.sp.m0 < 0 ? r.sp.fx.off >= 1 : r.sp.fx.off <= 0.3) && /speech/.test(r.half), JSON.stringify(r.sp));
  const r2 = run(c, `const sim = { done: false, mSide: 0, pending: null, chal: 2, ckKey: 'k', g: { id: 'g' }, pts: [7, 7], q: [[7, 0, 0, 0, 0], [7, 0, 0, 0, 0]], shortField: [0, 0], i: 2, total: 24, m0: 0, box: { t: [{ to: 1 }, { to: 0 }], wp: [{ v: 50 }] }, log: [{ s: 0, out: 'td', qtr: 1, pts: [7, 0] }, { s: 1, out: 'td', qtr: 1, pts: [7, 7], txt: 'TD' }] };
    const rv = reviewable(sim); const tries = []; for (let i = 0; i < 40; i++) { const s2 = JSON.parse(JSON.stringify(sim)); s2.ckKey = 'k' + i; const res = challengePlay(s2); tries.push([res.ok, s2.pts[1], s2.chal, !!reviewable(s2)]); }
    ({ rv, ok: tries.filter(t => t[0]).length, okPts: tries.filter(t => t[0]).every(t => t[1] === 3), badPts: tries.filter(t => !t[0]).every(t => t[1] === 7), left: tries.every(t => t[2] === 1 && !t[3]) })`);
  check('v9.7: an opponent touchdown can be challenged once; overturned it becomes a field goal', r2.rv && r2.rv.kind === 'td' && r2.ok > 0 && r2.ok < 40 && r2.okPts && r2.badPts && r2.left, JSON.stringify(r2));
});
sec('v9.7 rules and systems', () => {
  const c = makeContext();
  const r = run(c, `newGame('normal', null, 702, 'MICH'); goPro('DET', { role: 'gm' }); const a = proMax(); setRule('proRoster', 46); const b = proMax(); const pre = rulePreset();
    proAutoOffseason(); ({ a, b, pre, size: state.roster.length, ai: Math.max(...NFL.filter(t => t.id !== ME).map(t => proRoster(t.id).length)), classic: RULE_PRESETS.classic.v.proRoster })`);
  check('v9.7: the NFL roster limit is a league rule (53 by default) and the final cut follows it', r.a === 53 && r.b === 46 && r.size <= 46 && r.ai <= 46 && r.classic === 53 && r.pre === 'custom', JSON.stringify(r));
  const c2 = makeContext();
  const s = run(c2, `newGame('normal', null, 703, 'TCU'); const p = state.roster.find(x => !x.real && x.pos === 'WR'); p.inj = 6; p.injType = 'Hamstring strain';
    const open = rehabOpen(p); setRehab(p.id, 'rush'); const rush = { inj: p.inj, reinj: p.reinj, f: rehabInjF(p), again: rehabOpen(p) };
    const q = state.roster.find(x => !x.real && x.pos === 'CB'); q.inj = 3; setRehab(q.id, 'safe'); const safe = { inj: q.inj, f: rehabInjF(q) };
    const h0 = hireScout(scoutCands()[0].id); const cands = scoutCands(); hireScout(cands[0].id); hireScout(cands[1].id); const four = hireScout(scoutCands()[0] ? scoutCands()[0].id : 'x');
    const reg = Object.keys(SC_REG).find(k => scoutList().some(x => x.spec === k)); const rr = state.rec ? state.rec.list.find(x => recRegion(x) === reg) : null;
    const bal0 = state.fin.balance; const okB = issueBond(25); const bal1 = state.fin.balance; const paid = bondsYearEnd(); const again = bondsYearEnd(); const big = issueBond(50) && issueBond(50);
    ({ open, rush, safe, h0, four, scouts: scoutList().length, rr: rr ? !!recScout(rr) : 'none', okB, got: r1(bal1 - bal0), paid, again, big, debt: debtLeft() })`);
  check('v9.7: rushing a player back halves the time out but raises his injury risk; playing it safe does the opposite', s.open && s.rush.inj === 3 && s.rush.reinj === 4 && s.rush.f === 4 && !s.rush.again && s.safe.inj === 4 && s.safe.f === 0.5, JSON.stringify(s));
  check('v9.7: up to three scouts; a scout covers his region\'s recruits', s.h0 && !s.four && s.scouts === 3 && s.rr !== false, JSON.stringify(s));
  check('v9.7: a bond pays out now, is paid back once a year, and debt is capped', s.okB && s.got === 25 && s.paid > 3 && s.again === 0 && s.big === false, JSON.stringify(s));
  const t = run(c2, `state.phase = 'offseason'; let o = null; for (let i = 0; i < 30 && !o; i++) { state.season++; o = boosterOffer(); } const bal = state.fin.balance; const msg = answerBooster(true); const got = r1(state.fin.balance - bal); const k = o.k;
    if (k === 'coach') { stringsCheck('fire', o.coach); } else { state.fin.ticket = o.tix + 20; stringsCheck('year'); } const lost = r1(bal + got - state.fin.balance);
    ({ k, amt: o.amt, got, lost, broken: state.strings[0].broken })`);
  check('v9.7: a booster gift with strings pays now and wants half back if you break the promise', t.got === t.amt && t.broken && Math.abs(t.lost - t.amt / 2) < 0.05, JSON.stringify(t));
  const u = run(c2, `const before = state.roster.map(p => p.pers).join(); state.captains = state.roster.filter(p => p.pers === 'steady').slice(0, 4).map(p => p.id); let changed = 0; for (let i = 0; i < 4; i++) { state.season++; changed += evolvePers().length; }
    ({ changed, realDiva: state.roster.some(p => p.real && (p.pers === 'diva' || p.pers === 'fragile') && (p.persLog || []).length), logs: state.roster.filter(p => (p.persLog || []).length).length })`);
  check('v9.7: personalities change over the years, and real players never turn into divas', u.changed > 0 && u.logs > 0 && !u.realDiva, JSON.stringify(u));
  const w = run(c2, `state.season = 2030; state.phase = 'offseason'; const list = parseRankings('1. Georgia\\nOhio State 93\\n3) Texas\\n#4 LSU\\nNot A Team'); const r = importRankings('1. Georgia\\n2. Ohio State\\n3. Texas');
    ({ ids: list.map(x => x.id + ':' + x.rank + ':' + (x.rating || '')), n: r.n, order: ['UGA', 'OSU', 'TEX'].map(id => T(id).elo), top: Object.values(state.teams).sort((a, b) => b.elo - a.elo).slice(0, 3).map(t => t.id) })`);
  check('v9.7: a pasted ranking sets the top of the league in that order', w.n === 3 && w.top.join() === 'UGA,OSU,TEX' && w.ids.length === 4 && w.ids[1] === 'OSU:2:93', JSON.stringify(w));
});
sec('v9.7 career: academics, teammates, holdouts, followers', () => {
  const c = makeContext();
  const r = run(c, `newCareer({ pos: 'RB', first: 'C', last: 'M', num: 3, home: 'GA', path: 'college', stars: 4, diff: 'normal', pace: 'sim' }); signWith(offersList()[0].id);
    const a = acad(); setMajor('eng'); setStudy('light'); a.boost = -2; acadTerms(null); const gpa = a.gpa; colNewSeason(); const susp = a.susp; const share = myShare();
    a.susp = 0; setStudy('heavy'); for (let i = 0; i < 3; i++) acadTerms(null); const gpa2 = a.gpa;
    const m = mateList(); if (m.length) mateAdj(m[0].n, 30); const chem = chemistry();
    ({ gpa, susp, share, gpa2, terms: a.terms, mates: m.length, chem })`);
  check('v9.7: a GPA under 2.0 means academic probation: you sit the first three games', r.gpa < 2 && r.susp === 3 && r.share === 0 && r.gpa2 > r.gpa && r.terms === 8, JSON.stringify(r));
  check('v9.7: you have teammates at your position, and getting along raises chemistry', r.mates >= 1 && r.chem > 50, JSON.stringify(r));
  const h = run(c, `cs.lvl = 'col'; cs.phase = 'col'; cs.p.fol = 120000; cs.endY = null; cs.endorse = []; cs.endOff = []; cs.year++; endorseSeason(); const n1 = cs.endOff.length; endorseSeason(); const n2 = cs.endOff.length; ({ n1, n2 })`);
  check('v9.7: each season brands come back: one deal per follower level reached, at most three', h.n1 === 3 && h.n2 === 3, JSON.stringify(h));
  const k = run(c, `cs.nfl = { tm: 'DET', age: 25, yrs: 2, pow: {}, contract: { tm: 'DET', yrs: 4, left: 3, apy: 900000, bonus: 0, kind: 'rookie', from: cs.year }, hist: [], moves: [], draft: { year: cs.year, round: 3, pick: 80, tm: 'DET' }, earn: 0 }; cs.lvl = 'nfl'; cs.phase = 'nfloff'; cs.off = { steps: ['nreview', 'nmoney', 'ntrain'], i: 1 };
    Object.keys(cs.p.a).forEach(x => cs.p.a[x] = 90); const can = canHoldout(); const odds = holdoutOdds(); const bank = cs.p.bank = 5000000; const res = nflHoldout(); const again = canHoldout();
    ({ can, odds, ok: res && res.ok, apy: cs.nfl.contract.apy, fine: res && res.fine, trust: cs.p.trust, again, held: !!cs.off.held })`);
  check('v9.7: an underpaid NFL starter can hold out once; it ends in a new deal or in fines', k.can && k.odds > 0 && !k.again && (k.ok ? k.apy > 900000 : k.fine > 0 && k.held), JSON.stringify(k));
});

(async () => { for (const f of asyncChecks) { try { await f(); } catch (e) { fail++; out.push('FAIL  async check: ' + e.message); } }
out.forEach(l => console.log(l));
console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0); })();
