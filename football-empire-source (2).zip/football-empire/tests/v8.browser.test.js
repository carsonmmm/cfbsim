// Football Empire (v8) interface checks in headless Chromium: picking a school, school colors,
// the NFL Draft tab and offseason step, and the Player Career NFL screens, at desktop and phone widths.
//   NODE_PATH=$(npm root -g) node tests/v8.browser.test.js [path/to/game.html]
const { chromium } = require('playwright');
const path = require('path');
const { serveFile, enterAD } = require('./serve');
const file = path.resolve(process.argv[2] || path.join(__dirname, '..', 'football-empire.html'));
let pass = 0, fail = 0; const out = [];
function check(name, cond, detail) { (cond ? pass++ : fail++); out.push(`${cond ? 'PASS' : 'FAIL'}  ${name}${detail != null && detail !== '' ? '  (' + detail + ')' : ''}`); }
const sleep = ms => new Promise(r => setTimeout(r, ms));
async function fresh(browser, url, w) {
  const ctx = await browser.newContext({ viewport: { width: w || 1360, height: 900 } }); const page = await ctx.newPage(); const errors = [];
  page.on('pageerror', e => errors.push(e.message)); page.on('dialog', d => d.dismiss());
  await page.goto(url); await page.waitForSelector('#view .modes'); return { ctx, page, errors };
}
const overflow = page => page.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth);

(async () => {
  const url = await serveFile(file);
  const browser = await chromium.launch();

  // ---------- picking a school on the home screen ----------
  {
    const { ctx, page, errors } = await fresh(browser, url);
    const brand = await page.evaluate(() => document.querySelector('#hdr .wm').textContent);
    check('the site is branded Football Empire', /FOOTBALL EMPIRE/.test(brand), brand);
    await page.click('#view [data-act=adpick]'); await page.waitForSelector('#nc-tid');
    const n = await page.evaluate(() => document.querySelectorAll('#nc-tid option').length);
    check('the school picker lists all 138 FBS programs', n === 138, n);
    await page.selectOption('#nc-tid', 'TEX'); await sleep(150);
    const pv = await page.evaluate(() => document.querySelector('#view .schoolpv') && document.querySelector('#view .schoolpv').innerText);
    check('choosing a school previews its stadium and rivals', /Texas Memorial Stadium|DKR/.test(pv || '') && /Texas A&M|Oklahoma/.test(pv || ''), (pv || '').slice(0, 120));
    await page.click('#view [data-act=adpickstart]'); await page.waitForFunction(() => appMode === 'ad' && state && ME === 'TEX');
    const look = await page.evaluate(() => ({ name: document.querySelector('#hdr .wm').textContent, band: getComputedStyle(document.getElementById('hdr')).backgroundColor, title: document.title, txt: document.getElementById('view').innerText }));
    check('the AD career starts at the chosen school with its name in the header and title', /TEXAS/.test(look.name) && /Texas · Football Empire/.test(look.title), look.name + ' · ' + look.title);
    check('the header takes the school\'s colors', look.band !== 'rgb(0, 39, 76)', look.band);
    // every AD tab renders without Michigan leftovers
    const tabs = await page.evaluate(() => TABS.map(t => t[0]).filter(t => t !== 'admin'));
    const leaks = [];
    for (const t of tabs) { await page.evaluate(t => { ui.tab = t; render(); }, t); const txt = await page.evaluate(() => document.getElementById('view').innerText); if (/Wolverines|Big House|Michigan Stadium|Schembechler/.test(txt)) leaks.push(t); }
    check('no AD tab shows Michigan-only text when playing another school', leaks.length === 0, leaks.join(', '));
    // the Draft tab
    await page.evaluate(() => { ui.tab = 'draft'; render(); });
    const dr = await page.evaluate(() => ({ h: [...document.querySelectorAll('#view .h2')].map(x => x.textContent), board: document.querySelectorAll('#view .tbl tbody tr').length, mock: document.querySelectorAll('#view ol.mock li').length }));
    check('the NFL Draft tab shows your prospects, a big board and a mock first round', dr.h.includes('Your prospects') && dr.h.includes('Top 50 prospects') && dr.mock === 32 && dr.board >= 50, JSON.stringify(dr));
    await page.selectOption('#dpos', 'QB'); await sleep(150);
    const qb = await page.evaluate(() => [...document.querySelectorAll('#view .tbl')[1].querySelectorAll('tbody tr td:nth-child(3)')].every(td => td.textContent === 'QB'));
    check('the big board filters by position', qb);
    // offseason draft step
    await page.evaluate(() => { let n = 0; while (state.phase !== 'offseason' && n++ < 40) advance(); let g = 0; while (state.off.step < 6 && g++ < 20) { const o = state.off; if (o.step === 1) { autoBoard(); autoDeals(); } if (o.step === 2) autoHire(); if (o.step === 5 && !state.rec.done) signingDay(); offStepNext(); } ui.tab = 'off'; render(); });
    const pre = await page.evaluate(() => !!document.querySelector('#view [data-act=rundraft]') && /NFL Draft/.test(document.querySelector('#view ol.steps li.on').textContent));
    check('the offseason has an NFL Draft step with a button to run the draft', pre);
    await page.click('#view [data-act=rundraft]'); await sleep(200);
    const res = await page.evaluate(() => ({ mine: document.querySelectorAll('#view ul.dpicks li').length, rows: document.querySelectorAll('#view .tbl tbody tr').length, lastDraft: state.lastDraft && state.lastDraft.mine.length, rd: [...document.querySelectorAll('#view [data-act=drd]')].length }));
    check('running the draft shows your players by round and pick, and every pick by round', res.rd === 7 && res.rows === 32 && res.mine === res.lastDraft, JSON.stringify(res));
    await page.click('#view [data-act=drd][data-v="3"]'); await sleep(100);
    const r3 = await page.evaluate(() => document.querySelectorAll('#view .tbl tbody tr').length);
    check('round 3 lists its 40 picks, compensatory picks included', r3 === 40, r3);
    await page.click('#view [data-act=offnext]'); await sleep(150);
    const dev = await page.evaluate(() => state.off.step);
    check('after the draft the offseason moves on to development', dev === 7, dev);
    await page.evaluate(() => { ui.tab = 'history'; render(); });
    const hist = await page.evaluate(() => /Rd \d+, #\d+/.test(document.getElementById('view').innerText));
    check('History lists drafted players with round, pick and team', hist);
    check('no page errors in AD mode', errors.length === 0, errors.join(' | '));
    await ctx.close();
  }

  // ---------- phone width ----------
  {
    const { ctx, page, errors } = await fresh(browser, url, 390);
    await enterAD(page, 'UGA');
    const over = [];
    for (const t of ['office', 'draft', 'schedule', 'history']) { await page.evaluate(t => { ui.tab = t; render(); }, t); await sleep(80); if (await overflow(page) > 1) over.push(t); }
    check('AD tabs fit a 390px phone screen', over.length === 0, over.join(', '));
    check('no page errors on the phone', errors.length === 0, errors.join(' | '));
    await ctx.close();
  }

  // ---------- Player Career into the NFL ----------
  for (const w of [1360, 390]) {
    const { ctx, page, errors } = await fresh(browser, url, w);
    await page.click('[data-act=gocareer]'); await page.waitForSelector('#cnewform');
    await page.evaluate(() => { cui.form.pos = 'LB'; cui.form.path = 'college'; cui.form.stars = 4; });
    await page.click('[data-act=cstart]'); await sleep(150);
    await page.evaluate(() => { signWith(offersList().sort((a, b) => teamLevel(b.id) - teamLevel(a.id))[0].id); cs.p.auto = true; let g = 0; while (cs.phase !== 'done' && g++ < 40) { const r = cSimUntil(null, { events: true, spend: true }); if (r === 'choice' && offStep() === 'draft') declareDraft(true); else if (r === 'choice') offNext(); } cui.tab = 'home'; render(); });
    const dec = await page.evaluate(() => ({ start: !!document.querySelector('#view [data-act=cnfl]'), walk: !!document.querySelector('#view [data-k=nflskip]'), primary: document.querySelector('#hdr [data-act=ctab]') && document.querySelector('#hdr .btn.primary').textContent }));
    check(`[${w}] after the draft the player chooses between the NFL and walking away`, dec.start && dec.walk && /NFL decision/.test(dec.primary), JSON.stringify(dec));
    await page.click('#view [data-act=cnfl]'); await sleep(200);
    const home = await page.evaluate(() => ({ lvl: cs.lvl, phase: cs.phase, txt: document.getElementById('view').innerText, tabs: [...document.querySelectorAll('#tabs .tab, #mnav button')].map(b => b.textContent) }));
    check(`[${w}] starting the NFL career shows the first game and the contract`, home.lvl === 'nfl' && home.phase === 'nfl' && /Week 1/i.test(home.txt) && /rookie deal|undrafted/i.test(home.txt), home.txt.slice(home.txt.indexOf('Contract'), home.txt.indexOf('Contract') + 120));
    // play a game to the final
    await page.click('#view [data-act=cplay]');
    for (let i = 0; i < 400; i++) { const st = await page.evaluate(() => cg ? (cg.done ? 'done' : cg.pending ? 'pick' : 'run') : 'none'); if (st === 'done' || st === 'none') break; if (st === 'pick') await page.click('#cfirstopt').catch(() => { }); await sleep(25); }
    await page.waitForSelector('#cgdonebtn'); await page.click('#cgdonebtn'); await sleep(150);
    const played = await page.evaluate(() => cs.ss.games.length === 1 && cs.week === 2);
    check(`[${w}] an NFL game plays to the final with snap decisions`, played);
    const over = [];
    for (const t of ['home', 'player', 'schedule', 'stats', 'nil', 'team', 'league', 'settings']) { await page.evaluate(t => { cui.tab = t; render(); }, t); await sleep(60); const bad = await page.evaluate(() => /hit an error/.test(document.getElementById('view').innerText)); if (bad) over.push(t + ' error'); if (await overflow(page) > 1) over.push(t); }
    check(`[${w}] every career tab renders in the NFL${w < 500 ? ' and fits the phone' : ''}`, over.length === 0, over.join(', '));
    // season end, offseason, free agency
    await page.evaluate(() => { cSimUntil(() => !cInSeason(), { events: true, spend: true }); cui.tab = 'home'; render(); });
    const off = await page.evaluate(() => ({ phase: cs.phase, steps: [...document.querySelectorAll('#view ol.steps li')].map(x => x.textContent) }));
    check(`[${w}] the season ends in an NFL offseason: review, contract, training`, off.phase === 'nfloff' && off.steps.join('|') === 'Season review|Contract and free agency|Offseason training', JSON.stringify(off));
    await page.click('#view [data-act=coffnext]'); await sleep(100);
    await page.evaluate(() => { cs.nfl.contract.left = 0; cs.nfl.contract.opt = false; cs.nfl.moneyDone = null; nflMoneyStep(); render(); });
    const fa = await page.evaluate(() => ({ rows: document.querySelectorAll('#view .tbl tbody tr').length, offers: cs.nfl.fa.offers.length, blocked: !document.querySelector('#view .offc > .row [data-act=coffnext]') }));
    check(`[${w}] free agency lists the offers and holds the offseason until he signs`, fa.offers > 0 && fa.rows === fa.offers && fa.blocked, JSON.stringify(fa));
    const i = await page.evaluate(() => cs.nfl.fa.offers.findIndex(o => o.kind !== 'resign'));
    await page.click(`#view [data-act=cask2][data-k="fa-${i}"]`); await sleep(80); await page.click(`#view [data-act=cfa][data-i="${i}"]`); await sleep(120);
    const signed = await page.evaluate(i => ({ tm: cs.nfl.tm, done: cs.nfl.fa.done, flash: (document.querySelector('#view .flash') || {}).textContent || '' }), i);
    check(`[${w}] signing an offer moves the player to his new team`, signed.done && /signed with the/i.test(signed.flash), JSON.stringify(signed));
    // retire from the next screen
    await page.evaluate(() => { offNext(); render(); });
    await page.evaluate(() => { cs.off.i = 0; render(); });
    await page.click('#view [data-act=cask2][data-k=retire]'); await sleep(80); await page.click('#view [data-act=cretire]'); await sleep(150);
    const ret = await page.evaluate(() => ({ phase: cs.phase, txt: document.getElementById('view').innerText.slice(0, 200) }));
    check(`[${w}] retiring shows the career summary with a Hall of Fame verdict`, ret.phase === 'retired' && /(Hall of|career in the league|solid pro career)/i.test(ret.txt), ret.txt.slice(0, 100));
    // reload keeps the retired career
    await page.evaluate(() => cSaveNow()); await page.reload(); await page.click('[data-act=gocareer]'); await sleep(300);
    const back = await page.evaluate(() => cs && cs.phase);
    check(`[${w}] the retired career reloads`, back === 'retired', back);
    check(`[${w}] no page errors in the NFL career`, errors.length === 0, errors.join(' | '));
    await ctx.close();
  }

  await browser.close();
  out.forEach(l => console.log(l)); console.log(`\n${pass} passed, ${fail} failed`); process.exitCode = fail ? 1 : 0;
})().catch(e => { console.error(e); process.exit(1); });
