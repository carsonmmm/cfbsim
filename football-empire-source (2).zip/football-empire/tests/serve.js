// Serves the game file over http://127.0.0.1 for the browser tests. Headless Chromium can drop
// localStorage for file:// pages across a reload, which made reload checks flaky; a real origin
// keeps storage the way a browser does for a hosted page.
const http = require('http'), fs = require('fs'), path = require('path');
function serveFile(file) {
  const body = fs.readFileSync(file);
  return new Promise(resolve => {
    const srv = http.createServer((req, res) => {
      if (req.url.split('?')[0] === '/' || req.url.split('?')[0] === '/' + path.basename(file)) { res.writeHead(200, { 'content-type': 'text/html; charset=utf-8' }); res.end(body); }
      else { res.writeHead(404); res.end(); }
    });
    srv.listen(0, '127.0.0.1', () => { srv.unref(); resolve('http://127.0.0.1:' + srv.address().port + '/'); });
  });
}
// Goes from the home screen into AD mode. With no AD save the home screen offers "Pick your
// school" first; the tests take the default pick (Michigan) unless a school id is given.
async function enterAD(page, tid) {
  const sel = '#view [data-act=goad], #view [data-act=adpick]';
  await page.waitForSelector(sel); await page.click(sel);
  if (await page.$('#view [data-act=adpickstart]')) {
    if (tid) await page.selectOption('#nc-tid', tid);
    await page.click('#view [data-act=adpickstart]');
  }
  await page.waitForFunction(() => typeof appMode !== 'undefined' && appMode === 'ad' && typeof state !== 'undefined' && state && document.querySelector('#hdr .brand'));
}
module.exports = { serveFile, enterAD };
