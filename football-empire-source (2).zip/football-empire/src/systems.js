/* ===================== SEASON SYSTEMS ===================== */
function oppOf(g) { return g.h === ME ? g.a : g.h; }
// Money scale of the program: Michigan is 1. Real schools get a fixed scale from their conference and
// standing when the career starts (state.econ); custom programs made before v8 keep the old rule.
function econ() { if (state.econ != null) return state.econ; if (!state.me) return 1; const c = CONFS[T(ME).conf]; return c.p4 ? 0.85 : T(ME).conf === 'IND' ? 0.6 : 0.3; }
function progEcon(id, rating) { if (id === 'MICH') return 1; const t = CTEAMS0_AD[id]; const p4 = (t && CONFS[t.conf] && CONFS[t.conf].p4) || id === 'ND'; return p4 ? r2(clamp(0.62 + (rating - 60) * 0.016, 0.62, 1.05)) : r2(clamp(0.22 + (rating - 40) * 0.006, 0.22, 0.42)); }
const CTEAMS0_AD = {}; CONF_DEFS.forEach(([cid, , , , list]) => list.split(';').forEach(s => { const [nm, id, r] = s.split('|'); CTEAMS0_AD[id] = { name: nm, conf: cid, base: +r }; }));
const isRealMich = () => ME === 'MICH' && !state.me;
const myName = () => teamName(ME);
const myAb = () => (state.me && state.me.ab) || ME;
const myCity = () => state.me ? 'campus' : (TEAM_INFO[ME] || {}).city || 'campus';
const capacity = () => (state.me && state.me.cap) || (TEAM_INFO[ME] && TEAM_INFO[ME].cap) || STADIUM_CAP;
const rosterLimit = () => ((state.settings && state.settings.rules && +state.settings.rules.roster) || ROSTER_LIMIT) - (state.schRed && state.schRed.s === state.season + 1 ? state.schRed.n : 0) - (state.schRed && state.schRed.s === state.season && state.phase !== 'offseason' ? state.schRed.n : 0);
const CUSTOM_FAC = { stadium: null, building: 'Football operations building', indoor: 'Indoor practice facility', weight: 'Strength & conditioning', med: 'Sports medicine & recovery', academic: 'Player development center' };
function facName(id) { if (state.me) return id === 'stadium' ? state.me.stadium : CUSTOM_FAC[id]; if (!isRealMich()) return id === 'stadium' ? ((TEAM_INFO[ME] || {}).stadium || 'Home stadium') : CUSTOM_FAC[id]; return FAC_DEFS.find(f => f.id === id).name; }
// The school's rivals. Michigan keeps its real all-time series records; everyone else counts from day one.
function setupRivals() {
  const out = {}; const list = rivalsFor(ME, state.teams, x => T(x).conf);
  // a custom program inherits the local rivals of the school it replaces, but not their trophy names
  list.forEach(([id, nm], i) => { out[id] = isRealMich() && RIVAL_DATA[id] ? Object.assign({}, RIVAL_DATA[id]) : { name: state.me ? `${state.me.name}–${teamName(id)}` : nm, trophy: null, w: 0, l: 0, t: 0, note: 'Record during your tenure', arch: i === 0 }; });
  if (isRealMich()) out.OSU.arch = true;
  state.rivals = out; state.arch = list.length ? list[0][0] : null;
}
// How far below a power-conference level the program sits. Transfers and walk-ons scale down by it,
// so a Group of Six roster isn't flooded with players better than its starters.
const progShift = () => Math.max(0, Math.round((75 - (T(ME) ? T(ME).rating : 80)) * 0.6));
const archRival = () => state.arch || (state.rivals && state.rivals.OSU ? 'OSU' : null);
function clsLabel(p) { if (p.cls === 'Pro') return p.exp ? 'Year ' + (p.exp + 1) : 'Rookie'; return (p.rsUsed ? 'RS ' : '') + p.cls; }

/* ---------- personalities & captains ---------- */
// the same odds from a hash, for players made during play (no draw from the random stream)
function persOf(real, key) { const r = hash('pers:' + key); if (real) return r < 0.1 ? 'leader' : r < 0.28 ? 'worker' : r < 0.38 ? 'clutch' : 'steady'; return r < 0.08 ? 'leader' : r < 0.22 ? 'worker' : r < 0.3 ? 'clutch' : r < 0.36 ? 'diva' : r < 0.42 ? 'fragile' : 'steady'; }
function rollPers(real) {
  const r = R();
  if (real) return r < 0.1 ? 'leader' : r < 0.28 ? 'worker' : r < 0.38 ? 'clutch' : 'steady';
  return r < 0.08 ? 'leader' : r < 0.22 ? 'worker' : r < 0.3 ? 'clutch' : r < 0.36 ? 'diva' : r < 0.42 ? 'fragile' : 'steady';
}
function clutchCount() { let n = 0; ['QB', 'RB', 'WR'].forEach(pos => starters(pos).forEach(p => { if (p.pers === 'clutch') n++; })); return n; }
function captainsList() { return (state.captains || []).map(P).filter(Boolean); }
function autoCaptains() {
  const pool = state.roster.filter(p => ['Sr', 'Gr', 'Jr'].includes(p.cls) && state.depth[p.pos].indexOf(p.id) < START[p.pos]);
  pool.sort((a, b) => ((b.pers === 'leader') * 20 + b.ovr + CLASSES.indexOf(b.cls) * 2) - ((a.pers === 'leader') * 20 + a.ovr + CLASSES.indexOf(a.cls) * 2));
  const off = pool.filter(p => ['QB', 'RB', 'WR', 'TE', 'OL'].includes(p.pos)).slice(0, 2), def = pool.filter(p => ['DE', 'DT', 'LB', 'CB', 'S'].includes(p.pos)).slice(0, 2);
  state.captains = off.concat(def).map(p => p.id);
}
function leadership() { return captainsList().reduce((s, p) => s + (p.pers === 'leader' ? 3 : 1) + (['Sr', 'Gr'].includes(p.cls) ? 0.5 : 0), 0); }
function weeklyTeam(mg) {
  if (state.phase === 'offseason') return;
  let d = (leadership() - 5) * 0.25;
  let divas = 0, leaders = 0;
  state.roster.forEach(p => { const idx = state.depth[p.pos].indexOf(p.id); if (p.pers === 'diva' && p.ovr >= 74 && idx >= START[p.pos]) divas++; if (p.pers === 'leader' && idx < START[p.pos] && avail(p)) leaders++; });
  d += Math.min(1.5, leaders * 0.3) - Math.min(2, divas * 0.5);
  if (mg && mg.mResult === 'L') { const sulk = state.roster.filter(p => p.pers === 'diva' && state.depth[p.pos] && state.depth[p.pos].indexOf(p.id) >= 0 && state.depth[p.pos].indexOf(p.id) < START[p.pos]).length; d -= Math.min(1.5, sulk * 0.5); } /* a diva who starts sulks after a loss */
  state.meters.morale = clamp(Math.round((state.meters.morale + d) * 10) / 10, 0, 100);
  state.meters.morale = Math.round(state.meters.morale);
  if (state.practice === 'youth') state.roster.forEach(p => { if (['Fr', 'So'].includes(p.cls) && state.depth[p.pos].indexOf(p.id) >= START[p.pos]) p.xp = (p.xp || 0) + 1; });
  // compliance drift
  const b = annualBudget(); let risk = 0;
  if (b.niltop > 5) risk += 0.8; if (state.fin.recruit > 7) risk += 0.5; risk -= ((state.fin.compliance == null ? 1 : state.fin.compliance) - 1) * 0.5;
  state.meters.risk = clamp(Math.round((state.meters.risk + risk) * 10) / 10, 0, 100);
}

/* ---------- play calling ---------- */
function startPlayDrive(sim, s, qtr, clock, ot) {
  const start = ot && sim.otRule !== 'nfl' && sim.otRule !== 'sudden' ? 75 : clamp(25 + Math.round((sim.shortField[s] || 0) * 60), 20, 60); sim.shortField[s] = 0;
  sim.pending = { type: 'drive', s, qtr, clock, ot, ds: { yl: start, start, down: 1, togo: 10, plays: [], log: [], calls: [] } };
}
function playModel(sim) {
  const mu = michUnits(); const o = isFCS(sim.oppId) ? { runD: strength(sim.oppId).def, passD: strength(sim.oppId).def } : oppUnits(sim.oppId);
  const W = WX[sim.wx.k] || {};
  const qb = starters('QB')[0]; const rb = starters('RB')[0];
  return { runA: (mu.run - o.runD) / 10 + (W.run || 0) * 0.3, passA: (mu.pass - o.passD) / 10 + (W.pass || 0) * 0.35, acc: (qb && qb.tr && qb.tr.acc) || 60, arm: (qb && qb.tr && qb.tr.arm) || 60, spd: (rb && rb.tr && rb.tr.spd) || 70 };
}
function playHints(sim) {
  const m = playModel(sim);
  return { inside: `~${(3.4 + m.runA * 1.4).toFixed(1)} yds`, outside: `~${(3.8 + m.runA * 1.3 + (m.spd - 75) * 0.05).toFixed(1)} yds, boom or bust`, short: `${Math.round(clamp(0.67 + (m.acc - 75) * 0.006 + m.passA * 0.04, 0.4, 0.85) * 100)}% catch, ~6 yds`, deep: `${Math.round(clamp(0.36 + (m.arm - 75) * 0.006 + m.passA * 0.05, 0.15, 0.6) * 100)}% catch, 18+ yds, risky`, screen: 'Safe, sometimes breaks big' };
}
function runPlay(sim, call) {
  const p = sim.pending; if (!p || p.type !== 'drive') return;
  const ds = p.ds; const m = playModel(sim); const ctx = sim.ctx;
  const rep = ds.calls.slice(-2).filter(c => c === call).length; const pred = rep * 1.2;
  const clutch = (p.qtr >= 4 || p.ot) ? sim.clutch * 0.5 : 0;
  const rbs = starters('RB', 2), wrs = starters('WR', 3), tes = starters('TE', 1);
  let pl = { pass: false, comp: false, y: 0 }; let txt = '';
  const nm = x => x ? x.n : 'The runner';
  if (call === 'inside' || call === 'outside') {
    // the lead back tires: past 12 carries his share drops toward 45% and RB2 spells him (CL-B10)
    sim.rbLoad = sim.rbLoad || {}; const n1 = rbs[0] ? sim.rbLoad[rbs[0].id] || 0 : 0; const share1 = clamp(0.85 - Math.max(0, n1 - 12) * 0.02, 0.45, 0.85);
    const who = call === 'outside' && R() < 0.15 && ctx.qb ? ctx.qb : R() < share1 ? rbs[0] : (rbs[1] || rbs[0]);
    if (who && who !== ctx.qb) sim.rbLoad[who.id] = (sim.rbLoad[who.id] || 0) + 1;
    let y = call === 'inside' ? Math.round(3.4 + m.runA * 1.4 + gauss() * 2.6 - pred + clutch + (ds.togo <= 2 ? 1 : 0)) : Math.round(3.8 + m.runA * 1.3 + (m.spd - 75) * 0.05 + gauss() * 4.2 - pred + clutch);
    if (R() < (call === 'inside' ? 0.035 : 0.06) + m.runA * 0.01) y += ri(12, 45);
    pl = { pass: false, comp: true, y, who };
    if (R() < 0.012) { pl.fum = true; pl.comp = false; txt = `${CALLS[call]}: ${nm(who)} fumbles! ${teamName(sim.oppId)} recovers.`; }
    else txt = `${CALLS[call]}: ${nm(who)} ${y > 0 ? 'for ' + y + ' yard' + (y === 1 ? '' : 's') : y === 0 ? 'for no gain' : 'loses ' + -y + ' yard' + (y === -1 ? '' : 's')}.`;
  } else {
    const sackP = call === 'deep' ? 0.08 : call === 'short' ? 0.045 - m.passA * 0.01 : 0.02;
    const cp = call === 'deep' ? clamp(0.36 + (m.arm - 75) * 0.006 + m.passA * 0.05, 0.15, 0.6) : call === 'short' ? clamp(0.67 + (m.acc - 75) * 0.006 + m.passA * 0.04, 0.4, 0.85) : 0.82;
    const intP = call === 'deep' ? 0.055 : call === 'short' ? 0.015 : 0.01;
    const who = call === 'screen' ? (R() < 0.7 ? rbs[0] : wrs[2] || wrs[0]) : call === 'deep' ? (R() < 0.55 ? wrs[0] : wrs[1] || wrs[0]) : wpick(ctx.tg);
    if (R() < Math.max(0.01, sackP)) { const y = -ri(4, 9); pl = { pass: true, comp: false, sack: true, y: 0, ly: y }; txt = `${CALLS[call]}: ${ctx.qb ? ctx.qb.n : 'QB'} is sacked for a loss of ${-y}.`; pl.yl = y; }
    else if (R() < intP) { pl = { pass: true, comp: false, int: true, y: 0 }; txt = `${CALLS[call]}: intercepted! ${teamName(sim.oppId)} takes over.`; }
    else if (R() < cp + clutch * 0.02) {
      let y = call === 'deep' ? ri(16, 42) : call === 'short' ? Math.round(5.5 + m.passA + gauss() * 3.2 - pred + clutch) : Math.round(3 + m.runA * 0.8 + gauss() * 5 - pred);
      if (call !== 'deep' && R() < (call === 'screen' ? 0.05 : 0.04)) y += ri(10, 35);
      pl = { pass: true, comp: true, y, who }; txt = `${CALLS[call]}: ${ctx.qb ? ctx.qb.n : 'QB'} to ${nm(who)} for ${y} yard${Math.abs(y) === 1 ? '' : 's'}.`;
    } else { pl = { pass: true, comp: false, y: 0 }; txt = `${CALLS[call]}: incomplete${who ? ', intended for ' + who.n : ''}.`; }
  }
  ds.calls.push(call);
  const gain = pl.sack ? pl.yl : pl.y;
  ds.plays.push(pl);
  if (pl.int || pl.fum) { ds.log.push(txt); endPlayDrive(sim, 'to'); return; }
  ds.yl = Math.min(100, ds.yl + gain); ds.togo -= gain;
  if (ds.yl >= 100) { ds.log.push(txt + ' Touchdown!'); pl.y += 0; endPlayDrive(sim, 'td'); return; }
  if (ds.yl <= 0) { ds.yl = 1; }
  if (ds.togo <= 0) { ds.down = 1; ds.togo = Math.min(10, 100 - ds.yl); txt += ' First down.'; }
  else { ds.down++; if (ds.down > 4) { ds.log.push(txt + ' Turnover on downs.'); sim.shortField[1 - p.s] = clamp((ds.yl - 25) / 60, 0, 0.6); endPlayDrive(sim, 'downs'); return; } }
  ds.log.push(txt);
}
function fgRange(ds) { return 117 - ds.yl <= 60; }
function kickFromDrive(sim, kind) {
  const p = sim.pending; if (!p || p.type !== 'drive') return; const ds = p.ds;
  if (kind === 'fg') { p.fgDist = 117 - ds.yl; ds.log.push(`Field goal try from ${p.fgDist} yards.`); endPlayDrive(sim, 'fg'); }
  else { ds.log.push('Punt.'); endPlayDrive(sim, 'punt'); }
}
function endPlayDrive(sim, out) {
  const p = sim.pending; sim.pending = null; const ds = p.ds;
  if (!ds.plays.length) ds.plays.push({ pass: false, comp: true, y: 0, who: starters('RB')[0] });
  const drv = { s: p.s, qtr: p.qtr, clock: p.clock, ot: p.ot, out, yards: Math.max(0, ds.yl - ds.start), plays: ds.plays, fgDist: p.fgDist, pr: { d: 0 }, called: ds.log.slice(), endYl: ds.yl };
  sim.lastCalled = ds.log.slice();
  execDrive(sim, drv);
}

/* ---------- press conferences ---------- */
function maybePresser(g) {
  if (state.event || (isCoach() && ROLE_TIER[state.co.role] < 2)) return; // head coaches and coordinators face reporters
  const opp = g.h === ME ? g.a : g.h; const win = g.mResult === 'W'; const ms = g.h === ME ? g.hs : g.as, os = g.h === ME ? g.as : g.hs;
  const big = g.oppRk || rivalOf(opp) || g.type !== 'reg' || !win || ms - os >= 28;
  // rarer and spaced out: a marquee game draws reporters more often than a routine one (CL-B11)
  const marquee = rivalOf(opp) || g.type !== 'reg' || (g.oppRk && g.oppRk <= 10);
  if (!big || (state.lastPresser != null && state.lastPresser.s === state.season && state.week - state.lastPresser.wk < 3) || R() > (marquee ? 0.5 : 0.22)) return;
  state.lastPresser = { s: state.season, wk: state.week };
  const o = teamName(opp);
  const q = win ? pick([`Reporter: "That was a statement against ${o}. Is this team a real contender?"`, `Reporter: "${ms}-${os}. What did you see out there today?"`, `Reporter: "Fans are fired up after beating ${o}. What's your message to them?"`, `Reporter: "Recruits were in the stands today. What does a win like this do on the trail?"`, `Reporter: "Who stood out to you in the ${o} game?"`])
    : pick([`Reporter: "Tough loss to ${o}. Is the program headed in the right direction?"`, `Reporter: "${os}-${ms}. Does the head coach still have your full support?"`, `Reporter: "Fans are frustrated after the ${o} game. What do you tell them?"`, `Reporter: "Boosters are asking questions after ${o}. Are they right to worry?"`, `Reporter: "What has to change before next week?"`]);
  const next = mGames().find(x => !x.done && x !== g); const nextOpp = next ? oppOf(next) : null;
  let opts = win ? [
    { label: 'Stay humble', hint: 'Board +1, fans +1', fx: { board: 1, fan: 1 } },
    { label: 'Talk big', hint: 'Fans +3, locker room +2, board −1', fx: { fan: 3, morale: 2, board: -1 } },
    { label: 'Credit the players', hint: 'Locker room +3', fx: { morale: 3 } },
    ...(nextOpp && !isFCS(nextOpp) ? [{ label: `Send a message to ${teamName(nextOpp)}`, hint: 'Fans +2, but they will be fired up next week', fx: { fan: 2 }, bulletin: nextOpp }] : []),
  ] : [
    { label: 'Own it', hint: 'Board +1, locker room +1, fans −1', fx: { board: 1, morale: 1, fan: -1 } },
    { label: 'Blame the officials', hint: 'Fans +2, board −3, possible conference fine', fx: { fan: 2, board: -3 }, fine: true },
    { label: 'Back the head coach', hint: 'Hot seat −8; fans −2 if he is already on it', fx: { hot: -8, fan: state.meters.hot > 60 ? -2 : 0, morale: 1 } },
    { label: 'Call out the players', hint: 'Locker room −5, fans +1, hot seat −3', fx: { morale: -5, fan: 1, hot: -3 } },
  ];
  // a coach's answers land with his players, the fans and his boss (relationships)
  if (isCoach()) opts = win ? [
    { label: 'Credit the players', hint: 'Your starters like it (+3 rapport), fans +1', fx: { rap: 3, fan: 1 } },
    { label: 'Credit the staff and the administration', hint: `${bossName()} likes it (+3 rapport), locker room +1`, fx: { boss: 3, morale: 1 } },
    { label: 'Talk big', hint: `Fans +3, starters +1, ${bossName().toLowerCase()} −2`, fx: { fan: 3, rap: 1, boss: -2 } },
    { label: 'Stay humble', hint: `${bossName()} +1, fans +1`, fx: { boss: 1, fan: 1 } },
  ] : [
    { label: 'Own it', hint: `Starters +2, ${bossName().toLowerCase()} +2, fans −1`, fx: { rap: 2, boss: 2, fan: -1 } },
    { label: 'Back your players', hint: `Starters +4, ${bossName().toLowerCase()} −1`, fx: { rap: 4, boss: -1 } },
    { label: 'Call out the effort', hint: `Starters −4, ${bossName().toLowerCase()} +2, fans +1`, fx: { rap: -4, boss: 2, fan: 1 } },
    { label: 'Point to injuries and bad breaks', hint: `Fans −1, ${bossName().toLowerCase()} −2`, fx: { fan: -1, boss: -2 } },
  ];
  state.event = { key: 'presser', wk: state.week, title: 'Press conference', text: isPro() ? q.replace(/the program/g, 'the team').replace(/program/g, 'team') : q, opts, data: {}, def: 0 };
}
function resolvePresser(i) {
  const ev = state.event; const o = ev.opts[i]; const fx = o.fx || {};
  Object.entries(fx).forEach(([k, v]) => { if (k === 'hot') state.meters.hot = clamp(state.meters.hot + v, 0, 100); else if (k === 'rap') POS_ORDER.flatMap(pos => starters(pos)).forEach(p => rapAdj(p, v, v > 0 ? 'What you said at the press conference' : 'Called out at the press conference')); else if (k === 'boss') rapAdj(bossRel(), v, v > 0 ? 'Your press conference' : 'Your press conference'); else if (k === 'board' && isCoach()) state.co.sec = clamp(state.co.sec + v, 0, 100); else mv(k, v); });
  let msg = `You chose to ${o.label[0].toLowerCase() + o.label.slice(1)}.`; // keep team names capitalized
  if (o.bulletin) { state.bulletin = o.bulletin; msg += ` ${teamName(o.bulletin)} put your quote on their bulletin board.`; }
  if (o.fine && R() < 0.4) { state.fin.balance -= 0.05; state.fin.ytd.eventx += 0.05; msg += ' The conference fined the department $50,000.'; }
  return msg;
}

/* ---------- contract negotiation ---------- */
function negOdds(c, o, ext) {
  const m = state.meters; const ask = ext ? c.salary * 1.12 : c.salary; const wantYrs = ext ? 3 : c.years;
  const prestige = 70 + (rankOf(ME) ? 12 - rankOf(ME) * 0.3 : 0) + (m.board - 60) * 0.1 + (facLvl('building') - 3) * 3;
  let p = ext ? 0.55 + (state.meters.morale - 60) / 200 : 0.5 + (prestige - coachOvr(c)) / 40;
  p += (o.sal / ask - 1) * 1.6 + (o.yrs - wantYrs) * 0.04 + (o.buy - 0.5) * 0.3 + (o.incConf ? 0.03 : 0) + (o.incCFP ? 0.04 : 0) - (c.fails || 0) * 0.15;
  return clamp(p, 0.02, 0.98);
}
function canExtend(c) { return !!c && !c.interim && c.extS !== state.season; }
function negotiateExt(role, o) {
  const c = state.staff[role]; if (!c || c.interim) return 'gone'; if (!canExtend(c)) return 'done';
  if (R() < negOdds(c, o, true)) { c.salary = r1(o.sal); c.years = o.yrs; c.buyPct = o.buy; c.inc = { conf: o.incConf ? r1(c.salary * 0.1) : 0, cfp: o.incCFP ? r1(c.salary * 0.15) : 0 }; c.fails = 0; c.extS = state.season; mv('morale', 2); if (role === 'HC') { if (state.meters.hot > 50) { mv('fan', -5); mv('boost', -4); } state.meters.hot = Math.max(5, state.meters.hot - 15); } addNews(`${c.name} signs a new deal: ${o.yrs} years at $${c.salary.toFixed(1)}M per year.`); return 'signed'; }
  c.fails = (c.fails || 0) + 1; if (c.fails >= 3) { c.fails = 0; state.hcUnhappy = role === 'HC' ? true : state.hcUnhappy; addNews(`Extension talks with ${c.name} broke down.`, 'bad'); return 'broke'; }
  return 'counter';
}

/* ---------- media & partner deals ---------- */
function dealOffers(d) {
  const mr = rankOf(ME); const base = DEAL_DEFS.find(x => x.id === d.id).amt * econ() * (0.85 + state.meters.fan / 250 + (mr ? (26 - mr) * 0.008 : -0.05));
  return [
    { k: 'short', label: 'Short deal', yrs: 3, amt: r1(base * 1.05), bonus: 0, perf: false, desc: 'Three years at a strong rate. Renegotiate soon.' },
    { k: 'long', label: 'Long deal', yrs: 8, amt: r1(base * 0.93), bonus: r1(base * 1.5), perf: false, desc: `Eight years, slightly less per year, plus a $${r1(base * 1.5)}M signing bonus now.` },
    { k: 'perf', label: 'Performance deal', yrs: 5, amt: r1(base * 0.8), bonus: 0, perf: true, desc: 'Five years at a lower base. +$1.5M for each playoff trip and +$0.5M for each 10-win season.' },
  ];
}
function signDeal(id, k) {
  const d = state.deals.find(x => x.id === id); if (!d || !dealOpen(d)) return; const o = dealOffers(d).find(x => x.k === k); if (!o) return;
  d.amt = o.amt; d.thru = state.season + o.yrs; d.perf = o.perf; d.kind = o.label;
  if (o.bonus) { state.fin.balance += o.bonus; state.fin.ytd.events += o.bonus; }
  addNews(`New ${d.name.toLowerCase()}: $${o.amt}M per year through ${d.thru}${o.bonus ? ` with a $${o.bonus}M signing bonus` : ''}.`);
}
const dealOpen = d => d.thru - state.season <= 1;

/* ---------- board meeting ---------- */
function boardApprove(base) { return clamp(base + (state.meters.board - 60) / 100 + (state.off && state.off.review && state.off.review.fin.net > 0 ? 0.12 : -0.12), 0.05, 0.95); }
function presentBoard(ch) {
  if (state.off && state.off.boardRes) return; // one meeting per offseason
  const res = [];
  if (ch.stance === 'invest') { if (R() < boardApprove(0.5)) { const before = state.fin.recruit; state.fin.recruit = r1(clamp(before + 1.5, 1, 10)); state.mediaBonus = state.mediaBonus || 0; res.push(state.fin.recruit > before ? `Approved: more money for recruiting (+$${r1(state.fin.recruit - before)}M).` : 'Approved, but the recruiting budget is already at the $10M maximum.'); } else { mv('board', -2); res.push('Rejected: the board would not raise football spending.'); } }
  else if (ch.stance === 'lean') { if (state.fin.recruit > 1) { state.fin.recruit = r1(clamp(state.fin.recruit - 1, 1, 10)); mv('board', 3); res.push('Approved: a leaner budget. The board appreciates the discipline.'); } else res.push('No change: the recruiting budget is already at the $1M minimum.'); }
  else res.push('Approved: a balanced budget.');
  if (ch.fac && ch.fac !== 'none') { const f = state.facilities.find(x => x.id === ch.fac); if (f && !f.building && f.lvl < 5) { if (R() < boardApprove(0.45)) { const c = facCost(f.lvl) * 0.5; state.fin.balance -= c; f.building = true; res.push(`Approved: the university pays half of the ${facName(f.id)} upgrade. You pay $${c.toFixed(1)}M.`); } else res.push(`Rejected: no university money for ${facName(f.id)} this year.`); } }
  if (ch.tix === 'raise') { if (state.fin.ticket >= LEVERS.ticket.max) res.push(`No change: tickets are already at the $${LEVERS.ticket.max} maximum.`); else if (R() < (state.meters.fan >= 55 ? 0.85 : 0.4)) { const d = Math.min(10, LEVERS.ticket.max - state.fin.ticket); state.fin.ticket += d; mv('fan', -Math.round(3 * d / 10)); res.push(`Approved: ticket prices go up $${d}.`); } else res.push('Rejected: no ticket increase.'); }
  else if (ch.tix === 'cut') { if (state.fin.ticket <= LEVERS.ticket.min) res.push(`No change: tickets are already at the $${LEVERS.ticket.min} minimum.`); else { const d = Math.min(10, state.fin.ticket - LEVERS.ticket.min); state.fin.ticket -= d; mv('fan', Math.round(3 * d / 10)); res.push(`Approved: ticket prices drop $${d}.`); } }
  if (mediaDue()) res.push(settleMedia(ch.media || 'linear'));
  if (ch.move && ch.move !== 'none') { const ok = tryMove(ch.move); res.push(ok ? `Approved: ${myName()} joins the ${CONFS[ch.move].name} next season (exit fee $${moveFee(ch.move)}M).` : `The ${CONFS[ch.move].name} said no to your application.`); if (ok) mv('board', CONFS[ch.move].p4 && !CONFS[T(ME).conf].p4 ? 4 : 0); }
  const v = state.off.vote;
  if (v) { v.yes = ch.vote === 'yes'; v.passed = R() < (v.yes ? 0.85 : 0.25); res.push(v.passed ? `The conference approved adding ${v.teams.map(teamName).join(' and ')}. They join next season.` : `Expansion failed. ${v.teams.map(teamName).join(' and ')} stay put.`); }
  state.off.boardRes = res; res.forEach(r => addNews('Board meeting: ' + r));
}

/* ---------- compliance ---------- */
function extraContact(id) { const r = state.rec.list.find(x => x.id === id); if (!r || r.contact || r.status !== 'open') return; r.contact = true; r.interest = clamp(r.interest + 8, 1, 99); state.meters.risk = clamp(state.meters.risk + 3, 0, 100); }
function investigate() {
  const risk = state.meters.risk; const chance = risk / 200 * (1 - ((state.fin.compliance == null ? 1 : state.fin.compliance) - 1) * 0.15);
  let out = null;
  if (R() < chance) {
    if (risk < 40) { state.fin.balance -= 1; mv('board', -5); out = 'Minor violation: $1M fine.'; }
    else if (risk < 70) { state.fin.balance -= 2; state.schRed = { s: state.season + 1, n: 5 }; mv('board', -10); out = 'Level II violation: $2M fine and five fewer roster spots next season.'; }
    else { state.ban = state.season + 1; mv('board', -18); mv('fan', -8); const h = state.history[state.history.length - 1]; if (h) h.vacated = true; out = `Level I violation: a postseason ban for ${state.season + 1} and this season's wins are vacated.`; }
    state.investigations.push({ s: state.season, out }); addNews('NCAA investigation: ' + out, 'bad');
  }
  state.meters.risk = Math.round(risk * 0.6);
  return out;
}

/* ---------- league: realignment, carousel, national recruiting ---------- */
function expansionCandidates() { const me = T(ME).conf; return Object.values(state.teams).filter(t => t.conf !== me && ['ACC', 'B12'].includes(t.conf) && t.id !== 'ND').sort((a, b) => b.rating - a.rating).slice(0, 2).map(t => t.id); }
function realign() {
  const moves = [];
  if (state.off && state.off.vote && state.off.vote.passed) { state.off.vote.teams.forEach(id => { moves.push([id, T(id).conf, T(ME).conf]); T(id).conf = T(ME).conf; }); state.mediaBonus = (state.mediaBonus || 0) + 3; }
  if (R() < 0.15) {
    const g6 = Object.values(state.teams).filter(t => !CONFS[t.conf].p4 && t.id !== 'ND' && t.id !== ME && t.rating >= 64).sort((a, b) => b.rating - a.rating)[0];
    if (g6) { const to = pick(['B12', 'ACC', 'P12'].filter(c => c !== g6.conf)); moves.push([g6.id, g6.conf, to]); g6.conf = to; }
  }
  if (state.myMove && state.myMove.s === state.season - 0 && state.myMove.done !== true) { const mm = state.myMove; moves.push([ME, T(ME).conf, mm.to]); T(ME).conf = mm.to; mm.done = true; } // your program's own move
  if (moves.length) { rebuildConfs(); moves.forEach(([id, from, to]) => addNews(`Realignment: ${teamName(id)} moves from the ${CONFS[from].name} to the ${CONFS[to].name}.`, 'big')); state.confMoves = (state.confMoves || []).concat(moves.map(m => ({ s: state.season + 1, id: m[0], from: m[1], to: m[2] }))); }
}
function otherCarousel() {
  const changes = [];
  const mk = isCoach() && state.co.market ? new Set(state.co.market.open.filter(o => o.role === 'HC' && o.tid !== ME).map(o => o.tid)) : null;
  Object.values(state.teams).forEach(t => {
    if (t.id === ME) return; const last = { w: t.w, l: t.l };
    const p4 = CONFS[t.conf].p4;
    if (mk ? mk.has(t.id) : (p4 && last.w <= 4 && R() < 0.55) || (!p4 && last.w <= 3 && R() < 0.4)) {
      const old = t.coach; t.coach = treePromote(t.id) || genName(); const bump = gauss() * 2.5; t.rating = r1(clamp(t.rating + bump, 38, 96)); t.off = r1(t.rating + gauss() * 2); t.def = r1(2 * t.rating - t.off);
      changes.push(`${t.name} fires ${old} and hires ${t.coach}.`);
    }
  });
  if (changes.length) { changes.slice(0, 5).forEach(c => addNews('Coaching carousel: ' + c)); if (changes.length > 5) addNews(`Coaching carousel: ${changes.length} programs changed head coaches this offseason.`); }
}
function nationalClasses(mine) {
  const rc = state.rec; const stolen = {};
  rc.list.forEach(r => { if (r.status === 'lost' && r.to && T(r.to)) stolen[r.to] = (stolen[r.to] || 0) + (r.star === 5 ? 100 : r.star === 4 ? 60 : 28) + r.pot * 0.2; });
  const rows = Object.values(state.teams).filter(t => t.id !== ME).map(t => ({ id: t.id, sc: Math.round((t.rating - 40) * 26 + (CONFS[t.conf].p4 ? 260 : 0) + (t.elo - 1500) * 0.3 + gauss() * 110 + (stolen[t.id] || 0)) }));
  rows.push({ id: ME, sc: Math.round(classScore(mine)) });
  rows.sort((a, b) => b.sc - a.sc);
  rows.forEach((r, i) => { T(r.id).classRank = i + 1; });
  rc.nat = rows.slice(0, 25);
  const mine2 = rows.findIndex(r => r.id === ME) + 1; state.natClasses = { s: state.season, rows: rows.slice(0, 25), mine: mine2 };
  return mine2;
}

/* ---------- walk-ons ---------- */
function holdTryouts() {
  if (state.tryouts === state.season) return; state.tryouts = state.season; state.fin.balance -= 0.1;
  state.walkons = [];
  for (let i = 0; i < 6; i++) { const pos = pick(POS_ORDER); const gem = R() < 0.12; const b = genBody(pos); state.walkons.push({ id: 'w' + i + Math.floor(R() * 1e6), n: genName(), pos, ovr: ri(48, 64) - Math.round(progShift() / 2), pot: (gem ? ri(84, 93) : ri(56, 78)) - Math.round(progShift() / 3), gem, home: pick(TOWNS)[0], ht: b.ht, wt: b.wt }); }
}
function addWalkon(id) {
  const w = (state.walkons || []).find(x => x.id === id); if (!w || w.added) return 'gone'; if (state.roster.length >= rosterLimit()) return 'full';
  const p = makePlayer({ num: freeNumber(w.pos), n: w.n, pos: w.pos, cls: 'Fr', ht: w.ht, wt: w.wt, home: w.home, ovr: w.ovr, pot: w.pot, real: false, walkon: true, pay: 0 });
  state.roster.push(p); rebuildPMap(); state.depth[w.pos].push(p.id); w.added = true; addNews(`Walk-on ${w.n} (${w.pos}) joins the program after tryouts.`); return 'ok';
}
function awardScholarship(pid) { const p = P(pid); if (!p || !p.walkon) return; p.walkon = false; p.exWalkon = true; p.pay = Math.max(p.pay, 0.02); mv('morale', 1); addNews(`${p.n} is put on scholarship. The locker room erupts.`, 'win'); }

/* ---------- careers ---------- */
function recordCareers() {
  state.roster.forEach(p => { (p.hist = p.hist || []).push({ s: state.season, cls: clsLabel(p), pos: p.pos, ovr: p.ovr, gp: p.gp, st: Object.assign({}, p.st) }); });
}
function applyRedshirts() {
  state.roster.forEach(p => { if (!p.rsUsed && p.gp <= 4 && p.cls !== 'Gr') { p.rsUsed = true; p.rsThisYear = true; if (p.injSE) p.medRS = true; } });
}

/* ---------- season recap ---------- */
function buildRecap(delta) {
  const games = mGames().filter(g => g.done);
  const val = g => { const opp = oppOf(g); const e = T(opp) ? T(opp).elo : 1200; const mm = (g.h === ME ? g.hs - g.as : g.as - g.hs); return e + mm * 5; };
  const wins = games.filter(g => g.mResult === 'W'), losses = games.filter(g => g.mResult === 'L');
  const best = wins.sort((a, b) => val(b) - val(a))[0], worst = losses.sort((a, b) => val(a) - val(b))[0];
  const comeback = wins.filter(g => (g.minM || 0) <= -10).sort((a, b) => a.minM - b.minM)[0];
  const top = state.roster.filter(p => Object.keys(p.st).length).map(p => ({ n: p.n, pos: p.pos, sc: heisScore(p.st, p.pos, ME), line: statLineRaw(p.pos, p.st) })).sort((a, b) => b.sc - a.sc).slice(0, 3);
  const sc = g => { const a = g.h === ME ? g.hs : g.as, b = g.h === ME ? g.as : g.hs; return `${a}-${b}`; };
  return {
    best: best ? { opp: teamName(oppOf(best)), score: sc(best), id: best.id } : null, worst: worst ? { opp: teamName(oppOf(worst)), score: sc(worst), id: worst.id } : null,
    comeback: comeback ? { opp: teamName(oppOf(comeback)), score: sc(comeback), down: -comeback.minM } : null,
    top, grade: delta >= 12 ? 'A' : delta >= 5 ? 'B' : delta >= -2 ? 'C' : delta >= -8 ? 'D' : 'F',
  };
}
function statLineRaw(pos, st) { const g = k => st[k] || 0; if (pos === 'QB') return `${g('py')} pass yds, ${g('ptd')} TD`; if (pos === 'RB') return `${g('ry')} rush yds, ${g('rtd')} TD`; if (['WR', 'TE'].includes(pos)) return `${g('rcy')} rec yds, ${g('rctd')} TD`; return `${g('tk')} tkl, ${g('sk')} sk, ${g('int')} INT`; }

/* ---------- achievements & legacy ---------- */
function unlock(id) { if (state.ach[id]) return; state.ach[id] = { s: state.season }; const a = ACH.find(x => x[0] === id); addNews(`Achievement unlocked: ${a[1]}. ${a[2]}`, 'big'); state.achToast = a[1]; }
function checkAch(when, g) {
  const games = mGames(); const wins = games.filter(x => x.mResult === 'W');
  if (wins.length) unlock('first_win');
  if (g && g.done && g.mResult === 'W') {
    const opp = oppOf(g); const m = g.h === ME ? g.hs - g.as : g.as - g.hs;
    if (opp === archRival()) unlock('beat_osu');
    if (g.oppRk && g.oppRk <= 10 && m >= 21) unlock('blowout');
    if ((g.minM || 0) <= -17) unlock('comeback');
  }
  if (rankOf(ME) === 1) unlock('no1');
  if (wins.length >= 10) unlock('ten');
  { const nR = Object.keys(state.rivals || {}).length; const yrs = {}; state.rivalLog.filter(x => x.win).forEach(x => (yrs[x.s] = yrs[x.s] || new Set()).add(x.opp)); if (nR >= 2 && Object.values(yrs).some(s => s.size >= nR)) unlock('triple'); const ar = state.rivalLog.filter(x => x.opp === archRival()); if (ar.length >= 5 && ar.slice(-5).every(x => x.win)) unlock('osu5'); }
  if (state.roster.some(p => (p.walkon || p.exWalkon) && state.depth[p.pos].indexOf(p.id) < START[p.pos])) unlock('walkon');
  if (state.facilities.some(f => f.lvl >= 5)) unlock('maxfac');
  if (when === 'final') {
    if (games.some(x => x.type === 'cfp')) unlock('cfp');
    if (state.champ === ME) unlock('natl');
    if (games.some(x => x.type === 'ccg' && x.mResult === 'W')) unlock('b1g');
    if (games.length >= 12 && games.every(x => x.mResult === 'W')) unlock('undefeated');
    const home = games.filter(x => x.att); if (home.length >= 5 && home.every(x => x.att >= capacity() * 0.995)) unlock('fullhouse');
  }
  if (when === 'season') {
    const h = state.history; const aw = state.awards[state.awards.length - 1];
    if (aw && aw.heis[0] && aw.heis[0].tm === ME) unlock('heisman');
    if (h.length >= 3 && h.slice(-3).every(x => x.net >= 0)) unlock('profit3');
    if (h.length >= 5 && h.slice(0, 5).every(x => x.net >= 0)) unlock('profit_all');
    if (state.settings.diff === 'hard' && !state.gameOver) unlock('hard');
    if (h.length >= 10) unlock('decade');
    if (h.length >= 5 && !state.investigations.some(x => x.s > state.season - 5)) unlock('clean');
  }
  if (when === 'draft') { const byYr = {}; state.draft.filter(d => d.rd === 1).forEach(d => byYr[d.s] = (byYr[d.s] || 0) + 1); if (Object.values(byYr).some(n => n >= 3)) unlock('picks3'); }
  if (when === 'class' && state.rec && state.rec.classRank && state.rec.classRank <= 5) unlock('class5');
}
function legacyScore() {
  const h = state.history; const tr = state.trophies;
  const natl = tr.filter(t => t.k === 'natl').length, conf = tr.filter(t => t.k === 'conf').length, cfp = tr.filter(t => t.k === 'cfp').length;
  const wins = h.reduce((s, x) => s + (x.vacated ? 0 : x.w), 0); const osu = state.rivalLog.filter(x => x.opp === archRival() && x.win).length;
  const profit = h.filter(x => x.net >= 0).length; const r1c = state.draft.filter(d => d.rd === 1).length, picks = state.draft.length - r1c;
  const heis = state.awards.filter(a => a.heis[0] && a.heis[0].tm === ME).length;
  const ach = Object.keys(state.ach || {}).reduce((s, id) => s + (ACH.find(a => a[0] === id) || [0, 0, 0, 0])[3], 0);
  const raw = natl * 100 + conf * 40 + cfp * 20 + wins * 2 + osu * 10 + profit * 5 + r1c * 8 + picks * 2 + heis * 30 + ach;
  return Math.round(raw * (LEGACY_MULT[state.settings.diff] || 1));
}

/* ---------- custom program ---------- */
function applyCustom(c) {
  const t = state.teams[ME]; t.name = c.name; t.conf = c.conf; t.style = genStyle();
  state.me = { name: c.name, ab: (c.ab || c.name.slice(0, 4)).toUpperCase().slice(0, 5), stadium: c.stadium || c.name + ' Stadium', cap: clamp(+c.cap || 60000, 15000, 115000), c1: c.c1 || '#F5C518', c2: c.c2 || '#00274C', tier: c.tier, cfg: c };
  const mates = Object.values(state.teams).filter(x => x.conf === c.conf && x.id !== ME); const avg = mates.length ? mates.reduce((a, x) => a + x.rating, 0) / mates.length : 70;
  state.me.base = Math.round(clamp(avg + { power: 10, mid: 1, rebuild: -6 }[c.tier], 50, 88));
  t.rating = state.me.base; t.elo = 1500 + (t.rating - 70) * 12;
  state.deals = DEAL_DEFS.map(d => Object.assign({}, d, { amt: r1(d.amt * econ()) }));
  state.facilities.forEach(f => f.lvl = c.tier === 'power' ? 4 : c.tier === 'mid' ? 3 : 2);
}
function genCustomRoster(base) {
  const counts = { QB: 4, RB: 5, WR: 10, TE: 5, OL: 16, DE: 9, DT: 8, LB: 9, CB: 9, S: 8, K: 2, P: 2, LS: 1 };
  Object.entries(counts).forEach(([pos, n]) => {
    for (let i = 0; i < n; i++) {
      const cls = pick(['Fr', 'Fr', 'So', 'So', 'Jr', 'Jr', 'Sr', 'Sr', 'Gr']); const b = genBody(pos);
      const starterish = i < START[pos] + 1; const ovr = clamp(Math.round(base + (starterish ? 2 : -7) + gauss() * 4 + CLASSES.indexOf(cls) * 1.2), 45, 92);
      const pot = clamp(ovr + { Fr: 14, So: 10, Jr: 6, Sr: 3, Gr: 1 }[cls] + ri(0, 8), ovr, 97);
      state.roster.push(makePlayer({ num: 0, n: genName(), pos, cls, ht: b.ht, wt: b.wt, home: recruitTown(TEAM_STATE[ME])[0], ovr, pot, real: false }));
    }
  });
  rebuildPMap(); state.roster.forEach(p => { p.num = freeNumber(p.pos); });
}
function genCustomStaff(base) {
  const st = {}; STAFF_ROLES.forEach(r => { const c = genCandidates(r, 3)[1]; c.salary = r1(Math.max(0.1, c.salary * Math.max(0.3, econ()))); if (r === 'HC') { ['off', 'def', 'rec', 'dev', 'gm'].forEach(k => c[k] = clamp(Math.round(base + gauss() * 4), 55, 92)); } else c.ovr = clamp(Math.round(base - 2 + gauss() * 4), 55, 90); c.bg = 'Current staff'; st[r] = c; });
  if (st.HC && T(ME) && T(ME).coach && !state.me) st.HC.name = T(ME).coach;
  return st;
}
function ownSchedule() {
  const me = T(ME); const c = CONFS[me.conf]; const cg = c.confGames ? Math.min(c.confGames, c.teams.length - 1) : 0;
  const sched = []; const used = new Set([ME]); const book = ncBooked(state.season);
  const nonConf = Object.values(state.teams).filter(t => t.conf !== me.conf && t.id !== ME);
  const g5 = nonConf.filter(t => !CONFS[t.conf].p4 && t.id !== 'ND');
  const addBook = wk => { const b = book.find(x => x.wk === wk); if (b && !used.has(b.opp) && (isFCS(b.opp) || T(b.opp).conf !== me.conf)) { used.add(b.opp); sched.push([wk, b.opp, b.site !== 'A' ? 1 : 0, b.site === 'N' ? { neutral: true, payout: b.payout, loc: b.loc, name: 'Neutral site: ' + b.loc } : b.fee ? { fee: b.fee } : null]); return true; } return false; };
  if (cg) {
    // rivals from other conferences fill the early non-conference weeks before a buy game does
    const ncRv = Object.keys(state.rivals || {}).filter(id => T(id) && T(id).conf !== me.conf);
    [1, 2, 3].forEach(wk => { if (!addBook(wk)) { const rvO = ncRv.find(id => !used.has(id)); if (rvO) { used.add(rvO); sched.push([wk, rvO, (state.season + rvO.length + wk) % 2]); return; } const o = pick(g5.filter(t => !used.has(t.id))).id; used.add(o); sched.push([wk, o, 1, { fee: r1(rnd(1.2, 1.8)) }]); } });
    // Conference rivals are always on the schedule; the archrival closes the regular season.
    const rv = Object.keys(state.rivals || {}).filter(id => T(id) && T(id).conf === me.conf);
    const arch = archRival(); const lastWk = rv.includes(arch) ? arch : null;
    const pool = shuffle(c.teams.filter(t => t !== ME && !rv.includes(t)));
    const opps = rv.filter(x => x !== lastWk).concat(pool).slice(0, cg - (lastWk ? 1 : 0));
    const bye = ri(5, 9); const weeks = []; for (let w = 4; w <= 13; w++) if (w !== bye && !(lastWk && w === 13)) weeks.push(w);
    const wsel = shuffle(weeks).slice(0, opps.length).sort((a, b) => a - b);
    shuffle(opps).forEach((o, i) => { used.add(o); sched.push([wsel[i], o, i % 2 === 0 ? 1 : 0]); });
    if (lastWk) { used.add(lastWk); sched.push([13, lastWk, state.season % 2 === 1 ? 1 : 0]); }
    // non-conference rivals take an open week (the archrival gets week 13 when it's free)
    Object.keys(state.rivals || {}).filter(id => T(id) && T(id).conf !== me.conf && !used.has(id)).forEach(id => {
      const free = []; for (let w = 4; w <= 13; w++) if (!sched.some(x => x[0] === w) && w !== bye) free.push(w);
      if (!free.length || sched.length >= 12) return; const w = id === arch && free.includes(13) ? 13 : free[free.length - 1];
      used.add(id); sched.push([w, id, (state.season + id.length) % 2]);
    });
    const open = []; for (let w = 4; w <= 13; w++) if (!sched.some(x => x[0] === w)) open.push(w);
    while (sched.length < 12 && open.length > 1) { const w = open.splice(ri(0, open.length - 1), 1)[0]; const o = pick(nonConf.filter(t => !used.has(t.id))).id; used.add(o); sched.push([w, o, R() < 0.5 ? 1 : 0]); }
  } else {
    const pool = shuffle(nonConf.slice()); const bye = ri(5, 9); let k = 0;
    // independents keep their rivals; the archrival closes the season
    const rvI = Object.keys(state.rivals || {}).filter(id => T(id)); const arch = archRival();
    for (let w = 1; w <= 13; w++) { if (w === bye) continue; if (w <= 3 && addBook(w)) continue; let o = w === 13 && arch && rvI.includes(arch) && !used.has(arch) ? arch : w >= 9 ? rvI.find(id => !used.has(id) && id !== arch) : null; if (!o) o = pool.find(t => !used.has(t.id) && !rvI.includes(t.id)).id; used.add(o); sched.push([w, o, k++ % 2 === 0 ? 1 : 0]); }
  }
  return sched;
}

/* ---------- automation for multi-year sims ---------- */
function autoBoard() { if (!state.off.boardRes) presentBoard({ stance: finTotals().net >= 0 ? 'balanced' : 'lean', fac: 'none', tix: 'hold', vote: 'yes' }); }
function autoDeals() { (state.deals || []).forEach(d => { if (d.thru < state.season + 1) signDeal(d.id, 'short'); }); }
function autoSeason() {
  autoSeasonRecruiting(); let n = 0;
  while (state.phase !== 'offseason' && !state.gameOver && n++ < 40) advance();
  if (!state.gameOver) autoOffseason();
}

function autoFinishDrive(sim) {
  let g = 0; while (sim.pending && sim.pending.type === 'drive' && g++ < 60) { const ds = sim.pending.ds; if (ds.down === 4) { if (fgRange(ds) && 117 - ds.yl <= 52) kickFromDrive(sim, 'fg'); else if (ds.togo <= 2 && ds.yl >= 45) runPlay(sim, 'inside'); else kickFromDrive(sim, 'punt'); } else runPlay(sim, pick(['inside', 'outside', 'short', 'short', 'screen', 'deep'])); }
}

/* ---------- NFL Draft (AD mode) ----------
 * Each season's draft class is everyone draft-eligible across the country: your seniors and
 * likely early entrants, every other school's star players, and depth prospects generated from
 * each program's strength. Boards, the NFL standings that set the order, and teams' picks all come
 * from seeded generators keyed to the save and the year, so looking at the Draft tab never moves the
 * game's random sequence, and the same save always produces the same draft. */
const DPOS_ADJ = { QB: 2.5, DE: 1.5, CB: 1, OL: 0.8, WR: 0.5, DT: 0.3, LB: 0, S: -0.5, TE: -1, RB: -1.2, K: -9, P: -9, LS: -14 };
const draftYear = () => state.season + 1; // the class built from this season plays in next April's draft
function draftVal(ovr, pos, cls, key, bonus) { return r1(ovr + (DPOS_ADJ[pos] || 0) + (cls === 'Jr' || cls === 'So' ? 0.8 : 0) + (bonus || 0) + (hash(key + ':combine') - 0.5) * 3); }
function honorBonus(p) { const a = p.awards || []; const yr = a.filter(x => typeof x === 'string' && x.startsWith(String(state.season))); return (yr.some(x => /Heisman/.test(x)) ? 1.5 : 0) + (yr.some(x => /All-America/.test(x)) ? 1 : 0); }
// my players who would be in this class: seniors and graduates, plus juniors good enough to leave early
function myDraftables() {
  if (state.phase === 'offseason' && state.off && state.off.declared) return state.off.declared.map(d => Object.assign({}, d, { mine: true, tm: ME }));
  // the same bar the departures step uses: graduates 80+, seniors 79+, juniors 87+ may leave early
  return state.roster.filter(p => (p.cls === 'Gr' && p.ovr >= 80) || (p.cls === 'Sr' && p.ovr >= 79) || (p.cls === 'Jr' && p.ovr >= 87)).map(p => ({ id: p.id, n: p.n, pos: p.pos, cls: p.cls, ovr: p.ovr, tm: ME, mine: true, early: p.cls === 'Jr', v: draftVal(p.ovr, p.pos, p.cls, state.seed + ':' + p.id, honorBonus(p)) }));
}
let DP_CACHE = null;
function depthProspects() {
  const key = state.seed + ':dp:' + state.season + ':' + Object.keys(state.teams).length;
  if (DP_CACHE && DP_CACHE.key === key) return DP_CACHE.list;
  const r = lrng(key); const pk = a => a[Math.floor(r() * a.length)]; const g = () => { let u = 0, v = 0; while (!u) u = r(); while (!v) v = r(); return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v); };
  const POSW = [['QB', 3], ['RB', 5], ['WR', 9], ['TE', 4], ['OL', 12], ['DE', 7], ['DT', 6], ['LB', 7], ['CB', 8], ['S', 6], ['K', 1], ['P', 1], ['LS', 0.4]]; const tot = POSW.reduce((s, x) => s + x[1], 0);
  const wp = () => { let x = r() * tot; for (const [p, w] of POSW) { x -= w; if (x <= 0) return p; } return 'OL'; };
  const list = [];
  Object.values(state.teams).forEach(t => {
    if (t.id === ME) return; const base = CONFS[t.conf].p4 || t.id === 'ND' ? 2.2 : 0.5; const n = Math.max(0, Math.round(base + (t.rating - 60) / 7 + g() * 0.8));
    for (let i = 0; i < n; i++) { const pos = wp(); const cls = r() < 0.18 ? 'Jr' : r() < 0.3 ? 'Gr' : 'Sr'; const ovr = clamp(Math.round(t.rating - 3 + g() * 4.5), 50, 96); const id = 'dp' + t.id + i;
      list.push({ id, n: pk(FIRST) + ' ' + pk(LAST), pos, cls, ovr, tm: t.id, v: draftVal(ovr, pos, cls, key + id) }); }
  });
  DP_CACHE = { key, list }; return list;
}
// the whole class, best first
function draftClass() {
  const out = myDraftables();
  Object.values(state.teams).forEach(t => { if (t.id === ME || !t.stars) return; t.stars.forEach(x => { if (x.cls === 'Sr' || x.cls === 'Gr' || (x.cls === 'Jr' && x.ovr >= 88)) out.push({ id: x.id, n: x.n, pos: x.pos, cls: x.cls, ovr: x.ovr, tm: t.id, star: true, v: draftVal(x.ovr, x.pos, x.cls, state.seed + ':' + x.id, x.ovr >= 95 ? 1 : 0) }); }); });
  return out.concat(depthProspects()).sort((a, b) => b.v - a.v || a.id.localeCompare(b.id));
}
// projected slot for a board position (1-based); 0 means likely undrafted
const projPick = rank => (rank <= DRAFT_PICKS ? rank : 0);
function projLabel(rank) { const pk = projPick(rank); if (!pk) return 'Undrafted'; const rd = pickRound(pk); return pk <= 10 ? 'Top 10' : rd === 1 ? 'Round 1' : 'Round ' + rd; }

// NFL standings for a season: each club's strength drifts year to year from its 2026 level
function nflPowers(season) {
  const pw = {}; NFL.forEach(t => pw[t.id] = t.p);
  for (let y = 2026; y <= season; y++) { const r = lrng(state.seed + ':nflpow:' + y); NFL.forEach(t => { const drift = (r() + r() + r() - 1.5) * 9; pw[t.id] = clamp(Math.round(pw[t.id] * 0.62 + 76 * 0.38 + drift), 52, 97); }); }
  return pw;
}
function nflSeason(season) {
  const pw = nflPowers(season); const r = lrng(state.seed + ':nflsea:' + season);
  const rows = NFL.map(t => { let w = 0; for (let g = 0; g < 17; g++) { const opp = NFL[Math.floor(r() * 32)]; const oppP = opp.id === t.id ? 76 : pw[opp.id]; if (r() < 1 / (1 + Math.exp(-(pw[t.id] - oppP) / 9))) w++; } return { id: t.id, w, l: 17 - w, p: pw[t.id] }; });
  // seven playoff teams a conference: four division winners and three wild cards
  const seeds = {}; ['AFC', 'NFC'].forEach(cf => { const c = rows.filter(x => NFL_BY[x.id].conf === cf).sort((a, b) => b.w - a.w || b.p - a.p);
    const divW = ['East', 'North', 'South', 'West'].map(dv => c.find(x => NFL_BY[x.id].div === dv)); const wc = c.filter(x => !divW.includes(x)).slice(0, 3); seeds[cf] = divW.sort((a, b) => b.w - a.w || b.p - a.p).concat(wc); });
  const pf = x => 1 / (1 + Math.exp(-(x.p - 76) / 6)) + x.w / 17; const champOf = list => { let best = null, bs = -1; list.forEach(x => { const s = pf(x) * (0.6 + r()); if (s > bs) { bs = s; best = x; } }); return best; };
  const afc = champOf(seeds.AFC), nfc = champOf(seeds.NFC); const champ = r() < pf(afc) / (pf(afc) + pf(nfc)) ? afc : nfc; const runner = champ === afc ? nfc : afc;
  const inPO = new Set(seeds.AFC.concat(seeds.NFC).map(x => x.id));
  return { season, rows, playoff: inPO, champ: champ.id, runner: runner.id };
}
// first-round order: non-playoff teams worst first, then playoff teams, Super Bowl loser and winner last
function draftOrder(season) {
  const ns = nflSeason(season); const key = x => (x.id === ns.champ ? 3 : x.id === ns.runner ? 2 : ns.playoff.has(x.id) ? 1 : 0);
  return ns.rows.slice().sort((a, b) => key(a) - key(b) || a.w - b.w || a.p - b.p).map(x => x.id);
}
// every pick: team for each slot, compensatory picks spread by a seeded draw
function draftSlots(season) {
  const order = draftOrder(season); const r = lrng(state.seed + ':comp:' + season); const slots = [];
  DRAFT_ROUNDS.forEach((n, ri0) => { for (let i = 0; i < n; i++) slots.push({ rd: ri0 + 1, tm: i < 32 ? order[i] : order[Math.floor(r() * 32)] }); });
  return slots.map((s, i) => Object.assign(s, { no: i + 1, inRd: i + 1 - DRAFT_ROUNDS.slice(0, s.rd - 1).reduce((a, b) => a + b, 0) }));
}
// mock or real: teams take the best player left, with a little team-by-team preference
function simDraft(season, pool) {
  const slots = draftSlots(season); const left = pool.slice(); const picks = [];
  slots.forEach(s => {
    let bi = 0, bv = -1e9; for (let i = 0; i < Math.min(14, left.length); i++) { const x = left[i]; const v = x.v + (hash(state.seed + ':' + s.tm + ':' + x.id) - 0.5) * 3.2 - i * 0.05; if (v > bv) { bv = v; bi = i; } }
    if (!left.length) return; const x = left.splice(bi, 1)[0]; picks.push(Object.assign({}, s, { id: x.id, n: x.n, pos: x.pos, cls: x.cls, ovr: x.ovr, school: x.tm, mine: !!x.mine }));
  });
  return { picks, undrafted: left };
}
// The real draft, run at the offseason's NFL Draft step.
function runADDraft() {
  const o = state.off; if (o.nfl) return o.nfl; const yr = draftYear();
  const pool = draftClass(); const res = simDraft(state.season, pool);
  const mine = res.picks.filter(p => p.mine); const udfa = res.undrafted.filter(x => x.mine);
  const rFA = lrng(state.seed + ':udfa:' + yr);
  mine.forEach(p => { state.draft.push({ s: yr, n: p.n, pos: p.pos, rd: p.rd, no: p.no, inRd: p.inRd, tm: p.tm });
    const al = state.alumni.find(a => (a.pid && a.pid === p.id) || (!a.pid && a.n === p.n && a.last === state.season)); if (al) al.where = `Drafted by the ${nflName(p.tm)}: round ${p.rd}, pick ${p.no} overall, ${yr} NFL Draft`; });
  udfa.forEach(x => { const tm = NFL[Math.floor(rFA() * 32)].id; const al = state.alumni.find(a => (a.pid && a.pid === x.id) || (!a.pid && a.n === x.n && a.last === state.season)); if (al) al.where = `Undrafted; signed with the ${nflName(tm)} as a free agent`; });
  const top = res.picks[0];
  o.nfl = { year: yr, picks: res.picks.map(p => ({ no: p.no, rd: p.rd, inRd: p.inRd, tm: p.tm, n: p.n, pos: p.pos, cls: p.cls, school: p.school, mine: p.mine })), udfa: udfa.map(x => ({ n: x.n, pos: x.pos })) };
  state.lastDraft = { year: yr, r1: o.nfl.picks.filter(p => p.rd === 1), mine: o.nfl.picks.filter(p => p.mine), udfa: o.nfl.udfa };
  addNews(`${yr} NFL Draft: the ${nflName(top.tm)} take ${top.pos} ${top.n} (${teamName(top.school)}) first overall.`);
  if (mine.length) { const r1n = mine.filter(p => p.rd === 1).length; addNews(`${mine.length} ${myName()} player${mine.length > 1 ? 's are' : ' is'} drafted${r1n ? `, ${r1n} in the first round` : ''}. ${mine.slice(0, 3).map(p => `${p.n} (round ${p.rd}, pick ${p.no}, ${NFL_BY[p.tm].nick})`).join('; ')}${mine.length > 3 ? '; and more' : ''}.`, 'win'); }
  else if (o.declared && o.declared.length) addNews(`No ${myName()} players are drafted this year.`, 'bad');
  checkAch('draft');
  return o.nfl;
}

// traits drawn from a player's name and position instead of the game's random sequence, so a free agent or
// draft prospect shows the same strengths before and after he joins you
function hashTraits(p) {
  const keys = TRAITS[p.pos]; if (!keys) return null; const g = k => { const u = Math.max(1e-9, hash(p.n + ':' + p.pos + ':' + k + ':u')), v = hash(p.n + ':' + p.pos + ':' + k + ':v'); return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v) * 5; };
  const vals = keys.map(g); const mean = vals.reduce((a, b) => a + b, 0) / vals.length; const t = {}; keys.forEach((k, i) => t[k] = clamp(Math.round(p.ovr + vals[i] - mean), 35, 99));
  const o = TRAIT_OVERRIDE[p.n]; if (o) Object.keys(t).forEach(k => { if (o[k]) t[k] = o[k]; }); return t;
}
/* ===================== TEAM IDENTITY (schemes) =====================
 * Every team runs an offense and a defense. A scheme decides which player traits count most (scheme fit),
 * and some schemes match up better against others. The effects are kept small: about ±1.5 points of unit
 * rating from fit, ±0.6 from the matchup and -1 for each of the first two games after a switch.
 * Your scheme comes from your coordinators unless the person in charge picked one (state.schSet).
 * No DOM here. */
const OFF_SCH = {
  pro: { n: 'Pro style', d: 'Balanced: under center or in the shotgun, run and pass.', key: { QB: ['acc'], TE: ['blk'], RB: ['pow'] } },
  spread: { n: 'Spread option', d: 'Speed in space and a quarterback who runs.', key: { QB: ['mob'], RB: ['spd'], WR: ['spd'], OL: ['rbk'] } },
  air: { n: 'Air raid', d: 'Four and five receivers, throwing all over the field.', key: { QB: ['arm', 'acc'], WR: ['rte', 'hnd'], OL: ['pbk'] } },
  power: { n: 'Power run', d: 'Downhill running behind big linemen and a blocking tight end.', key: { RB: ['pow'], OL: ['rbk'], TE: ['blk'] } },
  wc: { n: 'West Coast', d: 'Short, quick timing throws that work like runs.', key: { QB: ['acc'], WR: ['rte'], TE: ['hnd'], RB: ['hnd'] } },
};
const DEF_SCH = {
  d43: { n: '4-3', d: 'Four linemen who rush; linebackers who tackle.', key: { DE: ['rsh'], DT: ['rnd'], LB: ['tkl'] } },
  d34: { n: '3-4', d: 'Big men up front eat blocks; linebackers make the plays.', key: { DT: ['rnd'], DE: ['rnd'], LB: ['rsh', 'tkl'] } },
  blitz: { n: 'Blitz-heavy', d: 'Pressure from everywhere, tight coverage behind it.', key: { LB: ['rsh'], DE: ['rsh'], S: ['cov'] } },
  zone: { n: 'Zone coverage', d: 'Keep everything in front and make them drive the field.', key: { CB: ['cov'], S: ['cov'], LB: ['cov'] } },
};
// how much better each offense does against each defense (points of drive rating for the offense)
const SCH_MU = {
  pro: { d43: 0, d34: 0, blitz: 0, zone: 0 },
  spread: { d43: 0.3, d34: 0.2, blitz: -0.6, zone: 0 },
  air: { d43: 0.3, d34: 0, blitz: 0.6, zone: -0.6 },
  power: { d43: 0, d34: -0.5, blitz: -0.2, zone: 0.6 },
  wc: { d43: 0, d34: 0.2, blitz: 0.4, zone: -0.4 },
};
const OFF_KEYS = Object.keys(OFF_SCH), DEF_KEYS = Object.keys(DEF_SCH);
// a team's own identity, from how it plays (team style) and a fixed per-team draw
function defaultScheme(id, st) {
  st = st || { run: 0, pass: 0, runD: 0, passD: 0 }; const h1 = hash(id + ':so'), h2 = hash(id + ':sd');
  const off = st.pass - st.run > 2 ? (h1 < 0.6 ? 'air' : 'wc') : st.run - st.pass > 2 ? (h1 < 0.55 ? 'power' : 'spread') : OFF_KEYS[Math.floor(h1 * OFF_KEYS.length)];
  const def = st.passD - st.runD > 2 ? (h2 < 0.5 ? 'zone' : 'd34') : st.runD - st.passD > 2 ? (h2 < 0.5 ? 'd43' : 'blitz') : DEF_KEYS[Math.floor(h2 * DEF_KEYS.length)];
  return { off, def };
}
// what a coach likes to run (fixed per coach)
function coachSch(c) { if (!c || c.me) return null; if (!c.sch) c.sch = { off: OFF_KEYS[Math.floor(hash(c.name + ':o') * OFF_KEYS.length)], def: DEF_KEYS[Math.floor(hash(c.name + ':d') * DEF_KEYS.length)] }; return c.sch; }
// who may pick your scheme: a head coach both sides, a coordinator his side, a GM through his head coach
function canSetScheme(side) { if (isCoach()) { const r = state.co.role; return r === 'HC' || (side === 'off' && r === 'OC') || (side === 'def' && r === 'DC'); } return typeof isGM === 'function' && isGM(); }
function myScheme() {
  const t = T(ME); if (!t) return { off: 'pro', def: 'd43' }; if (!t.scheme) t.scheme = defaultScheme(ME, t.style);
  let off = t.scheme.off, def = t.scheme.def; const s = state.staff || {};
  const oc = coachSch(s.OC), dc = coachSch(s.DC); if (oc) off = oc.off; if (dc) def = dc.def;
  const set = state.schSet; if (set && set.tid === ME && (!isCoach() || set.role === state.co.role)) { if (set.off) off = set.off; if (set.def) def = set.def; }
  return { off, def };
}
function teamScheme(id) { if (id === ME) return myScheme(); const t = T(id); if (!t) return null; if (!t.scheme) t.scheme = defaultScheme(id, t.style); return t.scheme; }
function setScheme(side, k) {
  if (!canSetScheme(side) || !(side === 'off' ? OFF_SCH : DEF_SCH)[k]) return false;
  const cur = state.schSet && state.schSet.tid === ME && (!isCoach() || state.schSet.role === state.co.role) ? state.schSet : { tid: ME, role: isCoach() ? state.co.role : 'GM' };
  cur[side] = k; state.schSet = cur; return true;
}
// a player's fit: how his scheme-key traits compare with his overall (null when the scheme doesn't key on his position)
function playerFit(p, sch) {
  sch = sch || myScheme(); if (!p || !sch) return null; const keys = (OFF_SCH[sch.off].key[p.pos] || DEF_SCH[sch.def].key[p.pos]); const tr = p.tr || (typeof hashTraits === 'function' ? hashTraits(p) : null);
  if (!keys || !tr) return null; return Math.round(keys.reduce((s, k) => s + (tr[k] != null ? tr[k] : p.ovr), 0) / keys.length - p.ovr);
}
const fitLabel = f => (f == null ? '' : f >= 3 ? 'Great fit' : f >= -2 ? 'Fits' : 'Poor fit');
const schemeKeyPos = (pos, sch) => { sch = sch || myScheme(); return !!(OFF_SCH[sch.off].key[pos] || DEF_SCH[sch.def].key[pos]); };
// fit of your starters: unit bonus for offense and defense
function schemeFitBonus() {
  const sch = myScheme(); const side = (S, list) => { const f = []; list.forEach(pos => { if (!S.key[pos]) return; starters(pos).forEach(p => { const x = playerFit(p, sch); if (x != null) f.push(x); }); }); return f.length ? clamp(f.reduce((a, b) => a + b, 0) / f.length * 0.35, -1.5, 1.5) : 0; };
  return { off: r1(side(OFF_SCH[sch.off], ['QB', 'RB', 'WR', 'TE', 'OL'])), def: r1(side(DEF_SCH[sch.def], ['DE', 'DT', 'LB', 'CB', 'S'])) };
}
// the matchup with an opponent, for your offense and your defense (positive is good for you)
function schemeEdge(opp) { const a = myScheme(), b = teamScheme(opp); if (!b) return { off: 0, def: 0 }; return { off: SCH_MU[a.off][b.def] || 0, def: -(SCH_MU[b.off][a.def] || 0) }; }
// a new scheme takes two games to install; called when one of your games starts
function schemeGameStart() {
  const cur = myScheme(); const last = state.schLast; const inst = state.schInst || (state.schInst = { off: 0, def: 0 });
  if (last && last.tid === ME) { if (last.off !== cur.off) inst.off = 2; if (last.def !== cur.def) inst.def = 2; }
  state.schLast = { tid: ME, off: cur.off, def: cur.def };
  const pen = { off: inst.off > 0 ? -1 : 0, def: inst.def > 0 ? -1 : 0 }; if (inst.off > 0) inst.off--; if (inst.def > 0) inst.def--; return pen;
}
const schemeInstalling = () => { const i = state.schInst; return i ? { off: i.off > 0, def: i.def > 0 } : { off: false, def: false }; };

/* ===================== RELATIONSHIPS =====================
 * Rapport (0-100, 60 to start) between you and your players (p.rap), your assistant coaches (c.rap) and,
 * for a coach or a GM, your boss (state.rel: the AD, head coach or owner). In AD mode the Board of Regents
 * and the boosters are the existing meters. Every change keeps a short reason. No DOM here. */
const REL0 = 60;
const rapOf = x => (x && x.rap != null ? x.rap : REL0);
const rapLabel = v => (v >= 80 ? 'Close' : v >= 63 ? 'Good' : v >= 45 ? 'Neutral' : v >= 30 ? 'Strained' : 'Broken');
function rapAdj(x, d, why) { if (!x || !d) return; const v = clamp(Math.round((rapOf(x) + d) * 10) / 10, 0, 100); if (v === rapOf(x) && x.rap != null) return; x.rap = v; if (why) x.rapW = [{ d: Math.round(d), why, s: state.season }].concat((x.rapW || []).filter(w => w.why !== why)).slice(0, 4); }
// a new boss starts fresh: the record is tied to your team and role
function bossRel() { const role = isCoach() ? state.co.role : 'GM'; if (!state.rel || (state.rel.tid && (state.rel.tid !== ME || state.rel.role !== role))) state.rel = { rap: 55, tid: ME, role }; else if (!state.rel.tid) Object.assign(state.rel, { tid: ME, role }); return state.rel; }
const hasBoss = () => isCoach() || (typeof isGM === 'function' && isGM());
const bossName = () => (isCoach() ? (state.co.role === 'HC' ? (typeof isPro === 'function' && isPro() ? 'Ownership' : 'Your athletic director') : 'Your head coach') : 'The owner');
// after each of your games: playing time, the result and how it compares with expectations
function relAfterGame(g, win) {
  const pre = g.preWP != null ? g.preWP : 0.5;
  POS_ORDER.forEach(pos => {
    if (['K', 'P', 'LS'].includes(pos)) return; const dep = (state.depth[pos] || []).map(P).filter(Boolean); const n = START[pos];
    const top = dep.filter(avail).slice().sort((a, b) => b.ovr - a.ovr).slice(0, n).map(p => p.id);
    dep.forEach((p, i) => {
      if (!avail(p)) return;
      if (p.rap != null && p.rap !== REL0) p.rap = Math.round((p.rap + (REL0 - p.rap) * 0.04) * 10) / 10; // feelings fade a little every week
      if (i < n) { if (win) rapAdj(p, 0.5, 'Starting and winning'); }
      else if (top.includes(p.id) && p.ovr >= 60) rapAdj(p, p.pers === 'diva' ? -6 : -3, 'Benched behind lower-rated players');
    });
  });
  const st = state.staff || {}; STAFF_ROLES.forEach(r => { const c = st[r]; if (c && !c.me) rapAdj(c, win ? 0.5 : -0.3, win ? 'Winning' : null); });
  if (hasBoss()) { if (win && pre < 0.4) rapAdj(bossRel(), 3, 'Upset win'); else if (!win && pre > 0.7) rapAdj(bossRel(), -3, 'Loss as a favorite'); else rapAdj(bossRel(), win ? 0.5 : -0.5, null); }
  // the locker room's mood follows the starters' rapport
  rateLogPush();
  const st22 = POS_ORDER.flatMap(pos => starters(pos)); if (st22.length && state.meters) { const avg = st22.reduce((s, p) => s + rapOf(p), 0) / st22.length; if (Math.abs(avg - REL0) >= 8) state.meters.morale = clamp(state.meters.morale + (avg > REL0 ? 1 : -1), 0, 100); }
}
// players who are unhappy with you, worst first
const unhappy = () => state.roster.filter(p => rapOf(p) < 35).sort((a, b) => rapOf(a) - rapOf(b));

/* ===================== LEGACY: timeline, ratings by week, highlights, Hall of Fame, long-term goals =====================
 * No DOM here. */
// the big moments of every season (the newswire only keeps the latest 100 items)
function tlPush(txt, kind) {
  if (typeof state === 'undefined' || !state || !['big', 'win', 'bad'].includes(kind)) return;
  const t = state.tline || (state.tline = []); t.push({ s: state.season, wk: state.phase === 'offseason' ? 0 : state.week, lv: typeof isPro === 'function' && isPro() ? 'nfl' : 'col', txt, k: kind });
  if (t.length > 700) t.splice(0, t.length - 700);
}
// your team's game-day rating after each of your games (for the season highlights chart)
function rateLogPush() { const rl = state.rateLog || (state.rateLog = []); rl.push({ s: state.season, wk: state.week, v: Math.round(michStrength().ovr * 10) / 10 }); if (rl.length > 80) rl.splice(0, rl.length - 80); }
// End of season: the plays, wins and players worth remembering. Works in college and the NFL.
function buildHighlights(extra) {
  const games = mGames().filter(g => g.done); if (!games.length) return null;
  const sc = g => { const a = g.h === ME ? g.hs : g.as, b = g.h === ME ? g.as : g.hs; return a + '-' + b; };
  const plays = [];
  games.forEach(g => { const b = g.box; if (!b || !b.plays) return; const ids = [g.h, g.a]; b.plays.forEach(pl => { if (ids[pl.s] !== ME || pl.to || pl.miss || !(pl.y >= 20)) return; plays.push({ txt: pl.txt, y: pl.y, np: pl.np || 0, opp: teamName(oppOf(g)), wk: g.wk, q: pl.q, c: pl.c, gid: g.id }); }); });
  plays.sort((a, b) => b.y - a.y);
  const elo = id => (T(id) ? T(id).elo || T(id).rating * 20 : 1200);
  const wins = games.filter(g => g.mResult === 'W').sort((a, b) => elo(oppOf(b)) - elo(oppOf(a))).slice(0, 3).map(g => ({ opp: teamName(oppOf(g)), score: sc(g), wk: g.wk, gid: g.id, name: g.name || '' }));
  const close = games.filter(g => g.mResult === 'W' && Math.abs(g.hs - g.as) <= 3).map(g => ({ opp: teamName(oppOf(g)), score: sc(g), wk: g.wk, gid: g.id, ot: !!g.ot }));
  const rating = (state.rateLog || []).filter(x => x.s === state.season).map(x => ({ wk: x.wk, v: x.v }));
  const top = state.roster.filter(p => p.st && Object.keys(p.st).length).map(p => ({ n: p.n, pos: p.pos, sc: typeof heisScore === 'function' ? heisScore(p.st, p.pos, ME) : 0, line: statLineRaw(p.pos, p.st) })).sort((a, b) => b.sc - a.sc).slice(0, 3);
  const w = games.filter(g => g.mResult === 'W').length, l = games.length - w;
  const hl = Object.assign({ s: state.season, rec: w + '-' + l, plays: plays.slice(0, 5), wins, close: close.slice(0, 3), rating, top }, extra || {});
  const all = state.hl || (state.hl = {}); all[state.season] = hl; const keys = Object.keys(all).sort(); while (keys.length > 30) delete all[keys.shift()];
  return hl;
}
// Hall of Fame (college): players who leave with a great career go in automatically. Real people are left out.
function hofScore(p) {
  const aw = (p.awards || []).map(String); let sc = 0; const why = [];
  aw.forEach(a => { if (/Heisman/i.test(a)) { sc += 60; why.push(a); } else if (/First-team All-America/i.test(a)) { sc += 30; why.push(a); } else if (/All-America/i.test(a)) { sc += 18; why.push(a); } else { sc += 6; } });
  const big = (p.hist || []).filter(h => h.ovr >= 86).length; if (big) { sc += big * 8; why.push(`${big} season${big > 1 ? 's' : ''} rated 86 or better`); }
  if ((p.ovr || 0) >= 92) { sc += 15; why.push('One of the best players in the country'); }
  return { sc, why };
}
function hofConsider(p, left) {
  if (!p || p.real) return null; const h = hofScore(p); if (h.sc < 45) return null;
  const list = state.hof || (state.hof = []); if (list.some(x => x.pid === p.id)) return null;
  const yrs = (p.hist || []).map(x => x.s); const e = { pid: p.id, n: p.n, pos: p.pos, num: p.num, from: yrs.length ? Math.min(...yrs) : left, to: left, why: h.why.slice(0, 3), s: state.season };
  list.push(e); addNews(`${p.n} (${p.pos}) goes into the ${myName()} Hall of Fame.`, 'big'); return e;
}
// retired numbers stay off the roster
const retiredNums = () => new Set((state.retNums || []).map(x => x.num));
function retireNumber(pid) { const e = (state.hof || []).find(x => x.pid === pid); if (!e || e.num == null || retiredNums().has(e.num)) return false; (state.retNums || (state.retNums = [])).push({ num: e.num, n: e.n, pos: e.pos, s: state.season }); addNews(`${myName()} retires No. ${e.num} in honor of ${e.n}.`, 'big'); return true; }
// Long-term goals: tracked across every job and level (state.mile travels with you between college and the NFL)
const MILES = [
  { id: 'm_100w', n: 'Century mark', d: 'Win 100 games in your career.', p: m => [m.wins, 100] },
  { id: 'm_20s', n: 'Lifer', d: 'Complete 20 seasons.', p: m => [m.seasons, 20] },
  { id: 'm_3natl', n: 'Dynasty', d: 'Win three national championships.', p: m => [m.natl, 3] },
  { id: 'm_3teams', n: 'Wherever you go', d: 'Win a title (conference, national or Super Bowl) with three different teams.', p: m => [(m.titleTeams || []).length, 3] },
  { id: 'm_10po', n: 'Postseason regular', d: 'Make the playoffs 10 times (College Football Playoff or NFL).', p: m => [m.po, 10] },
  { id: 'm_sb', n: 'Lombardi', d: 'Win a Super Bowl.', p: m => [m.sb, 1] },
  { id: 'm_double', n: 'Both summits', d: 'Win a national championship and a Super Bowl.', p: m => [Math.min(1, m.natl) + Math.min(1, m.sb), 2] },
  { id: 'm_5conf', n: 'Conference kings', d: 'Win five conference titles.', p: m => [m.conf, 5] },
];
function mileRec() { if (!state.mile) state.mile = { seasons: 0, wins: 0, natl: 0, sb: 0, conf: 0, po: 0, titleTeams: [], done: {} }; return state.mile; }
function recordMile(o) {
  const m = mileRec(); m.seasons++; m.wins += o.w || 0; if (o.natl) m.natl++; if (o.sb) m.sb++; if (o.conf) m.conf++; if (o.po) m.po++;
  if ((o.natl || o.sb || o.conf) && !m.titleTeams.includes(o.tm)) m.titleTeams.push(o.tm);
  const got = [];
  MILES.forEach(x => { if (m.done[x.id]) return; const [a, b] = x.p(m); if (a >= b) { m.done[x.id] = state.season; got.push(x.n); addNews(`Long-term goal reached: ${x.n}. ${x.d}`, 'big'); } });
  return got;
}

/* ===================== AD MODE: media rights and moving conferences ===================== */
// The conference's TV deal comes up every few years. The AD pushes the conference one way at the board meeting.
const MEDIA_PLANS = {
  linear: { n: 'Traditional TV', d: 'Network and cable games. Steady money, the usual exposure.', amt: 0, rec: 0, fan: 0 },
  stream: { n: 'Streaming-first', d: 'More money (+$4M a year), but fewer people see your games: recruiting and fans dip a little.', amt: 4, rec: -2, fan: -2 },
  exposure: { n: 'Exposure-first', d: 'Less money (−$2M a year) for more national windows: recruiting and fans get a boost.', amt: -2, rec: 2, fan: 2 },
};
function mediaRec() { if (!state.media) { const h = hash((state.seed || 0) + ':media:' + ME); state.media = { plan: 'linear', thru: state.season + 1 + Math.floor(h * 3) }; } return state.media; }
const mediaDue = () => !isCoach() && state.phase === 'offseason' && mediaRec().thru <= state.season + 1;
const mediaAmt = () => (state.media && MEDIA_PLANS[state.media.plan] ? MEDIA_PLANS[state.media.plan].amt : 0);
const mediaRec2 = () => (state.media && MEDIA_PLANS[state.media.plan] ? MEDIA_PLANS[state.media.plan].rec : 0);
// odds the conference goes your way: your program's pull inside the league
function mediaOdds() { const t = T(ME); const peers = Object.values(state.teams).filter(x => x.conf === t.conf); const rank = peers.filter(x => x.rating > t.rating).length; return clamp(0.75 - rank * 0.06 + (state.meters.board - 60) / 200, 0.15, 0.9); }
function settleMedia(want) {
  const M = mediaRec(); const ok = want === 'linear' || R() < mediaOdds(); const plan = ok ? want : M.plan; const was = M.plan;
  M.plan = plan; M.thru = state.season + 7; M.signed = state.season + 1;
  if (MEDIA_PLANS[plan].fan) state.meters.fan = clamp(state.meters.fan + MEDIA_PLANS[plan].fan, 0, 100);
  const txt = `${CONFS[T(ME).conf].name} media rights: ${ok ? '' : 'the conference went another way. '}${MEDIA_PLANS[plan].n} deal through ${M.thru}.`;
  addNews(txt, ok && plan !== was ? 'big' : ''); return txt;
}
// Applying to another conference: the league decides on your program's pull, the market and how it's run.
function moveOdds(to) {
  const t = T(ME); const C = CONFS[to]; if (!C || to === t.conf || to === 'IND') return 0;
  const avg = Object.values(state.teams).filter(x => x.conf === to); const bar = avg.length ? avg.reduce((s, x) => s + x.rating, 0) / avg.length : 70;
  return clamp(0.35 + (t.rating - bar) * 0.04 + (state.meters.fan - 60) / 150 + (facLvl('building') - 3) * 0.05 + (rankOf(ME) ? 0.1 : 0), 0.03, 0.9);
}
const moveFee = to => r1(CONFS[T(ME).conf].p4 ? 18 : 6);
function tryMove(to) {
  const odds = moveOdds(to); if (!odds) return null; const ok = R() < odds; const fee = moveFee(to);
  if (ok) { state.myMove = { s: state.season, to, fee }; state.fin.balance -= fee; if (state.fin.ytd) state.fin.ytd.eventx = (state.fin.ytd.eventx || 0) + fee; addNews(`${myName()} accepts an invitation to join the ${CONFS[to].name} next season. Exit fee: $${fee}M.`, 'big'); }
  else addNews(`The ${CONFS[to].name} turns down ${myName()}'s application.`, 'bad');
  return ok;
}

/* ===================== COACHING TREE ===================== */
// Assistants who leave for bigger jobs become your coaching tree: you may face them, and you can hire them back.
function treeOf() { if (isCoach()) { const co = state.co; return co.tree || (co.tree = []); } return state.tree || (state.tree = []); }
function treeAdd(c, role, tid, newRole) { if (!c || c.me) return; const t = treeOf(); const e = t.find(x => x.name === c.name) || {}; Object.assign(e, { name: c.name, role, under: myName(), s: state.season, now: tid || null, nowRole: newRole || null, r: { off: c.off, def: c.def, rec: c.rec, dev: c.dev, gm: c.gm, ovr: c.ovr }, sal: c.salary }); if (!t.includes(e)) t.push(e); if (t.length > 40) t.shift(); }
const treeAt = tid => (T(tid) ? treeOf().find(x => x.now === tid && T(tid).coach === x.name) : null);
// a former assistant willing to come back, offered as a candidate for an opening
function treeCandidate(role) {
  const t = treeOf().filter(x => !state.cands[role] || !state.cands[role].some(c => c.name === x.name)); if (!t.length) return null;
  const fits = t.filter(x => (role === 'HC' ? ['OC', 'DC', 'HC'].includes(x.role) || x.nowRole === 'HC' : x.role === role || (['OC', 'DC'].includes(role) && ROLE_TIER[x.role] === 1))); const x = fits[0]; if (!x) return null;
  const b = x.r || {}; const base = { name: x.name, role, title: ROLE_TITLE[role], real: false, bg: `Former ${ROLE_TITLE[x.role]} on your staff${x.now && T(x.now) ? ', now with ' + teamName(x.now) : ''}`, tree: true };
  const c = role === 'HC' ? mkCoach(Object.assign(base, { off: b.off || b.ovr || 76, def: b.def || b.ovr || 74, rec: b.rec || 74, dev: b.dev || 74, gm: b.gm || 72 })) : mkCoach(Object.assign(base, { ovr: Math.min(95, (b.ovr || 74) + 2), rec: b.rec || 72, dev: b.dev || 72 }));
  c.salary = r1(Math.max(0.3, (x.sal || 1) * 1.15)); c.rap = 72; return c;
}
// another program hires one of your former assistants as its head coach (the AI carousel)
function treePromote(tid) { const c = treeOf().filter(x => x.now !== ME && x.nowRole !== 'HC' && (ROLE_TIER[x.role] >= 2 || ((x.r || {}).ovr || 0) >= 76)); if (!c.length || hash((state.seed || 0) + ':tp:' + state.season + ':' + tid) > 0.35) return null; const x = c[0]; x.now = tid; x.nowRole = 'HC'; addNews(`${teamName(tid)} hires ${x.name}, a former ${(ROLE_TITLE[x.role] || '').toLowerCase()} on your staff, as head coach.`, 'big'); return x.name; }
// when he's hired away from another program, that program needs a new head coach
function treeHired(c) { const x = treeOf().find(e => e.name === c.name); if (!x) return; if (x.now && T(x.now) && T(x.now).coach === c.name) T(x.now).coach = genName(); x.now = ME; x.nowRole = c.role; addNews(`${c.name} returns to ${myName()}.`, 'big'); }

/* ===================== COACH MODE: weekly practice plan ===================== */
// Eight practice periods a week: offense, defense, conditioning and film. Default is two each.
const PPLAN_KEYS = [['off', 'Offense', 'Sharper offense on game day'], ['def', 'Defense', 'Sharper defense on game day'], ['cond', 'Conditioning', 'Fewer injuries'], ['film', 'Film study', 'A better read on this week\'s opponent']];
const pplan = () => (isCoach() && state.co.role === 'HC' && state.pplan ? state.pplan : null);
function setPplan(k, d) { if (!isCoach() || state.co.role !== 'HC') return false; const p = state.pplan || (state.pplan = { off: 2, def: 2, cond: 2, film: 2 }); const tot = Object.values(p).reduce((a, b) => a + b, 0); if (!(k in p)) return false; if (d > 0 && tot >= 8) return false; p[k] = clamp(p[k] + d, 0, 6); return true; }
const pplanBonus = () => { const p = pplan(); return p ? { off: (p.off - 2) * 0.45, def: (p.def - 2) * 0.45, inj: 1 - (p.cond - 2) * 0.12, film: (p.film - 2) * 0.2 } : { off: 0, def: 0, inj: 1, film: 0 }; };

/* ===================== GAME DAY: halftime speech, replay review ===================== */
// The halftime speech lands differently with the score: firing them up works when you trail, staying the course
// when you lead, and a calm talk steadies a rattled team. Leaders among your captains make any speech land harder.
const SPEECHES = { fire: ['Fire them up', 'Best when you are behind. Does little with a big lead.'], steady: ['Stay the course', 'Best when you are ahead.'], calm: ['Calm and focused', 'Stops their momentum and steadies the defense.'] };
function speechFx(sim, k) {
  const m = simMargin(sim); const lf = 1 + 0.12 * captainsList().filter(p => p.pers === 'leader').length;
  const fx = k === 'fire' ? (m < 0 ? [1, 0.6] : m > 14 ? [0, 0] : [0.3, 0.3]) : k === 'steady' ? (m >= 0 ? [0.5, 0.5] : [0.2, 0.2]) : k === 'calm' ? (m < -14 ? [0.1, 0.2] : [0.2, 0.5]) : [0, 0];
  return { off: r1(fx[0] * lf), def: r1(fx[1] * lf) };
}
// Two challenges a game: an opponent's touchdown (ruled down at the 1, they kick a field goal) or your own
// turnover (ruled down by contact, so you keep it and punt instead). Only the drive that just ended can be
// reviewed. The ruling comes from hash(), not R(), so asking never changes the rest of the game's random stream.
const chalLeft = sim => (sim.chal == null ? 2 : sim.chal);
function reviewable(sim) {
  if (!sim || sim.done || sim.mSide < 0 || sim.pending || chalLeft(sim) <= 0) return null;
  const i = sim.log.length - 1; const x = sim.log[i]; if (!x || x.half || x.rev || x.ot) return null;
  const mine = x.s === sim.mSide;
  if (!mine && x.out === 'td' && !x.p6) return { i, kind: 'td' };
  if (mine && x.out === 'to' && !x.p6) return { i, kind: 'to' };
  return null;
}
function challengePlay(sim) {
  const r = reviewable(sim); if (!r) return null; const x = sim.log[r.i]; sim.chal = chalLeft(sim) - 1; x.rev = true;
  const ok = hash((sim.ckKey || sim.g.id || '') + ':rev:' + r.i) < (r.kind === 'td' ? 0.3 : 0.38);
  if (!ok) { x.txt += ' (the call stands after review)'; return { ok: false, kind: r.kind }; }
  if (r.kind === 'td') {
    const s = x.s; const prev = sim.log.slice(0, r.i).filter(y => !y.half).pop(); const before = prev ? prev.pts[s] : 0; const d = Math.max(0, x.pts[s] - before - 3); const qi = Math.min(4, x.qtr - 1);
    sim.pts[s] -= d; sim.q[s][qi] -= d; x.pts = sim.pts.slice(); x.out = 'fg'; x.score = true; x.txt += '. Overturned on review: down at the 1, and they settle for a field goal';
  } else { const o = 1 - sim.mSide; sim.shortField[o] = Math.min(sim.shortField[o] || 0, -0.2); if (sim.box) sim.box.t[sim.mSide].to = Math.max(0, sim.box.t[sim.mSide].to - 1); x.out = 'punt'; x.txt += '. Overturned on review: down by contact. You keep it and punt it away'; }
  if (sim.box && sim.box.wp.length) { const m = simMargin(sim); const rem = Math.max(0.01, 1 - sim.i / sim.total); sim.box.wp[sim.box.wp.length - 1].v = Math.round(normcdf((m + sim.m0 * rem) / (13.5 * Math.sqrt(rem) + 0.6)) * 100); }
  return { ok: true, kind: r.kind };
}
// clutch players on the field right now (shown in close fourth quarters and in big games)
function clutchNames() { return ['QB', 'RB', 'WR'].flatMap(pos => starters(pos)).filter(p => p.pers === 'clutch').map(p => p.n); }

/* ===================== PERSONALITIES THAT CHANGE ===================== */
// Each offseason a few players grow or sour: captains become leaders, divas who start on a winner settle down,
// injury-prone players who stay healthy shed the label, starters on playoff teams learn to close, and a talented
// backup can turn into a diva. Real players only ever change for the better. Uses hash(), not R().
function evolvePers() {
  const games = mGames(); const w = games.filter(g => g.mResult === 'W').length, l = games.filter(g => g.mResult === 'L').length; const post = games.some(g => g.type !== 'reg' && g.mResult);
  const caps = new Set(captainsList().map(p => p.id)); const out = [];
  state.roster.forEach(p => {
    if (!p.pers || !state.depth[p.pos]) return; const idx = state.depth[p.pos].indexOf(p.id); const starter = idx >= 0 && idx < (START[p.pos] || 1);
    const h = hash((state.seed || 0) + ':pers:' + state.season + ':' + p.id); const old = p.pers; let nw = null;
    if (caps.has(p.id) && ['steady', 'worker', 'clutch'].includes(old) && h < 0.35) nw = 'leader';
    else if (old === 'diva' && starter && w > l && h < 0.4) nw = 'steady';
    else if (old === 'fragile' && !p.inj && (p.gp || 0) >= 9 && h < 0.3) nw = 'steady';
    else if (old === 'steady' && starter && post && ['QB', 'RB', 'WR', 'TE', 'K'].includes(p.pos) && h < 0.15) nw = 'clutch';
    else if (old === 'steady' && !p.real && !starter && p.ovr >= 80 && h < 0.12) nw = 'diva';
    else if (old === 'steady' && ['Fr', 'So'].includes(p.cls) && h > 0.93) nw = 'worker';
    if (!nw || nw === old) return; p.pers = nw; (p.persLog || (p.persLog = [])).push({ s: state.season, from: old, to: nw });
    out.push(`${p.n} (${p.pos}) ${nw === 'leader' ? 'has grown into a team leader' : nw === 'steady' ? (old === 'diva' ? 'has stopped sulking and bought in' : 'has stayed healthy and shed the injury-prone label') : nw === 'clutch' ? 'learned to deliver in big moments' : nw === 'diva' ? 'is unhappy with his role and has become a distraction' : 'has become one of the hardest workers on the team'}.`);
  });
  out.slice(0, 6).forEach(t => addNews('Locker room: ' + t, /distraction/.test(t) ? 'bad' : 'win'));
  return out;
}
// who sets the tone this week: leaders who start, and troublemakers (divas who sit, or who start and just lost)
function lockerRoom() {
  const lead = [], trouble = [];
  state.roster.forEach(p => { const d = state.depth[p.pos]; if (!d) return; const idx = d.indexOf(p.id); const st = idx >= 0 && idx < (START[p.pos] || 1); if (p.pers === 'leader' && st && avail(p)) lead.push(p); if (p.pers === 'diva' && p.ovr >= 74 && !st) trouble.push(p); });
  return { lead, trouble };
}

/* ===================== INJURY REHAB ===================== */
// For an injury of two weeks or more you can rush him back (out about half as long, but four times as likely to
// get hurt again for a month), follow the standard plan, or play it safe (a week longer, half the usual risk after).
const REHAB = { rush: ['Rush him back', 'Back in about half the time. For four games after, he is about four times as likely to get hurt again.'], std: ['Standard plan', 'The doctors\' timeline.'], safe: ['Play it safe', 'One more week out. For five games after, he is half as likely to get hurt.'] };
function rehabOpen(p) { return p && p.inj >= 2 && p.inj < 99 && !p.injSE && !p.rehab; }
function setRehab(id, k) {
  const p = P(id); if (!rehabOpen(p) || !REHAB[k]) return false; p.rehab = k;
  if (k === 'rush') { p.inj = Math.max(1, Math.ceil(p.inj * 0.5)); p.reinj = 4; }
  else if (k === 'safe') { p.inj += 1; p.prot = 5; }
  return true;
}
function doctorNote(p) { const t = String(p.injType || 'injury').toLowerCase(); const fast = Math.max(1, Math.ceil(p.inj * 0.5)); return `Team doctor: "With ${aAn(t)}, the standard plan is ${p.inj} more week${p.inj > 1 ? 's' : ''}. We could have him back in ${fast}, but I would not do it before a game that doesn't matter much."`; }
const rehabInjF = p => (p.reinj > 0 ? 4 : 1) * (p.prot > 0 ? 0.5 : 1);
function rehabWeek(played) { state.roster.forEach(p => { if (p.inj > 0) return; if (p.reinj > 0 && played) p.reinj--; if (p.prot > 0 && played) p.prot--; if (p.rehab && !p.reinj && !p.prot) p.rehab = null; }); }

/* ===================== SCOUTING STAFF ===================== */
// Up to three scouts. In college each covers a region: recruits from there count as fully scouted and sleepers
// get flagged. In the NFL each covers a position group: those prospects start better scouted, and every scout
// adds scouting points each week.
const SC_REG = { NE: ['Northeast', 'ME NH VT MA RI CT NY NJ PA DE MD DC'], SE: ['Southeast', 'VA WV NC SC GA FL AL MS TN KY LA AR'], MW: ['Midwest', 'OH MI IN IL WI MN IA MO ND SD NE KS'], SW: ['Southwest', 'TX OK NM AZ'], W: ['West', 'CA OR WA NV UT CO ID MT WY AK HI'] };
const SC_GRP = { skill: ['QB and skill players', ['QB', 'RB', 'WR', 'TE']], trench: ['Linemen', ['OL', 'DE', 'DT']], back7: ['Linebackers and DBs', ['LB', 'CB', 'S']] };
const TOWN_ST = Object.fromEntries(TOWNS.map(t => [t[0], t[1]]));
function scoutList() { if (isPro()) { const L = PS(); return L.scouts || (L.scouts = []); } return state.scouts || (state.scouts = []); }
function scoutCands() {
  const pro = isPro(); const keys = Object.keys(pro ? SC_GRP : SC_REG); const have = scoutList();
  return [0, 1, 2, 3].map(i => { const h = hash((state.seed || 0) + ':sc:' + state.season + ':' + i + (pro ? 'n' : 'c')); const lvl = 1 + Math.floor(hash(h + ':l') * 3); const spec = keys[Math.floor(h * keys.length)]; return { id: 'sc' + state.season + i, name: genNameH(h), spec, lvl, sal: pro ? 150000 * lvl : 60000 * lvl }; }).filter(c => !have.some(x => x.id === c.id));
}
function genNameH(h) { const F = ['Ray', 'Dale', 'Curtis', 'Lonnie', 'Marcus', 'Glen', 'Terry', 'Walt', 'Andre', 'Hank', 'Reggie', 'Phil', 'Darnell', 'Stan', 'Cliff', 'Eddie']; const L = ['Hollis', 'Pruitt', 'Garner', 'Whitlock', 'Mabry', 'Coleman', 'Rowe', 'Fenwick', 'Odom', 'Tillery', 'Burkett', 'Vance', 'Spurlock', 'Kimbrough', 'Ashby', 'Delaney']; return F[Math.floor(hash(h + 'f') * F.length)] + ' ' + L[Math.floor(hash(h + 'g') * L.length)]; }
const scoutCan = () => !isCoach() || state.co.role === 'HC';
function hireScout(id) { const c = scoutCands().find(x => x.id === id); const L = scoutList(); if (!c || L.length >= 3 || !scoutCan()) return false; L.push(c); addNews(`${myName()} hires ${c.name} as a scout (${isPro() ? SC_GRP[c.spec][0] : SC_REG[c.spec][0]}).`); return true; }
function fireScout(id) { const L = scoutList(); const i = L.findIndex(x => x.id === id); if (i < 0 || !scoutCan()) return false; L.splice(i, 1); return true; }
// a recruit's region, and whether one of your scouts covers it
function recRegion(r) { const st = TOWN_ST[r.home]; return st ? Object.keys(SC_REG).find(k => SC_REG[k][1].split(' ').includes(st)) : null; }
function recScout(r) { if (isPro()) return null; const reg = recRegion(r); return reg ? scoutList().filter(s => s.spec === reg).sort((a, b) => b.lvl - a.lvl)[0] || null : null; }
const recSleeper = r => r.star <= 3 && r.pot >= r.ovr + 12;
// NFL prospects: a scout who covers his position group raises the starting scouting level
function proScoutBoost(pos) { if (!isPro()) return 0; const s = scoutList().filter(x => SC_GRP[x.spec] && SC_GRP[x.spec][1].includes(pos)).sort((a, b) => b.lvl - a.lvl)[0]; return s ? (s.lvl >= 3 ? 2 : 1) : 0; }
const effSc = p => Math.max(p.sc || 0, proScoutBoost(p.pos));

/* ===================== DEBT AND BOOSTERS (AD) ===================== */
// Bonds: money now for facilities or anything else, paid back in equal yearly payments over ten years at 5%.
// The board doesn't love debt. Boosters sometimes give with strings attached: keep the head coach, or hold
// ticket prices. Break the promise and they want half the money back.
const BOND_SIZES = [10, 25, 50], BOND_RATE = 0.05, BOND_YRS = 10, DEBT_MAX = 75;
const bondPay = amt => r1(amt * BOND_RATE / (1 - Math.pow(1 + BOND_RATE, -BOND_YRS)));
function debtLeft() { return r1((state.bonds || []).reduce((s, b) => s + b.pay * b.left, 0)); }
function issueBond(amt) {
  if (isPro() || isCoach() || !BOND_SIZES.includes(amt) || debtLeft() + bondPay(amt) * BOND_YRS > DEBT_MAX * 1.35) return false;
  (state.bonds || (state.bonds = [])).push({ s: state.season, amt, pay: bondPay(amt), left: BOND_YRS }); state.fin.balance += amt; mv('board', amt >= 50 ? -4 : amt >= 25 ? -2 : -1);
  addNews(`${myName()} issues $${amt}M in bonds: $${bondPay(amt)}M a year for ${BOND_YRS} years.`); return true;
}
// yearly payments post with the year-end money
function bondsYearEnd() { let t = 0; (state.bonds || []).forEach(b => { if (b.left > 0 && b.paidS !== state.season) { b.left--; b.paidS = state.season; t += b.pay; } }); if (t) { state.fin.balance -= t; state.fin.ytd.debt = r1((state.fin.ytd.debt || 0) + t); } state.bonds = (state.bonds || []).filter(b => b.left > 0); return t; }
function boosterOffer() {
  if (isPro() || isCoach() || state.phase !== 'offseason') return null; const h = hash((state.seed || 0) + ':bo:' + state.season); if (h > 0.7) return null;
  const done = (state.boDone || []).includes(state.season); if (done) return null; const hc = state.staff && state.staff.HC;
  const amt = Math.round((4 + h * 10) * 2) / 2; const k = hc && !hc.me && h < 0.38 ? 'coach' : 'tix';
  return { k, amt, thru: state.season + 2, coach: k === 'coach' ? hc.name : null, tix: state.fin.ticket, who: genNameH(h + 'b') };
}
function answerBooster(yes) {
  const o = boosterOffer(); if (!o) return null; (state.boDone || (state.boDone = [])).push(state.season);
  if (!yes) { mv('boost', -1); return `You turned down ${o.who}.`; }
  state.fin.balance += o.amt; state.fin.ytd.donations = r1((state.fin.ytd.donations || 0) + o.amt); (state.strings || (state.strings = [])).push(Object.assign({}, o, { s: state.season }));
  return `${o.who} gives $${o.amt}M. The condition: ${o.k === 'coach' ? `keep ${o.coach} as head coach through ${o.thru}` : `keep the average ticket at $${o.tix} or less through ${o.thru}`}.`;
}
// a broken promise: the booster wants half back and the others notice
function breakString(x, why) { x.broken = true; const back = r1(x.amt / 2); state.fin.balance -= back; state.fin.ytd.eventx = r1((state.fin.ytd.eventx || 0) + back); mv('boost', -10); addNews(`${x.who} says you broke your word (${why}) and wants $${back}M back. Other boosters are wary now.`, 'bad'); }
function stringsCheck(ev, data) {
  (state.strings || []).forEach(x => { if (x.broken || x.kept) return;
    if (ev === 'fire' && x.k === 'coach' && data === x.coach && state.season <= x.thru) breakString(x, `you fired ${x.coach}`);
    if (ev === 'year' && x.k === 'tix' && state.season <= x.thru && state.fin.ticket > x.tix) breakString(x, 'ticket prices went up');
    if (ev === 'year' && !x.broken && state.season >= x.thru) { x.kept = true; mv('boost', 3); addNews(`${x.who} is happy: you kept your promise through ${x.thru}.`, 'win'); }
  });
}

/* ===================== BOWL WEEK ===================== */
// Before a bowl or playoff game the AD sets the travel party and pushes tickets. Schools pay for the tickets
// they don't sell from their allotment.
const BOWL_CITY = { 'Duke\'s Mayo Bowl': 'Charlotte', 'Pinstripe Bowl': 'New York', 'Military Bowl': 'Annapolis', 'Birmingham Bowl': 'Birmingham', 'Fenway Bowl': 'Boston', 'Armed Forces Bowl': 'Fort Worth', 'First Responder Bowl': 'Dallas', 'Independence Bowl': 'Shreveport', 'Cactus Bowl': 'Phoenix', 'Arizona Bowl': 'Tucson', 'Hawaii Bowl': 'Honolulu', 'New Mexico Bowl': 'Albuquerque', 'Poinsettia Bowl': 'San Diego', 'New Orleans Bowl': 'New Orleans', 'Frisco Bowl': 'Frisco', 'Cure Bowl': 'Orlando', 'Puerto Rico Bowl': 'San Juan', 'Famous Idaho Potato Bowl': 'Boise', 'Myrtle Beach Bowl': 'Conway', 'Gasparilla Bowl': 'Tampa', 'Boca Raton Bowl': 'Boca Raton', 'Frisco Football Classic': 'Frisco', 'Salute to Veterans Bowl': 'Montgomery', '68 Ventures Bowl': 'Mobile', 'Citrus Bowl': 'Orlando', 'ReliaQuest Bowl': 'Tampa', 'Alamo Bowl': 'San Antonio', 'Pop-Tarts Bowl': 'Orlando', 'Gator Bowl': 'Jacksonville', 'Music City Bowl': 'Nashville', 'Holiday Bowl': 'San Diego', 'Sun Bowl': 'El Paso', 'Las Vegas Bowl': 'Las Vegas', 'Texas Bowl': 'Houston', 'Liberty Bowl': 'Memphis', 'Rose Bowl': 'Pasadena', 'Sugar Bowl': 'New Orleans', 'Orange Bowl': 'Miami', 'Cotton Bowl': 'Arlington', 'Fiesta Bowl': 'Glendale', 'Peach Bowl': 'Atlanta' };
const TRIP = { lean: ['Lean', 0.5, 0, 0], std: ['Standard', 0.9, 1, 1], full: ['Full band and boosters', 1.5, 3, 3] };
function bowlGame() { if (isPro() || isCoach()) return null; return state.games.find(g => !g.done && (g.type === 'bowl' || g.type === 'cfp') && (g.h === ME || g.a === ME)) || null; }
function bowlCity(g) { const k = Object.keys(BOWL_CITY).find(b => (g.name || '').includes(b)); return k ? BOWL_CITY[k] : 'a neutral site'; }
function bowlTix(g, promo) { const allot = g.type === 'cfp' ? 16000 : 12000; const f = clamp(0.45 + (state.meters.fan - 50) / 100 + (g.type === 'cfp' ? 0.15 : 0) + (promo ? 0.15 : 0), 0.3, 1); return { allot, sold: Math.round(allot * f / 100) * 100 }; }
function setTrip(k, promo) {
  const g = bowlGame(); if (!g || !TRIP[k]) return null; const T_ = state.trip || {}; if (T_.gid === g.id) return null;
  const t = bowlTix(g, promo); const price = g.type === 'cfp' ? 175 : 110; const unsold = r1((t.allot - t.sold) * price / 1e6); const cost = r1(TRIP[k][1] + (promo ? 0.2 : 0) + unsold);
  state.trip = { gid: g.id, k, promo: !!promo, cost, sold: t.sold, allot: t.allot }; state.fin.balance -= cost; state.fin.ytd.eventx = r1((state.fin.ytd.eventx || 0) + cost); mv('fan', TRIP[k][2]); mv('boost', TRIP[k][3]);
  return `Travel set: ${TRIP[k][0].toLowerCase()} party. ${t.sold.toLocaleString()} of ${t.allot.toLocaleString()} tickets sold. Cost $${cost}M${unsold ? ` (including $${unsold}M for unsold tickets)` : ''}.`;
}
const isTitleGame = g => !!g && /National Championship|Super Bowl/.test(g.name || '');

/* ===================== HISTORICAL SEASONS: import a ranking ===================== */
// Paste a poll (one team per line: "1. Georgia", "Georgia 95", "OSU: 91") and the league takes its shape:
// ranked teams get a rating and a poll position from their rank (or the rating you gave), and teams you left
// out can't start ahead of the last one listed. Best used in the preseason.
function rankTeamMatch(s) {
  const q = String(s || '').toLowerCase().replace(/[^a-z0-9& .'-]/g, '').replace(/\s+/g, ' ').trim(); if (!q) return null;
  const ids = Object.keys(state.teams); const nm = id => [id, T(id).name, CTEAMS0_AD[id] ? CTEAMS0_AD[id].name : '', teamName(id)].map(x => String(x || '').toLowerCase());
  return ids.find(id => nm(id).includes(q)) || ids.find(id => nm(id).some(n => n && (n.startsWith(q + ' ') || q.startsWith(n + ' ')))) || null;
}
function parseRankings(text) {
  const out = []; const seen = new Set();
  String(text || '').split(/\r?\n/).forEach(line => {
    let L = line.trim(); if (!L) return; let rank = null, rating = null;
    let m = L.match(/^#?\s*(\d{1,3})[.)\s:-]+(.+)$/); if (m && +m[1] <= 130) { rank = +m[1]; L = m[2].trim(); }
    m = L.match(/^(.+?)[\s,:(-]+(\d{2}(?:\.\d)?)\)?\s*$/); if (m && +m[2] >= 40 && +m[2] <= 99) { rating = +m[2]; L = m[1].trim(); }
    L = L.replace(/\s*\(\d+-\d+\)\s*$/, '').trim(); const id = rankTeamMatch(L); if (!id || seen.has(id)) return; seen.add(id);
    out.push({ id, rank, rating });
  });
  out.forEach((x, i) => { if (x.rank == null) x.rank = i + 1; }); out.sort((a, b) => a.rank - b.rank);
  return out;
}
function importRankings(text) {
  if (isPro()) return { n: 0 }; const list = parseRankings(text); if (!list.length) return { n: 0 };
  list.forEach((x, i) => { const t = T(x.id); const rk = i + 1; const r = x.rating != null ? x.rating : r1(clamp(96 - (rk - 1) * 0.6, 60, 97)); if (x.id !== ME) { const d = r - t.rating; t.rating = r; t.off = r1(clamp(t.off + d, 35, 99)); t.def = r1(clamp(t.def + d, 35, 99)); } t.elo = t.elo0 = 1860 - (rk - 1) * 9; });
  const floor = 1860 - list.length * 9 - 1; const listed = new Set(list.map(x => x.id)); Object.values(state.teams).forEach(t => { if (!listed.has(t.id) && t.elo > floor) t.elo = floor - (t.id === ME ? 0 : 1); });
  addNews(`League reset from an imported poll: ${list.slice(0, 3).map(x => teamName(x.id)).join(', ')}${list.length > 3 ? ` and ${list.length - 3} more` : ''}.`);
  return { n: list.length, top: list.slice(0, 5).map(x => teamName(x.id)) };
}
