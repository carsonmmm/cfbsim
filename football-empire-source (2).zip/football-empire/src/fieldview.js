/* ===================== FIELD VIEW: the play on the field (live games) ===================== */
// An optional top-down field above the live game. Twenty-two dots with jersey numbers line up in formation,
// the ball is snapped and the play runs: handoffs, routes, throws, tackles, punts and kicks.
// It only draws what the engine already decided (the drive log and the plays you call); it never calls R(),
// so turning it on or off can't change a result. Settings: prefs.field ('on' / 'off').

const PF_O = ['LT', 'LG', 'C', 'RG', 'RT', 'TE', 'WR1', 'WR2', 'WR3', 'RB', 'QB'];
const PF_D = ['DE1', 'DT1', 'DT2', 'DE2', 'LB1', 'LB2', 'LB3', 'CB1', 'CB2', 'S1', 'S2'];
const PF_MID = 28.65, PF_H = 57.3; // the field is 53.3 yards wide; 2 yards of sideline on each side
// formations, in yards: a = downfield from the line of scrimmage (offense negative), b = across the field
const PF_GUN = { LT: [-0.8, -5.4], LG: [-0.8, -2.7], C: [-0.8, 0], RG: [-0.8, 2.7], RT: [-0.8, 5.4], TE: [-1, 8.3], WR1: [-1, -19], WR2: [-1, 18], WR3: [-1.4, -12.5], RB: [-5.2, 2.7], QB: [-5, 0] };
const PF_UC = Object.assign({}, PF_GUN, { QB: [-1.9, 0], RB: [-6.8, 0], WR3: [-1.4, 13] });
const PF_DEF = { DE1: [1.1, -7], DT1: [1.1, -1.6], DT2: [1.1, 1.6], DE2: [1.1, 7], LB1: [4.6, -5.2], LB2: [5, 0], LB3: [4.6, 5.2], CB1: [6.5, -19], CB2: [6.5, 18], S1: [12.5, -9], S2: [12.5, 9] };
const PF_PUNT = { LT: [-0.8, -5.4], LG: [-0.8, -2.7], C: [-0.8, 0], RG: [-0.8, 2.7], RT: [-0.8, 5.4], TE: [-6.5, -2], WR1: [-1, -22], WR2: [-1, 22], WR3: [-6.5, 2], RB: [-7, 0], QB: [-14, 0] };
const PF_FG = { LT: [-0.8, -5.4], LG: [-0.8, -2.7], C: [-0.8, 0], RG: [-0.8, 2.7], RT: [-0.8, 5.4], TE: [-1, 8.2], WR1: [-1, -8.2], WR2: [-1.6, 10.4], WR3: [-1.6, -10.4], RB: [-9.6, -2.2], QB: [-7, 0] };
const PF_DFG = { DE1: [1, -8.6], DT1: [1, -1.4], DT2: [1, 1.4], DE2: [1, 8.6], LB1: [1.1, -4.1], LB2: [1.1, 4.1], LB3: [3.5, 0], CB1: [1.2, -11.5], CB2: [1.2, 11.5], S1: [7, -5], S2: [7, 5] };
const PF_DPUNT = Object.assign({}, PF_DEF, { CB1: [2.5, -21], CB2: [2.5, 21], S1: [18, 0] });

const pf = { el: null, svg: null, q: [], cur: null, raf: 0, until: 0, cam: 60, pos: {}, sim: null, ds: null, seen: 0, lastLog: 0, next: [25, 25], team: null, W: 120 };
function fieldOn() { return prefs.field !== 'off'; }
const pfSpeed = () => [1, 0.55, 0.3][(live.speed || 1) - 1] || 1;
const pfLerp = (a, b, k) => a + (b - a) * k;
const pfEase = k => k < 0.5 ? 2 * k * k : 1 - Math.pow(-2 * k + 2, 2) / 2;

/* ---------- colors and numbers ---------- */
function pfLum(hex) { const h = String(hex || '#777').replace('#', ''); const n = parseInt(h.length === 3 ? h.split('').map(c => c + c).join('') : h.slice(0, 6), 16) || 0; return (0.299 * (n >> 16 & 255) + 0.587 * (n >> 8 & 255) + 0.114 * (n & 255)) / 255; }
function pfDist(a, b) { const p = x => { const n = parseInt(String(x || '#777').replace('#', '').slice(0, 6), 16) || 0; return [n >> 16 & 255, n >> 8 & 255, n & 255]; }; const A = p(a), B = p(b); return Math.hypot(A[0] - B[0], A[1] - B[1], A[2] - B[2]); }
function pfColors(id) {
  if (id === ME) { const c = schoolColors(); if (c && c.c1) return [c.c1, c.c2 || '#ffffff']; if (!isPro()) return ['#00274C', '#FFCB05']; }
  if (isPro() && NFL_BY[id]) return [NFL_BY[id].c1, NFL_BY[id].c2];
  const ti = TEAM_INFO[id]; return ti ? [ti.c1, ti.c2] : ['#5b6470', '#e8e8e8'];
}
// jersey numbers by role: your starters from the depth chart, the other team's from its roster when there is one
function pfNums(id) {
  const used = new Set(); const h = (k, lo, hi) => { let n = lo + Math.floor(hash(id + ':pfn:' + k) * (hi - lo + 1)); let g = 0; while (used.has(n) && g++ < 100) n = n >= hi ? lo : n + 1; used.add(n); return n; };
  let get = null;
  if (id === ME && state.depth) get = (pos, n) => starters(pos, n);
  else if (isPro() && typeof proRoster === 'function') { const ros = proRoster(id) || []; get = (pos, n) => ros.filter(p => p.pos === pos && !p.inj).sort((a, b) => b.ovr - a.ovr).slice(0, n); }
  const take = (pos, n) => { try { return get ? get(pos, n).map(p => (p && p.num != null ? p.num : null)) : []; } catch (e) { return []; } };
  const ol = take('OL', 5), wr = take('WR', 3), de = take('DE', 2), dt = take('DT', 2), lb = take('LB', 3), cb = take('CB', 2), s = take('S', 2);
  const raw = { LT: ol[0], LG: ol[1], C: ol[2], RG: ol[3], RT: ol[4], TE: take('TE', 1)[0], WR1: wr[0], WR2: wr[1], WR3: wr[2], RB: take('RB', 1)[0], QB: take('QB', 1)[0], DE1: de[0], DT1: dt[0], DT2: dt[1], DE2: de[1], LB1: lb[0], LB2: lb[1], LB3: lb[2], CB1: cb[0], CB2: cb[1], S1: s[0], S2: s[1], K: take('K', 1)[0], P: take('P', 1)[0] };
  Object.values(raw).forEach(n => { if (n != null) used.add(n); });
  const R_ = { LT: [60, 79], LG: [60, 79], C: [50, 69], RG: [60, 79], RT: [60, 79], TE: [80, 89], WR1: [1, 19], WR2: [80, 89], WR3: [10, 19], RB: [20, 39], QB: [1, 19], DE1: [90, 99], DT1: [90, 99], DT2: [50, 79], DE2: [90, 99], LB1: [40, 59], LB2: [40, 59], LB3: [40, 59], CB1: [20, 39], CB2: [20, 39], S1: [20, 49], S2: [20, 49], K: [1, 19], P: [1, 19] };
  const out = {}; Object.keys(R_).forEach(k => { out[k] = raw[k] != null ? raw[k] : h(k, R_[k][0], R_[k][1]); }); return out;
}

/* ---------- the field ---------- */
function pfBuild() {
  const el = document.createElement('div'); el.className = 'pfield'; el.setAttribute('aria-hidden', 'true');
  const hashY = isPro() ? 23.58 : 20; let ticks = '', lines = '', nums = '', stripes = '';
  for (let x = 10; x <= 110; x += 10) stripes += x < 110 ? `<rect x="${x}" y="2" width="5" height="53.3" class="pfstripe"/>` : '';
  for (let x = 10; x <= 110; x += 5) lines += `M${x} 2V55.3`;
  for (let x = 11; x < 110; x++) if (x % 5) ticks += `M${x} 2.2v0.7M${x} 54.4v0.7M${x} ${2 + hashY}v0.7M${x} ${55.3 - hashY - 0.7}v0.7`;
  for (let x = 20; x <= 100; x += 10) { const v = x <= 60 ? x - 10 : 110 - x; nums += `<text x="${x}" y="${2 + 9}" class="pfnum">${v}</text><text x="${x}" y="${55.3 - 9}" class="pfnum" transform="rotate(180 ${x} ${55.3 - 9})">${v}</text>`; }
  const dot = (k, side) => `<g class="pfd ${side}" data-k="${k}"><circle r="1.25"/><text dy="0.05">00</text></g>`;
  el.innerHTML = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 120 ${PF_H}" preserveAspectRatio="xMidYMid meet">
    <rect x="-40" y="-2" width="200" height="${PF_H + 4}" class="pfgrass"/>${stripes}
    <rect x="0" y="2" width="10" height="53.3" class="pfez l"/><rect x="110" y="2" width="10" height="53.3" class="pfez r"/>
    <text class="pfezt l" transform="translate(5 ${PF_MID}) rotate(-90)"></text><text class="pfezt r" transform="translate(115 ${PF_MID}) rotate(90)"></text>
    <path d="${lines}" class="pfline"/><path d="${ticks}" class="pftick"/><path d="M0 2V55.3M120 2V55.3M0 2H120M0 55.3H120" class="pfbound"/>${nums}
    <path d="M0 ${PF_MID - 3.08}V${PF_MID + 3.08}M120 ${PF_MID - 3.08}V${PF_MID + 3.08}" class="pfpost"/>
    <line class="pflos" x1="0" x2="0" y1="2" y2="55.3"/><line class="pffd" x1="0" x2="0" y1="2" y2="55.3"/>
    <g class="pfdots">${PF_D.map(k => dot(k, 'def')).join('')}${PF_O.map(k => dot(k, 'off')).join('')}</g>
    <ellipse class="pfshadow" rx="0.55" ry="0.3"/><ellipse class="pfball" rx="0.6" ry="0.38"/>
    <text class="pflbl" y="11"></text></svg><div class="pfcap"></div>`;
  pf.el = el; pf.svg = el.querySelector('svg'); pf.dots = {}; el.querySelectorAll('.pfd').forEach(g => { pf.dots[(g.classList.contains('off') ? 'O' : 'D') + g.dataset.k] = g; });
  pf.ball = el.querySelector('.pfball'); pf.shadow = el.querySelector('.pfshadow'); pf.lbl = el.querySelector('.pflbl'); pf.cap = el.querySelector('.pfcap');
  pf.los = el.querySelector('.pflos'); pf.fd = el.querySelector('.pffd');
  return el;
}
function pfReset(sim) {
  pfClear(); pf.sim = sim; pf.ds = null; pf.seen = 0; pf.lastLog = 0; pf.next = [25, 25]; pf.pos = {}; pf.team = null; pf.cam = 60; pf.lastDir = null;
  pfBuild(); pf.nums = [pfNums(sim.ids[0]), pfNums(sim.ids[1])]; pf.col = [pfColors(sim.ids[0]), pfColors(sim.ids[1])];
  if (pfDist(pf.col[0][0], pf.col[1][0]) < 110) pf.col[1] = pfDist(pf.col[1][1], pf.col[0][0]) > 110 ? [pf.col[1][1], pf.col[1][0]] : ['#f2f2f2', pf.col[1][0]]; // two dark blues: the road team wears its other color
  // kickoff: both teams in a standard look at the 25 of the team that receives
  const s = sim.first; pf.snap = true; pfStage({ o: s, dir: pfDir(s, 1), los: 25, fd: 35, kind: 'set' }); pfDraw(pf.stage, 0, 0, 1);
}
function pfClear() { pf.q = []; pf.cur = null; pf.until = 0; if (pf.raf) cancelAnimationFrame(pf.raf); pf.raf = 0; }
function pfLeft() { return pf.cur || pf.q.length ? Math.max(0, pf.until - performance.now()) : 0; }
// side 0 (home) attacks to the right in the first half; the teams switch ends at halftime
const pfDir = (s, qtr) => (s === 0 ? 1 : -1) * (qtr >= 3 ? -1 : 1);
// where a field yard line (from the offense's goal line) sits in the picture
const pfX = (P, a) => (P.dir > 0 ? 10 + P.los : 110 - P.los) + P.dir * a;

/* ---------- plays ---------- */
// P = { o: offense side, dir, los, fd, kind, call, y, n (ball carrier's number), dist, good, ret, td, qtr, key }
function pfScript(P) {
  const T = {}; const H = (P.key || '') + ':' + P.kind; const r = k => hash(H + ':' + k); const sg = r('s') < 0.5 ? -1 : 1;
  const toGoal = 100 - P.los; const maxA = toGoal + 9.5, minA = -P.los - 9.5;
  const A = a => clamp(a, minA, maxA); const B = b => clamp(b, -25.6, 25.6);
  const put = (k, pts) => { T[k] = pts.map(p => [p[0], A(p[1]), B(p[2])]); };
  const F = P.kind === 'punt' ? PF_PUNT : P.kind === 'fg' ? PF_FG : P.kind === 'run' || P.kind === 'fum' ? PF_UC : PF_GUN;
  const DF = P.kind === 'fg' ? PF_DFG : P.kind === 'punt' ? PF_DPUNT : PF_DEF;
  const form = {}; PF_O.forEach(k => { form['O' + k] = [A(F[k][0]), B(F[k][1])]; }); PF_D.forEach(k => { const d = DF[k]; form['D' + k] = [A(Math.min(d[0], k[0] === 'S' ? Math.max(toGoal + 6, 3) : d[0])), B(d[1])]; });
  const at = k => form[k]; const still = k => put(k, [[0, at(k)[0], at(k)[1]], [1, at(k)[0], at(k)[1]]]);
  const ball = []; let lbl = null; let endA = P.y;
  const near = (pt, off, lag) => [pt[0] + off[0] - (lag || 0), pt[1] + off[1]];
  const offs = [[0.9, 0.5], [0.4, -1.1], [1.6, -0.3], [-0.6, 1.2], [2.2, 1.4], [1.1, 2.2], [-1, -1.6], [3, -2], [2.8, 2.5], [4.5, 0.6], [5.5, -1.4]];
  const converge = (keys, end, w, t0, mid) => keys.forEach((k, i) => { const s = at(k); const o = offs[i % offs.length]; const tgt = near(end, o, P.y > 14 && i < 6 ? 2 + i : 0); const m = mid && mid[k]; put(k, [[0, s[0], s[1]]].concat(m ? [[t0, m[0], m[1]]] : [[t0, pfLerp(s[0], tgt[0], 0.25), pfLerp(s[1], tgt[1], 0.2)]]).concat([[1, pfLerp(s[0], tgt[0], w), pfLerp(s[1], tgt[1], w)]])); });
  const td = P.td; const label = (t, txt, cls) => { lbl = [t, txt, cls || '']; };
  const roleOfNum = n => (n == null ? null : PF_O.find(k => pf.nums[P.o][k] === n));
  if (P.kind === 'run' || P.kind === 'fum') {
    const gap = P.call === 'outside' ? sg * (8 + r('g') * 3) : sg * (0.9 + r('g') * 1.4); const end = [td ? P.y + 1.5 : P.y, gap + (r('d') - 0.5) * 3];
    const cr = roleOfNum(P.n) === 'QB' ? 'QB' : 'RB';
    put('OQB', cr === 'QB' ? [[0, -1.9, 0], [0.2, -2.6, gap * 0.4], [0.45, 0, gap], [1, end[0], end[1]]] : [[0, -1.9, 0], [0.15, -3.1, sg * 0.7], [0.45, -4.4, -sg * 2], [1, -4.6, -sg * 2.6]]);
    if (cr !== 'QB') put('ORB', [[0, -6.8, 0], [0.16, -3.3, gap * 0.35], [0.38, -0.3, gap], [1, end[0], end[1]]]); else put('ORB', [[0, -6.8, 0], [0.4, -2, gap * 0.8], [1, 0.5, gap * 1.1]]);
    ['OLT', 'OLG', 'OC', 'ORG', 'ORT'].forEach((k, i) => { const s = at(k); put(k, [[0, s[0], s[1]], [0.3, s[0] + 1.1, s[1] + (P.call === 'outside' ? sg * 0.8 : 0)], [1, s[0] + 1.6 + Math.min(3, Math.max(0, P.y) * 0.08), s[1] + (P.call === 'outside' ? sg * 1.6 : (i - 2) * 0.2)]]); });
    put('OTE', [[0, -1, 8.3], [0.35, 0.6, 8.6], [1, 1.8, 9]]);
    ['OWR1', 'OWR2', 'OWR3'].forEach(k => { const s = at(k); put(k, [[0, s[0], s[1]], [0.55, 5.5, s[1] * 0.96], [1, 6.5, s[1] * 0.93]]); });
    converge(['DLB2', 'DDT1', 'DS1', 'DLB1', 'DLB3', 'DDT2', 'DDE1', 'DDE2', 'DS2', 'DCB1', 'DCB2'], end, 0.93, 0.32);
    ball.push({ h: 'OC', u: 0.06 }, { f: [-1.9, 0], u: 0.1, z: 0 }, { h: 'OQB', u: cr === 'QB' ? 1 : 0.16 }); if (cr !== 'QB') ball.push({ h: 'ORB', u: P.kind === 'fum' ? 0.78 : 1 });
    if (P.kind === 'fum') { const lo = [end[0] + 1.6, end[1] - 1.8]; ball.push({ f: lo, u: 0.92, z: 1.4 }); T.DLB2 = [[0, at('DLB2')[0], at('DLB2')[1]], [0.6, end[0] + 2, end[1]], [0.95, lo[0], lo[1]], [1, lo[0] + 0.3, lo[1]]]; label(0.8, 'Fumble!', 'bad'); }
    else if (td) label(0.88, 'Touchdown!', 'good');
  } else if (P.kind === 'punt') {
    const dist = P.dist || 42; const land = Math.min(dist, toGoal + 4); const tb = land >= toGoal; const ret = tb ? 0 : P.ret == null ? 6 : P.ret;
    const catchPt = [land, sg * 2]; const retEnd = [land - ret, sg * 4];
    form.DS1 = [A(land - 3), 0]; put('DS1', [[0, land - 3, 0], [0.4, land - 2, catchPt[1] * 0.5], [0.72, catchPt[0], catchPt[1]], [1, tb ? catchPt[0] : retEnd[0], tb ? catchPt[1] : retEnd[1]]]);
    put('OQB', [[0, -14, 0], [0.22, -13, 0], [0.35, -11, 0.4], [1, -4, 1]]);
    ['OWR1', 'OWR2'].forEach((k, i) => { const s = at(k); put(k, [[0, s[0], s[1]], [0.7, land - 6, (i ? 1 : -1) * 6], [1, retEnd[0] + 1.5, retEnd[1] + (i ? 1.4 : -1.4)]]); });
    ['OLT', 'OLG', 'OC', 'ORG', 'ORT', 'OTE', 'OWR3', 'ORB'].forEach((k, i) => { const s = at(k); put(k, [[0, s[0], s[1]], [0.3, s[0] + 1.5, s[1]], [1, Math.min(retEnd[0] + 3 + i * 1.3, s[0] + 40), retEnd[1] + (i - 4) * 1.6]]); });
    ['DDE1', 'DDT1', 'DDT2', 'DDE2', 'DLB1', 'DLB2', 'DLB3'].forEach((k, i) => { const s = at(k); put(k, [[0, s[0], s[1]], [0.25, s[0] - 2.5, s[1] * 0.8], [1, s[0] + 10 + i * 2, s[1] * 0.6]]); });
    ['DCB1', 'DCB2'].forEach((k, i) => { const s = at(k); put(k, [[0, s[0], s[1]], [0.7, s[0] + 5, s[1] * 0.5], [1, retEnd[0] - 2, retEnd[1] + (i ? 3 : -3)]]); });
    { const s2 = at('DS2'); put('DS2', [[0, s2[0], s2[1]], [1, s2[0] + 6, s2[1] * 0.6]]); }
    ball.push({ h: 'OC', u: 0.06 }, { f: [-14, 0], u: 0.16, z: 0.5 }, { h: 'OQB', u: 0.25 }, { f: catchPt, u: 0.72, z: dist * 0.3 }, { h: 'DS1', u: 1 });
    endA = tb ? toGoal : retEnd[0]; label(0.75, tb ? 'Touchback' : 'Punt', '');
  } else if (P.kind === 'fg') {
    const back = toGoal + 10; const miss = !P.good; const tgt = [back + 1, miss ? sg * (4.2 + r('m') * 2) : (r('m') - 0.5) * 2.4];
    put('ORB', [[0, -9.6, -2.2], [0.22, -9.6, -2.2], [0.34, -7.4, -0.5], [1, -6.2, 0.2]]); put('OQB', [[0, -7, 0], [1, -7, 0]]);
    ['OLT', 'OLG', 'OC', 'ORG', 'ORT', 'OTE', 'OWR1', 'OWR2', 'OWR3'].forEach(k => { const s = at(k); put(k, [[0, s[0], s[1]], [0.3, s[0] - 0.8, s[1] * 0.92], [1, s[0] - 1, s[1] * 0.9]]); });
    PF_D.forEach(k => { const s = at('D' + k); put('D' + k, [[0, s[0], s[1]], [0.35, s[0] - 1.6, s[1] * 0.85], [1, s[0] - 2, s[1] * 0.8]]); });
    ball.push({ h: 'OC', u: 0.08 }, { f: [-7, 0.2], u: 0.2, z: 0.3 }, { f: [-7, 0], u: 0.34, z: 0 }, { f: tgt, u: 0.9, z: 9 });
    endA = 0; label(0.9, miss ? 'No good' : 'It\'s good!', miss ? 'bad' : 'good');
  } else {
    // passing plays: incomplete, complete, sack, interception
    const deep = P.call === 'deep' || (P.kind === 'pass' && P.y >= 16); const screen = P.call === 'screen';
    const tr = roleOfNum(P.n); const tg = tr && tr !== 'QB' && PF_O.indexOf(tr) >= 5 ? tr : screen ? 'RB' : deep ? (r('t') < 0.55 ? 'WR1' : 'WR2') : ['WR3', 'TE', 'WR2', 'WR1'][Math.floor(r('t') * 4)];
    const routes = { WR1: [deep ? 22 : 12, -18.5], WR2: [deep ? 20 : 11, 12], WR3: [7, -5], TE: [6.5, 12.5], RB: screen ? [-1.8, 7] : [1.2, 9] };
    const yy = P.kind === 'pass' ? P.y : 0; const air = screen ? -1.8 : P.kind === 'pass' ? clamp(Math.round((yy >= 10 ? yy * 0.78 : yy * 0.9) * 10) / 10, 1.5, Math.max(1.5, yy)) : routes[tg][0];
    const cp = [air, tg === 'RB' ? routes.RB[1] : routes[tg][1]]; const fin = [td ? yy + 1.2 : yy, cp[1] + (r('d') - 0.5) * 5];
    PF_O.slice(6).concat(['TE']).forEach(k => { if (k === 'QB' || k === tg) return; const s = at('O' + k); const rt = routes[k]; if (!rt) return; put('O' + k, [[0, s[0], s[1]], [0.6, rt[0], rt[1]], [1, rt[0] + 1.5, rt[1] + (k === 'WR3' ? -2 : 1)]]); });
    const ts = at('O' + tg); put('O' + tg, P.kind === 'pass' ? [[0, ts[0], ts[1]], [0.55, cp[0], cp[1]], [1, fin[0], fin[1]]] : [[0, ts[0], ts[1]], [0.58, cp[0], cp[1]], [1, cp[0] + 1.2, cp[1]]]);
    ['OLT', 'OLG', 'OC', 'ORG', 'ORT'].forEach(k => { const s = at(k); put(k, [[0, s[0], s[1]], [0.3, s[0] - 1.6, s[1] * 1.04], [1, s[0] - 2.1, s[1] * 1.05]]); });
    const sackA = P.kind === 'sack' ? Math.min(-2, P.y) : 0;
    put('OQB', P.kind === 'sack' ? [[0, -5, 0], [0.25, -7.2, 0], [0.55, -7.4, sg * 1.2], [0.75, sackA, sg * 1.5], [1, sackA, sg * 1.5]] : [[0, -5, 0], [0.25, -7.2, 0], [0.45, -7, 0], [1, -6.4, 0]]);
    const qbEnd = P.kind === 'sack' ? [sackA, sg * 1.5] : [-6.4, 0];
    if (P.kind === 'sack') { const rusher = sg > 0 ? 'DDE2' : 'DDE1'; const rs = at(rusher); put(rusher, [[0, rs[0], rs[1]], [0.4, -3.5, sg * 4], [0.6, -7, sg * 1.6], [0.78, sackA + 0.6, sg * 1.9], [1, sackA + 0.4, sg * 2]]); }
    ['DDE1', 'DDT1', 'DDT2', 'DDE2'].forEach((k, i) => { if (T[k]) return; const s = at(k); put(k, [[0, s[0], s[1]], [0.35, -1.6, s[1] * 0.85], [0.65, -3.8 + i * 0.3, s[1] * 0.5], [1, P.kind === 'sack' ? qbEnd[0] + 1.6 : pfLerp(-3.5, fin[0], 0.25), (P.kind === 'sack' ? qbEnd[1] : 0) + (i - 1.5) * 1.6]]); });
    // coverage: corners carry the outside receivers, linebackers drop, safeties stay deep; everyone runs to the ball
    const end = P.kind === 'pass' ? fin : P.kind === 'sack' ? qbEnd : cp;
    const cov = (k, wr, deepA) => { const s = at(k); const w = T['O' + wr] || [[0, at('O' + wr)[0], at('O' + wr)[1]], [1, at('O' + wr)[0], at('O' + wr)[1]]]; const m = w[1] || w[0]; put(k, [[0, s[0], s[1]], [0.55, Math.max(m[1], 2) + (deepA || 1.2), m[2] * 0.94], [1, pfLerp(Math.max(m[1], 2) + 1, end[0] + 1.2, P.kind === 'inc' ? 0.2 : 0.75), pfLerp(m[2], end[1], P.kind === 'inc' ? 0.2 : 0.7)]]); };
    cov('DCB1', 'WR1'); cov('DCB2', 'WR2');
    ['DLB1', 'DLB2', 'DLB3'].forEach((k, i) => { const s = at(k); put(k, [[0, s[0], s[1]], [0.45, 7 + i * 0.5, s[1] * 1.1], [1, pfLerp(7, end[0] + offs[i][0], P.kind === 'inc' ? 0.3 : 0.85), pfLerp(s[1], end[1] + offs[i][1], P.kind === 'inc' ? 0.3 : 0.85)]]); });
    ['DS1', 'DS2'].forEach((k, i) => { const s = at(k); put(k, [[0, s[0], s[1]], [0.5, Math.max(s[0] + 2, deep ? 18 : 14), s[1] * 0.8], [1, pfLerp(Math.max(s[0] + 2, 14), end[0] + 2.5 + i, P.kind === 'inc' ? 0.4 : 0.8), pfLerp(s[1] * 0.8, end[1] + (i ? 2 : -2), P.kind === 'inc' ? 0.4 : 0.8)]]); });
    ball.push({ h: 'OC', u: 0.05 }, { f: [-5, 0], u: 0.12, z: 0.4 }, { h: 'OQB', u: P.kind === 'sack' ? 1 : 0.4 });
    if (P.kind === 'pass') { ball.push({ f: cp, u: 0.55, z: Math.max(1.5, Math.abs(air) * 0.32 + 1) }, { h: 'O' + tg, u: 1 }); if (td) label(0.85, 'Touchdown!', 'good'); else if (P.y >= 20) label(0.8, 'Big play', 'good'); }
    else if (P.kind === 'inc') { ball.push({ f: [cp[0] + 1.4, cp[1] + 0.4], u: 0.58, z: Math.abs(air) * 0.3 + 1 }, { f: [cp[0] + 3, cp[1] + 1], u: 0.7, z: 0.5 }); label(0.62, 'Incomplete', ''); endA = 0; }
    else if (P.kind === 'sack') { label(0.72, 'Sacked!', 'bad'); endA = sackA; }
    else if (P.kind === 'int') {
      const pk = cp[1] < -6 ? 'DCB1' : cp[1] > 6 ? 'DCB2' : r('i') < 0.5 ? 'DS1' : 'DLB2'; const ps = at(pk); const ret = P.p6 ? cp[0] + P.los + 1.5 : P.ret == null ? 8 : P.ret;
      const back = [cp[0] - ret, cp[1] + sg * 3]; put(pk, [[0, ps[0], ps[1]], [0.53, cp[0] + 0.6, cp[1] + 0.3], [1, back[0], back[1]]]);
      ['OWR1', 'OWR2', 'OWR3', 'OTE', 'ORB', 'OQB'].forEach((k, i) => { const w = T[k] || [[0, ...at(k)]]; const m = w[Math.min(1, w.length - 1)]; put(k, [[0, w[0][1], w[0][2]], [0.55, m[1], m[2]], [1, pfLerp(m[1], back[0] + 1.5 + i, 0.7), pfLerp(m[2], back[1] + (i - 2.5) * 1.5, 0.7)]]); });
      ball.push({ f: cp, u: 0.55, z: Math.abs(air) * 0.3 + 1 }, { h: pk, u: 1 }); label(0.6, P.p6 ? 'Pick six!' : 'Intercepted!', 'bad'); endA = cp[0] - ret;
    }
  }
  PF_O.forEach(k => { if (!T['O' + k]) still('O' + k); }); PF_D.forEach(k => { if (!T['D' + k]) still('D' + k); });
  return { T, form, ball, lbl, endA };
}
// pf.stage holds the play that is on screen: its script, world placement and the teams' colors
function pfStage(P) {
  const sc = P.kind === 'set' ? (() => { const form = {}; PF_O.forEach(k => { form['O' + k] = PF_GUN[k].slice(); }); PF_D.forEach(k => { form['D' + k] = PF_DEF[k].slice(); }); const T = {}; Object.keys(form).forEach(k => { T[k] = [[0, form[k][0], form[k][1]], [1, form[k][0], form[k][1]]]; }); return { T, form, ball: [], lbl: null, endA: 0 }; })() : pfScript(P);
  pf.stage = { P, sc };
}
function pfTrack(pts, t) { if (!pts) return [0, 0]; if (t <= pts[0][0]) return [pts[0][1], pts[0][2]]; for (let i = 0; i < pts.length - 1; i++) { const a = pts[i], b = pts[i + 1]; if (t <= b[0]) { const k = b[0] === a[0] ? 1 : (t - a[0]) / (b[0] - a[0]); return [pfLerp(a[1], b[1], k), pfLerp(a[2], b[2], k)]; } } const z = pts[pts.length - 1]; return [z[1], z[2]]; }
function pfBall(sc, t) {
  let pos = sc.form.OC ? [sc.form.OC[0] + 0.9, sc.form.OC[1]] : [0, 0]; let t0 = 0;
  for (const st of sc.ball) {
    if (st.h) { const p = pfTrack(sc.T[st.h], Math.min(t, st.u)); if (t <= st.u) return [p[0] + 0.4, p[1] + 0.2, 0]; pos = [p[0] + 0.4, p[1] + 0.2]; t0 = st.u; }
    else { if (t <= st.u) { const k = (t - t0) / Math.max(0.0001, st.u - t0); return [pfLerp(pos[0], st.f[0], k), pfLerp(pos[1], st.f[1], k), (st.z || 0) * 4 * k * (1 - k)]; } pos = st.f.slice(); t0 = st.u; }
  }
  return [pos[0], pos[1], 0];
}
// draws one moment of the staged play. ph: 0 = sliding into formation (k = progress), 1 = the play at time t
function pfDraw(st, ph, t, k) {
  if (!pf.svg || !st) return; const P = st.P, sc = st.sc; const oc = pf.col[P.o], dc = pf.col[1 - P.o]; const on = pf.nums[P.o], dn = pf.nums[1 - P.o];
  let bx = null;
  Object.keys(pf.dots).forEach(key => {
    const g = pf.dots[key]; const side = key[0]; const role = key.slice(1); let a, b;
    if (ph === 0) { const f = sc.form[key]; const fx = pfX(P, f[0]), fy = PF_MID + f[1]; const from = pf.pos[key] || [fx, fy]; a = pfLerp(from[0], fx, k); b = pfLerp(from[1], fy, k); }
    else { const p = pfTrack(sc.T[key], t); a = pfX(P, p[0]); b = PF_MID + p[1]; }
    pf.cpos[key] = [a, b]; g.setAttribute('transform', `translate(${a.toFixed(2)} ${b.toFixed(2)})`);
  });
  if (ph === 0) { const f = sc.form.OC; bx = [pfX(P, f[0] + 0.9), PF_MID + f[1], 0]; } else { const p = pfBall(sc, t); bx = [pfX(P, p[0]), PF_MID + p[1], p[2]]; }
  pf.ball.setAttribute('cx', bx[0].toFixed(2)); pf.ball.setAttribute('cy', (bx[1] - bx[2] * 0.35).toFixed(2)); pf.ball.setAttribute('transform', `rotate(${P.dir > 0 ? 0 : 180} ${bx[0].toFixed(2)} ${(bx[1] - bx[2] * 0.35).toFixed(2)}) scale(1)`);
  const sz = 1 + bx[2] * 0.03; pf.ball.setAttribute('rx', (0.6 * sz).toFixed(2)); pf.ball.setAttribute('ry', (0.38 * sz).toFixed(2));
  pf.shadow.setAttribute('cx', bx[0].toFixed(2)); pf.shadow.setAttribute('cy', (bx[1] + 0.25).toFixed(2)); pf.shadow.style.opacity = bx[2] > 0.2 ? 0.35 : 0;
  // camera: follow the ball, but never past the end lines
  const w = pf.svg.clientWidth || 600, h = pf.svg.clientHeight || 300; const VH = 44; const W = Math.min(126, VH * w / h); pf.W = W; /* show 44 of the 53 yards across, so the dots stay big */
  const want = W >= 124 ? 60 : clamp(bx[0], W / 2 - 3, 123 - W / 2); pf.cam = pf.snap ? want : pfLerp(pf.cam, want, 0.12); pf.snap = false;
  pf.svg.setAttribute('viewBox', `${(pf.cam - W / 2).toFixed(2)} ${(PF_MID - VH / 2).toFixed(2)} ${W.toFixed(2)} ${VH}`);
  pf.lbl.setAttribute('x', pf.cam.toFixed(2));
  if (st.colored !== true) {
    st.colored = true;
    Object.keys(pf.dots).forEach(key => { const g = pf.dots[key]; const isO = key[0] === 'O'; const c = isO ? oc : dc; const role = key.slice(1); const num = isO ? (P.kind === 'punt' && role === 'QB' ? on.P : P.kind === 'fg' && role === 'RB' ? on.K : P.kind === 'fg' && role === 'QB' ? on.P : on[role]) : dn[role];
      const cir = g.firstChild; cir.setAttribute('fill', c[0]); cir.setAttribute('stroke', c[1]); const tx = g.lastChild; tx.textContent = num; tx.setAttribute('fill', pfLum(c[0]) > 0.6 ? '#111' : '#fff'); });
    const lt = P.dir > 0 ? P.o : 1 - P.o; const ez = pf.el.querySelectorAll('.pfez'); const ezt = pf.el.querySelectorAll('.pfezt'); const ids = pf.sim.ids;
    [lt, 1 - lt].forEach((s, i) => { ez[i].setAttribute('fill', pf.col[s][0]); ezt[i].textContent = isFCS(ids[s]) ? 'FCS' : ids[s] === ME ? myAb() : ids[s]; ezt[i].setAttribute('fill', pfLum(pf.col[s][0]) > 0.6 ? '#111' : '#fff'); });
    const lx = pfX(P, 0), fx = P.fd != null ? pfX(P, P.fd - P.los) : null; pf.los.setAttribute('x1', lx); pf.los.setAttribute('x2', lx); pf.fd.style.display = fx == null || P.fd >= 100 ? 'none' : ''; if (fx != null) { pf.fd.setAttribute('x1', fx); pf.fd.setAttribute('x2', fx); }
    pf.lbl.textContent = ''; pf.lbl.setAttribute('class', 'pflbl');
  }
  const L = sc.lbl; if (ph === 1 && L && t >= L[0]) { if (pf.lbl.textContent !== L[1]) { pf.lbl.textContent = L[1]; pf.lbl.setAttribute('class', 'pflbl show ' + L[2]); } }
}
// queue a play: it slides into formation, holds a beat, runs, and holds the result
function pfQueue(P, cap) {
  if (!pf.el) return; const f = motionOn() ? pfSpeed() : 0;
  const item = { P, cap, d: [320 * f, 160 * f, 1350 * f, 380 * f] }; item.total = item.d.reduce((a, b) => a + b, 0) || 0;
  // never fall behind the game: if plays pile up (fast play calling), skip to the newest one
  if (pf.q.length >= 1) pf.q = [];
  pf.q.push(item); const now = performance.now(); pf.until = (pf.cur ? Math.max(now, pf.cur.t0 + pf.cur.total) : now) + pf.q.reduce((a, x) => a + x.total, 0);
  if (!pf.raf) pf.raf = requestAnimationFrame(pfLoop);
}
function pfLoop(now) {
  pf.raf = 0;
  if (!pf.cur && pf.q.length) { pf.cur = pf.q.shift(); pf.cur.t0 = now; pf.pos = Object.assign({}, pf.cpos); pfStage(pf.cur.P); if (pf.cap) pf.cap.textContent = pf.cur.cap || ''; }
  const it = pf.cur;
  if (it) {
    const e = now - it.t0; const [a, b, c] = it.d;
    if (it.total <= 0) { pfDraw(pf.stage, 0, 0, 1); pfDraw(pf.stage, 1, 1); pf.cur = null; }
    else if (e < a) pfDraw(pf.stage, 0, 0, pfEase(e / a));
    else if (e < a + b) pfDraw(pf.stage, 0, 0, 1);
    else if (e < a + b + c) pfDraw(pf.stage, 1, (e - a - b) / c);
    else { pfDraw(pf.stage, 1, 1); if (e >= it.total) pf.cur = null; }
  }
  if (pf.cur || pf.q.length) pf.raf = requestAnimationFrame(pfLoop);
}
pf.cpos = {};

/* ---------- reading the game ---------- */
const PF_CALL_TXT = { inside: 'Inside run', outside: 'Outside run', short: 'Short pass', deep: 'Deep shot', screen: 'Screen' };
function pfKind(pl) { return pl.sack ? 'sack' : pl.int ? 'int' : pl.fum ? 'fum' : pl.pass ? (pl.comp ? 'pass' : 'inc') : 'run'; }
function pfCap(sim, P) {
  const tm = sim.ids[P.o] === ME ? myAb() : isFCS(sim.ids[P.o]) ? 'FCS' : sim.ids[P.o]; const num = n => (n != null ? '#' + n : '');
  const y = P.y, yd = Math.abs(y) + ' yard' + (Math.abs(y) === 1 ? '' : 's');
  const t = { run: `${num(P.n) || 'Run'} ${y > 0 ? 'for ' + yd : y === 0 ? 'for no gain' : 'loses ' + yd}`, pass: `Pass complete${P.n != null ? ' to #' + P.n : ''}, ${yd}`, inc: 'Pass incomplete', sack: `Sacked, loss of ${Math.abs(y)}`, int: 'Intercepted', fum: 'Fumble', punt: 'Punt', fg: `${P.dist}-yard field goal: ${P.good ? 'good' : 'no good'}` }[P.kind] || '';
  return `${tm}${P.down ? ' · ' + ['1st', '2nd', '3rd', '4th'][P.down - 1] + ' & ' + (100 - P.los < P.togo ? 'goal' : P.togo) : ''} · ${t}${P.td ? ' · Touchdown' : ''}`;
}
// plays you (or your staff) called in the drive on screen
function pfFlushDs() {
  const ds = pf.ds; const sim = pf.sim; if (!ds || !sim) return; const n = ds.plays.length; if (n <= pf.seen) return;
  const from = Math.max(pf.seen, n - 2); let los = ds.start, down = 1, togo = 10;
  for (let i = 0; i < n; i++) {
    const pl = ds.plays[i]; const gain = pl.sack ? (pl.ly || pl.yl || -5) : pl.y || 0;
    if (i >= from && i >= pf.seen) {
      const kind = pfKind(pl); const P = { o: pf.dsSide, dir: pfDir(pf.dsSide, pf.dsQ), los, fd: Math.min(100, los + togo), kind, call: ds.calls[i], y: kind === 'sack' ? gain : kind === 'inc' || kind === 'int' ? 0 : gain, n: pl.who && pl.who.num != null ? pl.who.num : null, td: !pl.int && !pl.fum && los + gain >= 100, key: sim.ckKey + ':' + sim.i + ':' + i, down, togo };
      if (P.td) P.y = 100 - los; pfQueue(P, pfCap(sim, P));
    }
    if (pl.int || pl.fum) break; los = clamp(los + gain, 1, 100); togo -= gain; if (togo <= 0) { down = 1; togo = 10; } else down++;
  }
  pf.seen = n;
}
// a finished drive from the log. Drives you called already played out; only their kick is left to show.
function pfDrive(sim, x) {
  const s = x.s, dir = pfDir(s, x.ot ? 3 : x.qtr); const key = sim.ckKey + ':' + sim.log.indexOf(x);
  let endA; if (x.out === 'td') endA = 100; else if (x.out === 'fg' && x.fg) endA = clamp(117 - x.fg, 1, 99); else endA = clamp((pf.next[s] || 25) + (x.yards || 0), 1, 99);
  if (x.man) { endA = x.endYl != null ? x.endYl : endA; }
  const q = [];
  if (!x.man && x.pl) {
    let los = endA; const pls = x.pl; const list = [];
    for (let i = pls.length - 1; i >= 0; i--) {
      const p = pls[i]; const kind = { r: 'run', p: 'pass', x: 'inc', s: 'sack', i: 'int', f: 'fum' }[p.k] || 'run'; const last = i === pls.length - 1;
      let gain = kind === 'inc' || kind === 'int' || kind === 'fum' ? 0 : p.y || 0; let start;
      if (last && x.out === 'td') { start = clamp(100 - Math.max(1, gain), 1, 99); gain = 100 - start; } else start = clamp(los - gain, 1, 99);
      list.unshift({ o: s, dir, los: start, fd: Math.min(100, start + 10), kind, y: gain, n: p.n, td: last && x.out === 'td', p6: last && !!x.p6, key: key + ':' + i, call: kind === 'pass' && gain >= 16 ? 'deep' : '' });
      los = start;
    }
    list.forEach(P => q.push(P));
  }
  if (x.out === 'punt') q.push({ o: s, dir, los: endA, fd: null, kind: 'punt', dist: 38 + Math.round(hash(key + 'pd') * 12), ret: Math.round(hash(key + 'pr') * 10), key: key + ':k' });
  if (x.out === 'fg') q.push({ o: s, dir, los: endA, fd: null, kind: 'fg', dist: x.fg || 117 - endA, good: !!x.good, key: key + ':k' });
  q.slice(-1).forEach(P => pfQueue(P, pfCap(sim, P))); /* one play a drive: the one that decided it */
  // where the other team starts next
  const o = 1 - s; pf.next[o] = x.out === 'td' || x.out === 'fg' || x.p6 ? 25 : x.out === 'punt' ? clamp(100 - Math.min(endA + 40, 100), 10, 40) || 20 : clamp(100 - endA, 1, 99);
}
// called after every live render: queue whatever happened since the last look
function pfSync() {
  const sim = live.sim; if (!sim || !fieldOn() || !sim.box) return;
  if (pf.sim !== sim || !pf.el) pfReset(sim);
  const slot = $('#modal .pfslot'); if (slot && pf.el.parentNode !== slot) slot.appendChild(pf.el);
  pfFlushDs();
  const n = sim.log.length; if (n - pf.lastLog > 3) pf.lastLog = n - 1; // a big jump (two-minute drill, a skip): show the last drive only
  while (pf.lastLog < n) { const x = sim.log[pf.lastLog++]; if (!x.half) pfDrive(sim, x); }
  const p = sim.pending; const ds = p && (p.type === 'drive' || p.type === 'ddrive') ? p.ds : null;
  if (ds && ds !== pf.ds) { pf.ds = ds; pf.dsSide = p.s; pf.dsQ = p.ot ? 3 : p.qtr; pf.seen = 0; if (!ds.plays.length) { const P = { o: p.s, dir: pfDir(p.s, pf.dsQ), los: ds.yl, fd: Math.min(100, ds.yl + ds.togo), kind: 'set' }; pfQueue(Object.assign(P, { kind: 'set' }), `${sim.ids[p.s] === ME ? myAb() : isFCS(sim.ids[p.s]) ? 'FCS' : sim.ids[p.s]} ball · 1st & 10`); } }
  pfFlushDs();
}
