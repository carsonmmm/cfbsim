/* ===================== QUALITY OF LIFE: undo, shortcuts, the glossary, what changed ===================== */

/* ---------- undo the last roster move ---------- */
// Roster moves (releases, depth chart changes, position switches, cuts) keep a copy of the career from just before.
// The Undo button stays until you do something else that changes the game (a sim, a signing, another tab's move).
const UNDO_ACTS = { release: 'Release', pcut: 'Release', pautocut: 'Roster cuts', dmove: 'Depth chart change', dtop: 'Depth chart change', dauto: 'Depth chart reset', mkstarter: 'New starter', switchpos: 'Position change', scholar: 'Scholarship' };
// actions that only change what's on screen: they leave the undo in place
const UNDO_KEEP = new Set(['undo', 'tab', 'player', 'team', 'box', 'close', 'recf', 'dfpos', 'paysort', 'moremenu', 'overshow', 'overhide', 'cmpset', 'cmpgo', 'cmpclear', 'pollv', 'admtab', 'setpref', 'togglemode', 'toggleside', 'askrel', 'pask', 'dsort', 'sharef', 'sharerefresh', 'chalview', 'kbhelp', 'glossary', 'rpos']);
function undoSnap(act) { if (appMode !== 'ad' || !state || liveBusy() || !UNDO_ACTS[act]) return null; try { return { j: JSON.stringify(state), rng: RNG.s, lbl: UNDO_ACTS[act], key: state.season + ':' + state.week + ':' + state.phase, n: state.roster.length }; } catch (e) { return null; } }
function undoAfter(act, snap) { if (snap) { ui.undo = snap; return; } if (ui.undo && !UNDO_KEEP.has(act)) ui.undo = null; }
function undoBarHTML() { const u = ui.undo; if (!u || !state || u.key !== state.season + ':' + state.week + ':' + state.phase) return ''; return `<div class="undobar" role="status"><span>${esc(u.lbl)}</span><button class="btn sm" data-act="undo">Undo</button><button class="icon" data-act="undodrop" aria-label="Dismiss">×</button></div>`; }
Object.assign(actions, {
  undo() { const u = ui.undo; if (!u || liveBusy()) return; ui.undo = null; try { state = JSON.parse(u.j); RNG.s = u.rng; rebuildPMap(); save(); after(`Undone: ${u.lbl.toLowerCase()}.`); } catch (e) { after('That move could not be undone.'); } },
  undodrop() { ui.undo = null; render(); },
});

/* ---------- keyboard shortcuts ---------- */
// N: next (the main button) · L: watch live · 1-9: tabs · U: undo · ?: this list. In a live game: Space pauses,
// F changes the speed. Off in Settings (prefs.keys). Never fires while you type in a box.
const KB_HELP = [['N', 'Next: the main button (sim the week, next offseason step)'], ['L', 'Watch this week\'s game live'], ['1 – 9', 'Jump to a tab'], ['U', 'Undo the last roster move'], ['G', 'What the numbers mean'], ['?', 'Show this list'], ['Space', 'Live game: pause or resume'], ['F', 'Live game: faster or slower'], ['Esc', 'Close a window']];
function kbHelpHTML() { return `<div class="eyebrow">Keyboard shortcuts</div><h2 class="h2">Play faster</h2><table class="mini wide">${KB_HELP.map(([k, d]) => `<tr><td><kbd>${esc(k)}</kbd></td><td>${esc(d)}</td></tr>`).join('')}</table><p class="hint mt">Turn them off in Settings if they get in your way.</p>`; }
document.addEventListener('keydown', e => {
  if (prefs.keys === 'off' || e.ctrlKey || e.metaKey || e.altKey || e.defaultPrevented) return;
  const t = e.target; if (t && (t.isContentEditable || /^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName))) return;
  const k = e.key; const m = $('#modal'); const open = m && !m.hidden;
  if (open) {
    if (appMode === 'ad' && liveBusy() && live.open) {
      if (k === ' ' && !live.sim.pending) { e.preventDefault(); actions.lpause(); }
      else if (k === 'f' || k === 'F') { e.preventDefault(); actions.lspeed({ v: String(live.speed % 3 + 1) }); }
    }
    return;
  }
  if (k === '?') { e.preventDefault(); openModal(kbHelpHTML(), 'Keyboard shortcuts'); return; }
  if (appMode === 'home') return;
  if (k === 'g' || k === 'G') { e.preventDefault(); openModal(glossaryHTML(), 'What the numbers mean'); return; }
  if (/^[1-9]$/.test(k)) { const tabs = [...document.querySelectorAll('#tabs [data-act="tab"], #tabs [data-act="ctab"], #mnav [data-act="tab"], #mnav [data-act="ctab"]')].filter(b => b.offsetParent !== null); const b = tabs[+k - 1]; if (b) { e.preventDefault(); b.click(); } return; }
  if (appMode !== 'ad' || !state) return;
  if (k === 'n' || k === 'N') { const b = document.querySelector('#hdr [data-act="primary"], #view [data-act="primary"], #view [data-act="offnext"], #view [data-act="pnext"]'); if (b && !b.disabled) { e.preventDefault(); b.click(); } }
  else if (k === 'l' || k === 'L') { const b = document.querySelector('#view [data-act="live"]'); if (b && !b.disabled) { e.preventDefault(); b.click(); } }
  else if ((k === 'u' || k === 'U') && ui.undo) { e.preventDefault(); actions.undo(); }
});

/* ---------- the glossary: every rating and number ---------- */
const GLOSS = {
  ovr: 'Overall rating, 40–99: how good a player is right now at his position.', pot: 'Potential: the overall rating he could grow into.', 'ovr / pot': 'Overall rating now / the rating he could grow into. A range means your scouts aren\'t sure yet.',
  stars: 'Recruiting stars, 1–5, from the national services. Five stars is a can\'t-miss prospect.', interest: 'How interested a recruit is in your school, 0–100. The leader when he decides usually signs him.',
  overall: 'Team strength on a 0–100 scale: offense, defense and special teams together.', offense: 'Offensive strength: your starters\' ratings, scheme fit, coaching and this week\'s plan.', defense: 'Defensive strength: your starters\' ratings, scheme fit, coaching and this week\'s plan.',
  'expected wins': 'How many regular-season games a team this strong should win against this schedule.', 'win chance': 'The chance to win this game from here, from the score, the time left and the two teams\' strength.',
  prestige: 'How big the program or job is. Recruits, coaches and offers all follow prestige.', morale: 'The locker room, 0–100. High morale helps on game day and keeps players from leaving.', 'locker room': 'The locker room, 0–100. High morale helps on game day and keeps players from leaving.',
  fans: 'Fan support, 0–100. Drives ticket sales and the home crowd.', boosters: 'Booster support, 0–100. Drives donations and NIL money.', board: 'How happy your boss is, 0–100. Too low and you can be fired.', 'hot seat': 'How close the head coach is to being fired, 0–100.', 'ncaa risk': 'How likely an NCAA investigation is. Bending recruiting rules raises it; the compliance office lowers it.',
  'cap room': 'Salary cap space left this season after every contract and dead money.', 'dead money': 'Cap charges for players no longer on the team (signing bonuses that still count).', apy: 'Average per year: a contract\'s total value divided by its years.', 'signing bonus': 'Paid up front, but charged to the cap evenly over the contract\'s years.',
  leadership: 'How strong your captains are. Leaders count triple. It lifts the locker room every week.', 'legacy score': 'Your career on one number: titles, wins, rivalry wins, profits and the program\'s growth.',
  rapport: 'How a player or coach feels about you, 0–100. It moves with playing time, wins, promises and what you say.', chemistry: 'How well you get along with the teammates you compete with, 0–100.', gpa: 'Grade point average, 0–4. Under 2.0 at the start of a season means you sit the first three games.',
  followers: 'Your social following. Big games, awards and draft night grow it; brands call as it grows.', 'skill points': 'Points to spend on ratings. You earn them from games and offseasons.', trust: 'How much your coach trusts you, 0–100. More trust means more snaps.',
  'football net': 'Football revenue minus football expenses this fiscal year.', 'department reserve': 'The athletic department\'s cash on hand.', 'experience': 'Seasons in the NFL.', class: 'Year in school: Fr, So, Jr, Sr, or Gr (graduate).',
  momentum: 'Who has the run of play. A touchdown or a takeaway swings it.', 'crowd factor': 'How much the home crowd helps. Bigger stadiums and better fans help more.', 'composite': 'The recruiting services\' combined grade, out of 1.0000.',
};
function glossOf(txt) { const k = String(txt || '').toLowerCase().replace(/[^a-z /]/g, '').replace(/\s+/g, ' ').trim(); return GLOSS[k] || null; }
// mark the labels on screen that have an explanation: dotted underline, a tooltip, and tap or Enter to read it
function applyGloss(root) {
  if (!root) return; root.querySelectorAll('.tiles .k, th, .lbl, .kv .k, .meter .k').forEach(el => { if (el.dataset.gl || el.children.length > 1) return; const d = glossOf(el.textContent); if (!d) return; el.dataset.gl = '1'; el.classList.add('glo'); el.title = d; if (el.tagName !== 'TH') el.tabIndex = 0; });
}
function glossaryHTML() { return `<div class="eyebrow">Glossary</div><h2 class="h2">What the numbers mean</h2><dl class="gloss">${Object.entries(GLOSS).filter(([k]) => k !== 'ovr / pot' && k !== 'locker room').map(([k, v]) => `<dt>${esc(k.replace(/\b[a-z]/g, c => c.toUpperCase()).replace(/^(Ovr|Pot|Apy|Gpa|Ncaa)\b/, s => s.toUpperCase()))}</dt><dd>${esc(v)}</dd>`).join('')}</dl>`; }
document.addEventListener('click', e => { const el = e.target.closest('.glo'); if (!el || el.closest('[data-act]')) return; notifyGloss(el); });
document.addEventListener('keydown', e => { if (e.key !== 'Enter') return; const el = e.target.closest && e.target.closest('.glo'); if (el) { e.preventDefault(); notifyGloss(el); } });
function notifyGloss(el) { const d = el.title || glossOf(el.textContent); if (!d) return; let t = document.getElementById('gltip'); if (!t) { t = document.createElement('div'); t.id = 'gltip'; t.className = 'gltip'; t.setAttribute('role', 'status'); document.body.appendChild(t); } t.textContent = `${el.textContent.trim()}: ${d}`; t.hidden = false; clearTimeout(notifyGloss.t); notifyGloss.t = setTimeout(() => { t.hidden = true; }, 5000); }
Object.assign(actions, { glossary() { openModal(glossaryHTML(), 'What the numbers mean'); }, kbhelp() { openModal(kbHelpHTML(), 'Keyboard shortcuts'); } });
{ const mo = new MutationObserver(() => { applyGloss($('#view')); const m = $('#modal .mbody'); if (m && !$('#modal').hidden) applyGloss(m); }); mo.observe(document.getElementById('view'), { childList: true }); const md = document.getElementById('modal'); if (md) mo.observe(md, { childList: true, subtree: true }); }

/* ---------- what changed over a multi-season sim ---------- */
function changeSnap() {
  if (!state) return null; const t = T(ME); const top = state.roster.slice().sort((a, b) => b.ovr - a.ovr).slice(0, 5).map(p => p.id);
  return { season: state.season, lvl: isPro() ? 'nfl' : 'col', me: ME, rating: t ? t.rating : null, bal: state.fin && !isPro() ? state.fin.balance : null, hc: state.staff && state.staff.HC ? state.staff.HC.name : null, top, troph: (state.trophies || []).length, hof: (state.hof || []).length, fan: state.meters ? state.meters.fan : null, board: state.meters ? state.meters.board : null, role: isCoach() ? state.co.role : null };
}
function changesHTML(b) {
  if (!b || !state) return ''; const a = changeSnap(); const rows = []; const sg = v => (v > 0 ? '+' : '') + v;
  if (a.me !== b.me || a.lvl !== b.lvl) rows.push(`New team: <b>${esc(myName())}</b>${a.lvl !== b.lvl ? (a.lvl === 'nfl' ? ' (NFL)' : ' (college)') : ''}`);
  if (isCoach() && a.role !== b.role) rows.push(`New job: <b>${esc(roleTitle(a.role))}</b>`);
  if (a.me === b.me && a.rating != null && b.rating != null && Math.abs(a.rating - b.rating) >= 0.5) rows.push(`Team rating ${Math.round(b.rating)} → <b>${Math.round(a.rating)}</b> (${sg(Math.round(a.rating - b.rating))})`);
  if (a.hc !== b.hc && a.me === b.me && !isCoach() && a.hc) rows.push(`Head coach: ${esc(b.hc || 'none')} → <b>${esc(a.hc)}</b>`);
  if (a.bal != null && b.bal != null && a.lvl === 'col' && b.lvl === 'col') rows.push(`Department reserve ${fm(b.bal)} → <b>${fm(a.bal)}</b>`);
  if (a.fan != null && b.fan != null && Math.abs(a.fan - b.fan) >= 3) rows.push(`Fans ${Math.round(b.fan)} → <b>${Math.round(a.fan)}</b>`);
  if (a.board != null && b.board != null && Math.abs(a.board - b.board) >= 3) rows.push(`Board ${Math.round(b.board)} → <b>${Math.round(a.board)}</b>`);
  const gone = b.top.filter(id => !P(id)).length; if (gone && a.me === b.me) rows.push(`${gone} of your 5 best players from ${b.season} ${gone === 1 ? 'is' : 'are'} gone; your best now: ${state.roster.slice().sort((x, y) => y.ovr - x.ovr).slice(0, 3).map(p => `${esc(p.n)} (${p.pos}, ${p.ovr})`).join(', ')}`);
  if (a.troph > b.troph) rows.push(`Trophies won: <b>${(state.trophies || []).slice(b.troph).map(t => esc(t.t)).join(' · ')}</b>`);
  if (a.hof > b.hof) rows.push(`Hall of Fame: ${(state.hof || []).slice(b.hof).map(x => esc(x.n)).join(', ')}`);
  const tl = (state.tline || []).filter(x => x.s >= b.season && x.k === 'big' && !/season begins|^Welcome to|^Achievement unlocked/.test(x.txt)).slice(-10).map(x => `<li><span class="when">${x.s}</span>${esc(x.txt)}</li>`).join('');
  if (!rows.length && !tl) return '';
  return `<div class="eyebrow mt">What changed</div><ul class="plainlist small">${rows.map(r => `<li>${r}</li>`).join('')}</ul>${tl ? `<div class="eyebrow mt">Headlines</div><ul class="news">${tl}</ul>` : ''}`;
}

/* ---------- historical rankings (Admin) ---------- */
Object.assign(actions, { admrank() { const el = $('#admrank'); const r = importRankings(el ? el.value : ''); after(r.n ? `Ranking applied to ${r.n} team${r.n === 1 ? '' : 's'}: ${r.top.join(', ')}${r.n > 5 ? '…' : ''}.` : 'No teams matched. Use one team per line, like "1. Georgia".'); } });
applyGloss(document.getElementById('view'));
